////////////////////////////////////////////////////////
// DOGException.java
// 
// This file an execption-handling file
//
//
///////////////////////////////////////////////////////
package p1;
public class DOGException extends Exception
{		
		
		public 	int		Error;

		/**
		 *	Constructs a DOG exception that contain
		 *	an error number returned by DOG device driver
		 *
		 * @param ErrorNumber   Value returned by last call to DOG device driver.
		 */	
					
		public DOGException( int ErrorNumber )
		{
				super( "Dog Operation Error " + ErrorNumber );
				Error = ErrorNumber;
		}
}


