
                     -------------------------------------------------------
	                         MicroDog 32-bit LINUX Application
                                         API Guide to JAVA
                     -------------------------------------------------------

                   Copyright (c) 2003, Rainbow China Co., Ltd.


  The API for JAVA is a module for Linux and is suitable for protecting JAVA 
application.

========================
Introduction to MicroDog
========================
MicroDog includes hardware Dog and a supporting software kit. The hardware Dog 
consists of Single-chip microprocessor and 200-byte nonvolatile memory, and 
is installed to a parallel port when used. The kit contains functions for 
accessing the hardware Dog.

In LINUX operating system MicroDog provides five functions, allowing you to check 
MicroDog status,read data from or write data to the Dog memory, convert a string into a 
32-bit unsigned integer, read the Manufacturing code .

The function for checking MicroDog status is the fastest and simplest 
utility for generating program protection.
  
The memory reading and writing functions enable you to access the hardware 
Dog's memory.  You can write variables to the memory dynamically in one section of
the program, and directly read their values in another section, thereby improving 
software protection.  You can also place some configure information 
into the memory for recording the user's log.

The function for converting data sends a data string to the hardware Dog.  The Dog 
scrambles the data according to the algorithm chosen by developer and algorithm's 
descriptors defined by developer, and returns a 32-bit result. The values sent and 
returned correspond on a one by one basis, and every hardware Dog should have its 
system defined descriptors (4-byte/32-bit) and the developer defined descriptors 
(3-byte/24-bit). There are 256 kinds of algorithms for your choice. In total, you 
can have more than 4,000,000,000 different combinations.

The Manufacturing code reading function can read the Manufacturing code of the
current hardware Dog.Every hardware Dog has a unique Manufacturing code that can
be used by the developer to manage end-users.


By using these functions in an integrated manner, you can protect your software product and  
your profit from potential pirates.  For detailed information about how to implement 
software protection, please refer to the Developer's manual.
  

=========
File list
=========
   File name                    Description
   ----------            ----------------------------------------------------------
   readme-eng.txt        This file
   <sample1>             <dir> include the sample program source code and the source code which 
                               used to generate the shared library
   <sample2>             <dir> include the sample program source code and the source code which 
                               used to generate the shared library.In this sample we use the package
                               "p1",you can reference this sample to generate your own program.
   DogDemo.java          Sample program for using GS-MH MicroDog in encryption. 
   GSDOG.java            Source code for class GSDOG, with envelop for operations on MicroDog. 
                         And sample of calling DLL in JAVA.
   DOGGSMH.java          A source program of DOGGSMH that realized the operation on MicroDog, 
                         with inheriting GSDOG class. 
   DOGException.java     Source code for DOGException, error handling.
   libMhlinuxj.so        DLL which realizes the operation on MicroDog called by JAVA applications. 

===================
Tested environments
===================
Linux 2.4 ,JDK 1.3 Release for Linux

===================
Introduction to API    
===================
  Class GSDOG envelops the operating methods and variables for the Dog, including six 
variables:
  unsigned char DogCascade:
     The parameter for cascade capability, it should be equal the number saved in hardware dog.
     The DogCascade is the number from 0 to 15

  int  DogAddr:
     Indicates the start address (0~199) of MicroDog internal user area during read 
     operation. The sum of adding DogAddr with DogBytes will not be allowed to be 
     over 200.

  int  DogBytes:
     Byte number of read operation (1~200) or conversion operation (1~63). In  read 
     operation, The sum of adding DogAddr with DogBytes will not be allowed to be 
     over 200.

  int  DogPassword:
     Access operation password.

  long  DogResult:
     Result after conversion. Function DogConvert will put the converted result 
     into this variable. Be careful, if the operation of DogConvert fails, the original 
     DogResult value will not be changed. 
 

  String DogData:
     String variable to indicate buffer of read/write/conversion operation. 


  ============================
  Explanation to API functions
  ============================
a. public native int DogCheck();  
   Input parameter: DogCascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Checks whether the hardware Dog exists.  Only a Dog has the same serial
         number as the OBJ file can be detected.  In this version, the modules  have a cascade 
         function. DogCascade must be equal the number saved in the Hardware Dog.       


b. public native int DogConvert();  
   Input parameter: DogCascade, DogBytes, DogData
   Output parameter: DogResult
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Transfers data to MicroDog.  The hardware Dog converts the data 
       and returns the converted result Dogresult as a 32-bit integer.  DogBytes indicates
       the number of bytes of the date, which DogData points to, being converted. 
       The conversion algorithm can be specified by the developer.  The last 4 bytes 
       of memory affects the conversion algorithm.  The 196th byte is used to 
       specify the algorithm.  Therefore, a developer can define 256 kinds of algorithms. 
       The algorithm descriptors are made up of the 197th, 198th and 199th byte, so it have 
       a maximum of 16,777,215 different combinations.

c. public native int WriteDog();
   Input parameter: DogCascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Writes data to the hardware Dog. Carries out the same operation as ReadDog,
      except that the data flow direction is different.

*Caution:
     The last 4 bytes are used to define the conversion algorithm. Therefore, better
     not use these 4 bytes unless you want to change the algorithm.


d. public native int ReadDog();
   Input parameter:  DogCascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter:  DogData
   Return value:     0 = operation succeeded. All others are error codes.
   Function: Reads data from the hardware Dog. The Dog contains a 200-byte nonvolatile 
         memory.  ReadDog reads data from the Dog memory beginning at the address 
         indicated by DogAddr.  The bytes number of the read data is indicated 
         by DogBytes.  The read data is stored in the space DogData points to.
         MicroDog verifies the DogPassword. DogPassword is the password for
         read/write operations stored on the hardware Dog.  It can be set by the 
         utility tool DOGEDIT.EXE in UTILITY folder or the SetPassword() function. 
         Applications must ensure enough space to buffer the data being read.  ReadDog 
         does not check whether the buffer size is sufficient.


e. public native int GetCurrentNo();
   Input Parameter: DogCascade, DogData
   Output parameter: DogData
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads the Manufacturing code of the hardware Dog.Some of the hardware
             Dogs may have the same ID, but every hardware Dog has its unique
             Manufacturing code. The Manufacturing code can help developers manage
             user accounts.
             The Manufacturing code is 4 bytes.

Remark:
    Please refer DOGGSMH.JAVA, DOGDEMO.JAVA to learn how to use these functions. 

============
Error code
============
   Refer to ERRCODE.TXT in the root of the installation directory for detailed 
   information about error codes.

=======================================
Compiling and running of sample program
=======================================
  
  This Java sample program is written with Java JDK for Linux, with the 
following environment:
         Java J2SDK 1.3/1.4 Release
 
  Steps:

  1. Compile the java sample program
    Enter:
	JAVAC DogDemo.java
    The following are generated:
         DogDemo.class
         GSDOG.class
         DOGGSMH.class
         DOGException.class     

  2. Run java sample program:
    To run the sample program, device driver should be installed. With regard to 
installation for device drivers, please refer readme file in DRIVER folder.
    To run the sample, enter:
	java DogDemo
    If can't find the library,you should enter
        export LD_LIBRARY_PATH=.
    then enter
        java DogDemo

========================
Generate libMhlinuxj.so
========================

    DLL subfolder contains the following files, which may be used to generate 
libMhlinuxj.so. 
    This version of libMhlinuxj.so is written with Java JDK for Linux . 
    Compiling environment: Linux 2.4 ,GCC, Java JDK 1.3 Release


    dogimp.cc      native method source code in GSDOG 
    GSDOG.h        Header file generated directly from GSDOG.class.
                   Method: under command prompt, input;
                   javah -jni GSDOG
    mhlinuxc.o     The Linux C API module for MicroDog.
    GSMH.H          Header file needed to link mhlinuxc.o.
    
step 1:
      User need to modify "Makefile" file firstly, replacing INCLUDE macro with your JDK directory, for example
      INCLUDE = /home/j2sdk1.4.0/include
step 2:
      Execute "make" under DLL directory.
 


=========
Cautions
=========
1. When you write data to the Dog, changing the last 4 bytes of the 
   hardware Dog memory will affect the result of function DogConvert().


2. If you want to run the protected application in other computer in Linux, you 
   should install the corresponding device driver for the hardware Dog. Please go into 
   the driver directory and execute "make install" to install the device driver.

3. If you want to release your protected programs to your end-users, please include
   the device drivers and installing tool in the DRIVER folder in your SETUP process,
   and execute installing the device drivers for the Dog first. 

=================
Technical support
=================
If you have any technical problems, please contact Rainbow China Co., Ltd., 
our branches, or our distributors.  

Please Refer to  /Address.txt for the contact address.

