               -------------------------------------------------------------
	               MicroDog SUITE LINUX DRIVER MODULE SPECIFICATION
               -------------------------------------------------------------
                   Copyright (c) 2003,  Rainbow China Co., Ltd.


=================
FUNCTION
=================
MicroDog's driver in LINUX operating system can realize the base operations of Parallel Dog and USBDog.

=================
Appling Environment
=================
The Linux operating system based the kernel of Linux2.4 and Linux2.2.
You can only operate Parallel Dog in the Linux operating system based the kernel ofLinux2.2.
You can operate both Parallel Dog and USBDog in the Linux operating system based the kernel ofLinux2.4.

=================
Using Method
=================

-------------------------
Install the dog's driver
-------------------------
Install the driver of MicroDog

If you find the same directory with your linux kernel version in directory <ParallelDriver>, you should enter in 
this directory and excute "make install" to install device driver,then reboot the computer.
first execute "make",then execute "make install" to install device driver,finally reboot the computer.
If you don't find the same directory with you linux kernel version,please contact Rainbow China Co., Ltd.

Install the driver of USBDog

If you find the same directory with your linux kernel version in directory <UsbDriver>, you should enter in 
this directory and excute "make install" to install device driver,then reboot the computer.
first execute "make",then execute "make install" to install device driver,finally reboot the computer.
If you don't find the same directory with you linux kernel version,please contact Rainbow China Co., Ltd. 

----------------------
Remove the dog's driver
----------------------
In driver directory  execute "make uninstall".

=================  
File List
=================
 readme-chn.txt      This file    
 ParallelDriver  <DIR>   Include the driver file of Parallel Dog 
     2.4.2-2	 <DIR>	 Include the driver file of Parallel Dog for kernel version 2.4.2-2(RedHat 7.1)
	mhlinux.o		The module of driver
	Makefile		The driver install file
	mhdog_load	 	The script to be used loading the driver 
     2.4.7-10	 <DIR>	 Include the driver file of Parallel Dog for kernel version 2.4.7-10(RedHat 7.2)
	mhlinux.o		The module of driver
	Makefile		The driver install file
	mhdog_load	 	The script to be used loading the driver 
     2.4.18-3	 <DIR>	 Include the driver file of Parallel Dog for kernel version 2.4.18-3(RedHat 7.3)
	mhlinux.o		The module of driver
	Makefile		The driver install file
	mhdog_load	 	The script to be used loading the driver 
     2.4.18-14	 <DIR>	 Include the driver file of Parallel Dog for kernel version 2.4.18-14(RedHat 8.0)
	mhlinux.o		The module of driver
	Makefile		The driver install file
	mhdog_load	 	The script to be used loading the driver 
     2.4.20-8	 <DIR>	 Include the driver file of Parallel Dog for kernel version 2.4.20-8(RedHat 9.0)
	mhlinux.o		The module of driver
	Makefile		The driver install file
	mhdog_load	 	The script to be used loading the driver 
     2.2.x       <DIR>   Include the driver file of Parallel Dog for kernel version 2.2.x(pass the test on Redhat 7.0)
	mhlinux.o		The module of driver
	Makefile		The driver install file
     	mhdog_load	 	The script to be used loading the driver 

 usbDriver       <DIR>   Include the driver file of USBDog
     2.4.2-2	 <DIR>	 Include the driver file of USBDog for kernel version 2.4.2-2(RedHat 7.1)
	usbdog.o		The module of driver
	Makefile		The driver install file
	usbdog_load	 	The script to be used loading the driver 
     2.4.7-10	 <DIR>	 Include the driver file of USBDog for kernel version 2.4.7-10(RedHat 7.2)
	usbdog.o		The module of driver
	Makefile		The driver install file
	usbdog_load	 	The script to be used loading the driver 
     2.4.18-3	 <DIR>	 Include the driver file of USBDog for kernel version 2.4.18-3(RedHat 7.3)
	usbdog.o		The module of driver
	Makefile		The driver install file
	usbdog_load	 	The script to be used loading the driver 
     2.4.18-14	 <DIR>	 Include the driver file of USBDog for kernel version 2.4.18-4(RedHat 8.0)
	usbdog.o		The module of driver
	Makefile		The driver install file
	usbdog_load	 	The script to be used loading the driver 
     2.4.20-8	 <DIR>	 Include the driver file of USBDog for kernel version 2.4.20-8(RedHat 9.0)
	usbdog.o		The module of driver
	Makefile		The driver install file
	usbdog_load	 	The script to be used loading the driver 

 

=================
Technical support
=================
If you have any technical problems, please contact Rainbow China Co., Ltd., 
our branches, or our distributors. 

Please Refer to  /Address.txt for the contact address.