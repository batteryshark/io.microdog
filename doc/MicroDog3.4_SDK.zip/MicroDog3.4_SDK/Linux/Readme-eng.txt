				====================================
				MicroDog LINUX Module Utility Guide
				====================================
				Copyrights (c)  2002 , Rainbow China Co., Ltd.

    This module provides an extended capability of MicroDog to support Linux. 
This module is used to operate Parallel Dog when the Linux kernel's version is 2.2.x. 
This module is used to operate Parallel Dog or USBDog when the Linux kernel's version is 2.4.x.  

Software 
=========

    The new software includes the following files and documents:
    README-ENG.TXT                This file
    ADDRESS-ENG.TXT                  Rainbow China contact info
    ERRCODE-ENG.TXT                  Common error codes listing
    VERSION-ENG.TXT                  Account of each module, tool version and part number
    UTILITY      <DIR>           Tool software, including Getver 
    C            <DIR>           Module for C language, file and example program
    JAVA         <DIR>           Module for Java language, file and example program  
    DLL          <DIR>           Module for DLL in C language, file and example program
    DRIVER       <DIR>           Driver Module,and files
    Kylix        <DIR>	         Includes Delphi and CBuilder modules in linux

    For tech details, please read the corresponding Readme file and demo program.


======================================================================
    Dog, MicroDog are registered trademarks of Beijing Goldensoft Co., Ltd. and have been 
authorized to Rainbow China Co.,Ltd for its use.
