//---------------------------------------------------------------------------

#include <clx.h>
#pragma hdrstop

#include "Unit1.h"
extern "C"
{
extern cdecl unsigned long MyDogCheck(unsigned char Cascade);
extern cdecl unsigned long MyReadDog(unsigned char Cascade, unsigned long Password,short int Address,short int Bytes,unsigned char* pData);

extern cdecl unsigned long MyWriteDog(unsigned char Cascade, unsigned long Password,short int Address,short int Bytes,unsigned char* pData);

extern cdecl unsigned long MyDogConvert(unsigned char Cascade, short int DataLen,unsigned char* pDataIn,unsigned long *pResult);

extern cdecl unsigned long MyGetCurrentNo(unsigned char Cascade, unsigned long *pResult);

}

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.xfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------



void __fastcall TForm1::ButtonDogCheckClick(TObject *Sender)
{
        unsigned long ulRetCode;
        unsigned char Cascade;
        AnsiString str;
        Cascade=0;
        ulRetCode = MyDogCheck(Cascade);
        if (ulRetCode==0)
        {
                str.cat_printf("DogCheck succeeded");
                LabelResult->Caption=str;
        }
        else
        {
                str.cat_printf("DogCheck failed\nThe error code is: %u",ulRetCode);
                LabelResult->Caption=str;

        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonReadDogClick(TObject *Sender)
{
        unsigned long ulRetCode;
        unsigned char Cascade;
        unsigned long Password;
        unsigned char Data[16];
        unsigned short Address = 0;
        unsigned short Bytes =16;
        AnsiString      str;
        Password=0;
        Cascade=0;
        ulRetCode = MyReadDog(Cascade,Password,Address,Bytes,Data);
        if (ulRetCode==0)
        {
                str.cat_printf("ReadDog succeeded!\nThe read data is:\n");
                for(int i=0;i<16;i++)
                {
                        str.cat_printf("%c",Data[i]);
                }
                LabelResult->Caption=str;

        }
        else
        {
                str.cat_printf("ReadDog failed!\nThe error code is: %u",ulRetCode);
                LabelResult->Caption=str;

        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonWriteDogClick(TObject *Sender)
{
        unsigned long ulRetCode;
        unsigned char Cascade;
        unsigned long Password;
        unsigned char Data[16];
        unsigned short Address = 0;
        unsigned short Bytes =16;
        AnsiString str;

        Password=0;
        Cascade=0;

        for (int i=0;i<16;i++)
        {
           Data[i]=0x31+i;
        }

        ulRetCode = MyWriteDog(Cascade,Password,Address,Bytes,Data);
        if (ulRetCode==0)
        {
                str.cat_printf("WriteDog succeeded!");
                LabelResult->Caption=str;

        }
        else
        {
                str.cat_printf("WriteDog failed!\nThe error code is: %u",ulRetCode);
                LabelResult->Caption=str;

        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonGetCurrentNoClick(TObject *Sender)
{
        unsigned long ulRetCode,ulCurrentNumber;
        unsigned char Cascade;
        AnsiString str;
        Cascade=0;
        ulRetCode = MyGetCurrentNo(Cascade,&ulCurrentNumber);
        if (ulRetCode==0)
        {
                str.cat_printf("GetCurrentNo succeeded\nThe current number is %u",ulCurrentNumber);
                LabelResult->Caption=str;
        }
        else
        {
                str.cat_printf("WriteDog failed!\nThe error code is: %u",ulRetCode);
                LabelResult->Caption=str;

        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonDogConvertClick(TObject *Sender)
{
        unsigned long ulRetCode,ulResult;
        unsigned char Cascade;
        unsigned char Data[16];
        unsigned short   Len=16;
        AnsiString str;
        Cascade=0;

        ulRetCode = MyDogConvert(Cascade,Len,Data,&ulResult);
        if (ulRetCode==0)
        {
                str.cat_printf("DogConvert succeeded!\nThe result is: %u",ulResult);
                LabelResult->Caption=str;
        }
        else
        {
                str.cat_printf("DogConvert failed!\nThe error code is: %u",ulRetCode);
                LabelResult->Caption=str;

        }

}
//---------------------------------------------------------------------------

