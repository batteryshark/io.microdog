//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <QControls.hpp>
#include <QStdCtrls.hpp>
#include <QForms.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TButton *ButtonDogCheck;
        TGroupBox *GroupBox1;
        TLabel *LabelResult;
        TButton *ButtonReadDog;
        TButton *ButtonWriteDog;
        TButton *ButtonGetCurrentNo;
        TButton *ButtonDogConvert;
        TLabel *Label1;
        void __fastcall ButtonDogCheckClick(TObject *Sender);
        void __fastcall ButtonReadDogClick(TObject *Sender);
        void __fastcall ButtonWriteDogClick(TObject *Sender);
        void __fastcall ButtonGetCurrentNoClick(TObject *Sender);
        void __fastcall ButtonDogConvertClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
