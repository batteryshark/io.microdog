
                     -----------------------------------------------------------------
                               Microdog Suite 32-bit Linux Application
                          Illustration of Kylix using shared library sample 
                     -----------------------------------------------------------------

                 Copyrights (c)  2003 ,  Rainbow China Co., Ltd. 


=========
Functions
=========
  Microdog  Suite contains  Hardware Dog (Parallel Dog or USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of into the parallel port or USB port.  The software supplies functions for calling the 
Hardware Dog.
  In LINUX operating system,Microdog Suite has five functions including verifying of the correct 
Hardware Dog, writing data into and reading data from the memory, changing data, checking the 
current manufacturing number.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogCovert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-digit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The five functions specified above will secure your software products from any unauthorized 
use.  For detailed description of protection strategy, please read The Developer's Manual. 

===============================
Introduction to DLL programming
===============================

Under 32-bit Linux environment, the MicroDog Dynamic Linking Library can be made through GCC compiler.
One important thing is that, because the DLL is seperated from the protected application, 
the calling interface of DLL functions is then exposed to hacker (because of the nature 
of DLL). Here comes the importance for the hiding of DLL functions' name and function 
calling.  Therefore, we strongly recommend you to use static API Library (such as C API) to 
protect your application other than DLL in general. If DLL method must be used, and the 
strength of the protection comes from the complexity of your own DLL, the software developer 
must make the DLL as complicated as possible. The functions' calling interface of DLL must 
be hidden well, and the functions' names in the DLL should not be relative with the Dog 
operation. The sequence of parameters passing should also be baffling for hackers, and the 
dog operation functions should be merged with your own other DLL functions. 


=========
File list
=========
   File Name        Description
   ------------     -----------------------------
   readme-eng.txt   This guide
   mhInterface.so   The shared library
   CBuilder         CBuilder sample
   delphi           Delphi sample
   

==============================
Tested Environment
==============================
Based in the Linux Kernel 2.2 and 2.4. the Kylix 3 has been tested.


==============================
The Shared Library Functions
==============================
  The Shared Library here refer to the file libMhlinuxc.so. Include the head file GSMH.H when coding.

1. The Shared Library define the following functions which can be used in the developer's program.
unsigned long MyDogCheck(unsigned char Cascade);
unsigned long MyReadDog(unsigned char Cascade, unsigned long Password,short int Address,short int Bytes,
		unsigned char* pData);unsigned long MyWriteDog(unsigned char Cascade, unsigned long Password,short int Address,short int Bytes,
		unsigned char* pData);unsigned long MyDogConvert(unsigned char Cascade, short int DataLen,unsigned char* pDataIn,unsigned long *pResult);unsigned long MyGetCurrentNo(unsigned char Cascade, unsigned long *pResult);
   Explanation for the variables
   --------------------------------
     a. DogAddr:  Indicates the start address (0~199) of MicroDog internal 
                  user area during read operation. The sum of adding DogAddr with 
                  DogBytes will not be allowed to be over 200.

     b. DogBytes: Byte number of read operation (1~200) or conversion operation 
                  (1~63). In read operation, The sum of adding DogAddr with DogBytes 
                  will not be allowed to be over 200.

     c. DogPassword: Access password. The factory setting in the hardware Dog is 
                     0, it may be changed by dogedit in UTILITY folder. It 
                     will only take effect for the functions of ReadDog and WriteDog, 
                     not for DogCheck and DogConvert.

     d. DogResult: Result after conversion. Function DogConvertT will put the 
                   converted result into this variable. Be careful, if the 
                   operation of DogConvert fails, the original DogResult value will 
                   not be changed. 

     e. DogCascade:  parameter for cascade capability, it must be the number saved in 
                  the Hardware Dog.The DogCascade is the number from 0 to 15. 

     f. pData: Buffer of read/write/conversion operation. 

2. unsigned long MyDogCheck(unsigned char Cascade)
   Input parameter: DogCascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Checks whether the hardware Dog exists.  Only a Dog that has the same serial
             number as the OBJ file can be detected.  In this version, the modules have a 
             cascade function. DogCascade must be equal the number saved in Hardware Dog.       
    
3. unsigned long MyReadDog(unsigned char Cascade, unsigned long Password,short int Address,short int Bytes,
		unsigned char* pData)
   Input parameter:  DogCascade DogAddr, DogBytes, pData, DogPassword
   Output parameter:  pData
   Return value:     0 = operation succeeded. All others are error codes.
   Function: Reads data from the hardware Dog. The Dog contains a 200-byte nonvolatile 
         memory.  ReadDog reads data from the Dog memory beginning at the address 
         indicated by DogAddr.  The bytes number of the read data is indicated 
         by DogBytes.  The read data is stored in the space DogData points to.
         MicroDog verifies the DogPassword. DogPassword is the password for
         read/write operations stored on the hardware Dog.  It can be set by the 
         utility tool DOGEDIT in UTILITY folder .Applications must ensure enough 
         space to buffer the data being read.  ReadDog does not check whether the
         buffer size is sufficient.

4. unsigned long MyWriteDog(unsigned char Cascade, unsigned long Password,short int Address,short int Bytes,
		unsigned char* pData)
   Input parameter: DogCascade, DogAddr, DogBytes, pData, DogPassword
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Writes data to the hardware Dog. Carries out the same operation as ReadDog,
      except that the data flow direction is different.

*Caution:
     The last 4 bytes are used to define the conversion algorithm. Therefore, better
     not use these 4 bytes unless you want to change the algorithm.

5. unsigned long MyDogConvert(unsigned char Cascade, short int DataLen,unsigned char* pDataIn,unsigned long *pResult)
   Input parameter: DogCascade, DogBytes, pData
   Output parameter: DogResult
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Transfers data to MicroDog.  The hardware Dog converts the data 
       and returns the converted result Dogresult as a 32-bit integer.  DogBytes indicates
       the number of bytes of the date, which DogData points to, being converted. 
       The conversion algorithm can be specified by the developer.  The last 4 bytes 
       of memory affects the conversion algorithm.  The 196th byte is used to 
       specify the algorithm.  Therefore, a developer can define 256 kinds of algorithms. 
       The algorithm descriptors are made up of the 197th, 198th and 199th byte, so it have 
       a maximum of 16,777,215 different combinations.
         

6. unsigned long MyGetCurrentNo(unsigned char Cascade, unsigned long *pResult)   Input Parameter: DogCascade, pData
   Output parameter: DogData
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads the Manufacturing code of the hardware Dog.Some of the hardware
             Dogs may have the same ID, but every hardware Dog has its unique
             Manufacturing code. The Manufacturing code can help developers manage
             user accounts.
             The Manufacturing code is 4 bytes.

============
Error code
============
   Refer to ERRCODE.TXT in the root of the installation directory for detailed 
   information about error codes.

=========
Cautions
=========
1. When you write data to the Dog, changing the last 4 bytes of the 
   MicroDog memory will affect the result of function DogConvert().


2. If you want to run the protected application in other computer in Linux 2.4, you should install
   the corresponding device driver for the hardware Dog. Please go into driver directory and first execute
   "make",then execute "make install" to install device driver. 

3. If you want to release your protected programs to your end-users, please include
   the device drivers and installing tool in the DRIVER folder in your SETUP process,
   and execute installing the device drivers for the Dog first. 



=================
Technical Support
=================

    For contact address, please see Address.txt under installation path.