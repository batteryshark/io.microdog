//---------------------------------------------------------------------------

#include <clx.h>

#pragma hdrstop

#include "Unit1.h"
#include "gsmh.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.xfm"
TForm1 *Form1;
short int DogBytes,DogAddr;
unsigned long DogPassword;

unsigned long DogResult;

unsigned char DogCascade;

void * DogData;






//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{


}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonDogCheckClick(TObject *Sender)
{
  unsigned long ulRetCode;
  AnsiString str;
  DogCascade = 0;
  ulRetCode=DogCheck();
  if (ulRetCode == 0)
  {
        str.cat_printf("DogCheck succeeded!");
        LabelResult->Caption=str;
  }
  else
  {

        str.cat_printf("DogCheck failed!\nThe error code is:%u",ulRetCode);
        LabelResult->Caption=str;

  }

}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonWriteDogClick(TObject *Sender)
{
  unsigned char ucData[20];
  unsigned long ulRetCode;
  AnsiString str;
  DogCascade = 0;
  DogPassword = 0;
  DogAddr = 0;
  DogBytes =20;
  DogData = ucData;

  for (int i=0;i<20;i++)
  {
        ucData[i]= 65+i;
  }

  ulRetCode=WriteDog();

  if (ulRetCode == 0)
  {
        str.cat_printf("WriteDog succeeded!");
        LabelResult->Caption=str;

  }
  else
  {

        str.cat_printf("WriteDog failed!\nThe error code is:%u",ulRetCode);
        LabelResult->Caption=str;

  }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonGetCurrentNoClick(TObject *Sender)
{
  unsigned long ulRetCode;
  unsigned long ulCurrentNumber;
  AnsiString str;
  DogCascade = 0;
  ulRetCode=GetCurrentNo();
  if (ulRetCode == 0)
  {
        str.cat_printf("GetCurrentNo succeeded!\nThe current number is:%u",ulCurrentNumber);
        LabelResult->Caption=str;
  }
  else
  {
        str.cat_printf("GetCurrentNo failed!\nThe error code is:%u",ulRetCode);
        LabelResult->Caption=str;
  }


}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonDogConvertClick(TObject *Sender)
{
  unsigned char ucData[20];
  unsigned long ulRetCode;
  AnsiString str;

  DogCascade = 0;
  DogBytes =20;
  DogData = ucData;

  for (int i=0;i<20;i++)
  {
        ucData[i]= 65+i;
  }

  ulRetCode=DogConvert();

  if (ulRetCode == 0)
  {

        str.cat_printf("DogConvert succeeded!\nThe result is:%u",DogResult);
        LabelResult->Caption=str;

  }
  else
  {

        str.cat_printf("DogConvert failed!\nThe error code is:%u",ulRetCode);
        LabelResult->Caption=str;
  }


}
//---------------------------------------------------------------------------

void __fastcall TForm1::ReadDogBtClick(TObject *Sender)
{
  unsigned char ucData[40];
  unsigned long ulRetCode;
  AnsiString str;

  DogCascade = 0;
  DogPassword = 0;
  DogAddr = 0;
  DogBytes =20;
  DogData = ucData;
  ulRetCode=ReadDog();

  if (ulRetCode == 0)
  {
        str.cat_printf("ReadDog succeeded!\nThe Read data is:\n");
        for(int i=0;i<20;i++)
        {
             str.cat_printf("%c",ucData[i]);
        }
  }
  else
  {

        str.cat_printf("ReadDog failed!\nThe error code is:%u",ulRetCode);

  }
  LabelResult->Caption=str;
}
//---------------------------------------------------------------------------

