                             -------------------------------------------------------
	                 MicroDog 32-bit LINUX Application
                         API Guide to Kylix CBuilder modules
                     -------------------------------------------------------

                   Copyright (c) 2003, Rainbow China Co., Ltd.


  This module is used for Kylix CBuilder language in Linux and also suitable for protecting C /C++ application.

The interface file mhlinuxc.o is the same with the file in the C module,please refer to the readme document in the c mdoudles.

=========
File list
=========
   File Name        Description
   ------------     -----------------------------
   readme-eng.txt   	This guide
   CBuilder         	The sample module directory

In the CBuilder,includes the following files:

	gsmh.h          Interface head file
	mhlinuxc.o      Interface file
	Project1.bpr	C++Builder project file
	project1.cpp    project source file
	Project1.res    Project resouce file
	Unit1.cpp       project source file
	Unit1.ddp       project source file 
	Unit1.h         project head file
	Unit1.xfm       project configuration file 

==============================
Tested Environment
==============================
Based in the Linux Kernel 2.2 and 2.4. the Kylix 3 has been tested.


=======================
Method
=======================
add the encryption interface file(mhlinuxc.o) into the project from ��Project Manage�� menu


============
Error code
============
   Refer to ERRCODE.TXT in the root of the installation directory for detailed 
   information about error codes.

=========
Cautions
=========
1. When you write data to the Dog, changing the last 4 bytes of the 
   MicroDog memory will affect the result of function DogConvert().


2. If you want to run the protected application in other computer in Linux 2.4, you should install
   the corresponding device driver for the hardware Dog. Please go into driver directory and first execute
   "make",then execute "make install" to install device driver. 

3. If you want to release your protected programs to your end-users, please include
   the device drivers and installing tool in the DRIVER folder in your SETUP process,
   and execute installing the device drivers for the Dog first. 



=================
Technical Support
=================
    For technical issues, please contact Rainbow China Co., Ltd. or its distributors 
immediately. 
    For contact address, please see Address.txt under installation path.