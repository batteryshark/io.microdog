			      --------------------------------------
                              Utilities Guide for MicroDog  Linux 
                              --------------------------------------
                               Copyright (c) 2003, Rainbow China Co., Ltd.

-----------
DOGEDT.exe
-----------
DOGEDT.exe Windows application, it can be used for editorial work for MicroDog Linux
hardware Dog(Parallel Dog or UsbDog). 

Notice:
       1.the last four bytes in the memory of Hardware Dog is the factors of DogConvert.
         If you change these four factors,the result of DogConvert will be changed.
       2.The default password is 0, if you change the Password,you must keep it well.
         If you forget the password ,you must send hardware dog back to us.
       3.The Data must not exceed 60 bytes,and the result of DogConvert is long int.

----------
GETVER
---------- 
GETVER.EXE is a utility for Microdog Linux. It can be used to get the program 
part-number and version.

syntax:
           ./getver <file name>


