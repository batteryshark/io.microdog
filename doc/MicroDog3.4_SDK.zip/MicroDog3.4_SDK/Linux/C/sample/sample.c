#include "gsmh.h"
#include <stdio.h>
#include <stdlib.h>



short int DogBytes;
short int DogAddr;
unsigned long DogPassword;
unsigned long DogResult;
unsigned char DogCascade;
void *DogData;


int main()
{
     unsigned long retcode; 
     char s[100];
     int i,j;  
     unsigned char tmp[200];
     unsigned long CurrentNo;

     DogCascade=0;
     DogPassword=0;
     printf("The sample program of using linux c api\n");
     printf("Copyright(C) 2003 Rainbow China Co.,Ltd\n");
     //detect degugging ,ptrace can not be called more than once
     if (ptrace(0,0,1,0)<0)
     {
         printf("DEBUGGING...  Bye!!!\n");
         return;
     }
     //end detect debugging
     retcode =DogCheck();
     if (retcode != 0)
     {
 	  printf("DogCheck failed! Error code is %d\n",retcode);
     }
     else
     {
 	printf("DogCheck succeeded!\n");
     }
     DogAddr = 50;
     DogBytes = 50;
     for(i=0;i<50;i++)
	{
		tmp[i]=0x99;
	}
     DogData = &tmp[0];
     retcode = WriteDog();
     if (retcode != 0)
     {
          printf("WriteDog failed! Error code is %d\n",retcode);
     }
     else
     {
          printf("WriteDog succeeded!\n");
     }
    DogData=&tmp[0];
    DogBytes=6;
    for (i=0;i<6;i++)
    {
        tmp[i]='0'+i;
    }
    retcode = DogConvert();
     if (retcode != 0)
     {
          printf("DogConvert failed! Error code is %d\n",retcode);
     }
     else
     {
          printf("DogConvert succeeded!\n");
          printf("DogConvert string is %c%c%c%c%c%c\n",tmp[0],tmp[1],tmp[2],tmp[3],tmp[4],tmp[5]);
          printf("DogConvert result is %u\n",DogResult);
     }

     DogData = &tmp[0];
     DogAddr = 0;
     DogBytes = 200;
     retcode = ReadDog();
     if (retcode != 0)
     {
          printf("ReadDog failed! Error code is %d\n",retcode);
     }
     else
     {
          printf("ReadDog succeeded!\n ");
 	 for(i=0;i<78;i++)
		printf("-");
		printf("\n");
	 for(i=0;i<10;i++)
		{
		  printf("%03d: ",i*20);
		  for(j=0;j<10;j++)
		  {
		   sprintf(s,"%02x%02x ",tmp[i*20+j*2],tmp[i*20+j*2+1]);
		   printf(s);
		  }	
		  printf("\n");
		}
	 for(i=0;i<78;i++)
	   printf("-");
	   printf("\n");
	  
    }
     DogData = &CurrentNo;
     retcode = GetCurrentNo();
     if (retcode != 0)
     {
          printf("GetCurrentNo failed! Error code is %d\n",retcode);
     }
     else
     {
          printf("GetCurrentNo succeeded! %u\n ",CurrentNo);
     }

   
}
