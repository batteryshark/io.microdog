 		  -------------------------------------------------------
	                    MicroDog Suite 32-bit WINDOWS Application
                                  Guide to ActiveX Control
                  -------------------------------------------------------

                              Copyright (C) 2003 Rainbow China Co., Ltd.

     MicroDog Suite combines all advantages and features of USBDog(UMC type) and Parallel 
Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel Dog(PMH type) 
which are compatible with each other.The protected applications can use either USBDog or 
Parallel Dog when running in the operating systems such as Windows 98, Windows ME,Windows 2000 
and Windows XP. The current version of MicroDog can support only Parallel dog when the application
is running in Windows NT 4.0 , so please contact us if you need to operate USBDog in that environment.
   
=========
Functions
=========
  MicroDog Suite contains two Hardware Dogs (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, writing 
data into and reading data from the memory, changing data, checking the current manufacturing 
number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six functions specified above will secure your software products from any unauthorized 
use.  For detailed description of protection strategy, please read The Developer's Manual .

=========
File list
=========
   README-ENG.TXT        This file
   setup.exe             Appliaction to setup and register ActiveX Control
   UMHControl.ocx        ActiveX Control  
   VC         <dir>      VC example program using ActiveX Control
   VB         <dir>      VB example program using ActiveX Control
   JavaScript <dir>      Homepage using AcitveX Control in javascript language 
   VBScript   <dir>      Homepage using AcitveX Control in vbscript language 

===========================================
Introduction to AcitveX Control programming
===========================================
Under 32-bit WINDOWS environment, the Hardware Dog AcitveX Control can be made 
through MS Visual C++ or other compiler. The approach is to call the WIN32 C 
standard API (mhwin32c.obj) in the AcitveX Control, so as to operate the Hardware Dog. 
Thus, the applications calling this AcitveX Control will be able to judge whether the 
proper Hardware Dog exists through the result of the operation. The application is then
protected. See below the illustration for the calling to AcitveX Control by an application:
	  
 Application     AcitveX        Win32 API         
 ------------    ---------      ---------        
      |   call    |    call       | communication    |
      |           |               | with the Dog     |
      |=========> | ============> | ==============>  | ------------
      |           |               |                  | Hardware Dog
      |<========= | <============ | <==============  | ------------


One important thing is that, because the AcitveX Control is separated from the protected 
application, the calling interface of AcitveX Control functions is then exposed to hacker
(because of the nature of AcitveX Control). Here comes the importance for the hiding of 
ActiveX Control function calling.  Therefore, we strongly recommend you to use static API 
Library (such as C API) to protect your application other than AcitveX Control in general. 
For your benefits, you should follow the above principles to develop you own AcitveX Control
by calling C/C++ module. 

===============================
 Introduction to UMHControl.ocx
===============================
1. UMHControl.ocx is actually calling the WIN32C API module to operate the hardware Dog. 
   
2. The ActiveX Control defines seven properties,they are

        short bytes;	//Byte number of operation
	short addr;	//Beginning address
	short cas;	//Cascade number
	short command;	//Command code
	long password;  //Access password
	long result;	//Conversion result
	BSTR memdata;	//I/O data buffer

3. The ActiveX Control defines one method:
        long OperateDog(); //operate the hardware Dog
	Return value: Returns zero if successful; returns an error code if the function fails.

4. The property command is a command code, defined as following:
    DogCheck	   1	Check the hardware Dog
    ReadDog	   2	Read data from the Dog
    WriteDog	   3	Write data to the Dog
    DogConvert	   4	Convert a string into a 32-bit integer
    GetCurrentNo   5	Get current number of the hardware Dog
    DisableShare   6	Disable share
    SetDogCascade  7	Set Cascade for RC-MH dog
    SetPassword    8    Set password of hardware dog

5.  Please run setup.exe to setup and register ActiveX Control.

6.  Please consult the source code of example application for detailed infomation. 

========
Cautions
========
1. One important thing is that, because the AcitveX Control is separated from the protected
   application, the calling interface of AcitveX Control functions is then exposed to hacker
   (because of the nature of AcitveX Control). Here comes the importance for the hiding of 
   ActiveX Control function calling.  Therefore, we strongly recommend you to use static API
   Library (such as C API) to protect your application other than AcitveX Control in general. 
   For your benefits, you should follow the above principles to develop you own AcitveX Control
   by calling C/C++ module. 
2. The protected applications can use either USBDog or MicroDog when running in the operating
   systems such as Windows 98 ,Windows ME ,Windows 2000 and Windows XP. The current version of 
   Microdog can support only MicroDog when the application is running in Windows NT 4.0, so please
   contact us if you need to operate USBDog in that environment.

==========
Error code
==========
   Refer to ERRCODE-ENG.TXT in the root of the installation directory for detailed 
   information about error codes.

=================
Technical Support
=================
    For technical issues, please contact Rainbow China Co., Ltd. or its distributors 
immediately. 
    For contact address, please see Address.txt under installation path.
