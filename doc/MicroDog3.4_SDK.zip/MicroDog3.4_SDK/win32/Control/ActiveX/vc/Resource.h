//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by test.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TEST_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDC_UMHCONTROLCTRL1             1000
#define IDC_BUTTON_READ                 1002
#define IDC_BUTTON_WRITE                1003
#define IDC_BUTTON_CHECK                1004
#define IDC_BUTTON_CONVERT              1005
#define IDC_BUTTON_SETPASSWORD          1006
#define IDC_BUTTON_GETCURNO             1007
#define IDC_BUTTON_DISABLESHARE         1008
#define IDC_STATIC_TEXT                 1009
#define IDC_BUTTON_SETDOGCASCADE        1013
#define IDC_PASSWORD                    1015
#define IDC_NEWPASSWORD                 1016
#define IDC_CASCADE                     1017
#define IDC_NEWCASCADE                  1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
