// testDlg.cpp : implementation file
//

#include "stdafx.h"
#include "test.h"
#include "testDlg.h"
#include "umhcontrol.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestDlg dialog

CTestDlg::CTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestDlg)
	m_text = _T("");
	m_dwPassword = 0;
	m_dwNewPassword = 0;
	m_nCascade = 0;
	m_nNewCascade = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestDlg)
	DDX_Text(pDX, IDC_STATIC_TEXT, m_text);
	DDX_Control(pDX, IDC_UMHCONTROLCTRL1, m_umh);
	DDX_Text(pDX, IDC_PASSWORD, m_dwPassword);
	DDV_MinMaxDWord(pDX, m_dwPassword, 0, 4294967295);
	DDX_Text(pDX, IDC_NEWPASSWORD, m_dwNewPassword);
	DDV_MinMaxDWord(pDX, m_dwNewPassword, 0, 4294967295);
	DDX_Text(pDX, IDC_CASCADE, m_nCascade);
	DDV_MinMaxInt(pDX, m_nCascade, 0, 15);
	DDX_Text(pDX, IDC_NEWCASCADE, m_nNewCascade);
	DDV_MinMaxInt(pDX, m_nNewCascade, 0, 15);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestDlg, CDialog)
	//{{AFX_MSG_MAP(CTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_READ, OnButtonRead)
	ON_BN_CLICKED(IDC_BUTTON_WRITE, OnButtonWrite)
	ON_BN_CLICKED(IDC_BUTTON_CHECK, OnButtonCheck)
	ON_BN_CLICKED(IDC_BUTTON_CONVERT, OnButtonConvert)
	ON_BN_CLICKED(IDC_BUTTON_GETCURNO, OnButtonGetcurno)
	ON_BN_CLICKED(IDC_BUTTON_DISABLESHARE, OnButtonDisableshare)
	ON_BN_CLICKED(IDC_BUTTON_SETDOGCASCADE, OnButtonSetDogCascade)
	ON_BN_CLICKED(IDC_BUTTON_SETPASSWORD, OnButtonSetPassword)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestDlg message handlers

BOOL CTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTestDlg::OnOK() 
{
	// TODO: Add extra validation here

	CDialog::OnOK();
}

void CTestDlg::OnButtonRead() 
{

	// TODO: Add your control notification handler code here
	//read
	UpdateData(true);
	CString data1;
	m_umh.SetAddr(0);
	m_umh.SetBytes(10);
	m_umh.SetCas(m_nCascade);
	m_umh.SetPassword(m_dwPassword);
	m_umh.SetCommand(2);
	unsigned long re=m_umh.OperateDog();
	if(!re)
	{
 		data1=m_umh.GetMemdata();
		m_text.Format("%s%s","Read dog succeeded!\nThe dog data is:",data1);
	}
	else
	    m_text.Format("%s%ld","Read dog failed!\nThe error code is:",re);
    UpdateData(false);
	
}

void CTestDlg::OnButtonWrite() 
{
	// TODO: Add your control notification handler code here
	//write
	UpdateData(true);
	CString data="1234567890";
	m_umh.SetAddr(0);
	m_umh.SetBytes(10);
	m_umh.SetCas(m_nCascade);
	m_umh.SetPassword(m_dwPassword);
	m_umh.SetCommand(3);
	m_umh.SetMemdata((LPCTSTR)data);  
	unsigned long re=m_umh.OperateDog();
	if(!re)
	{
 		m_text.Format("%s%s","Write dog succeeded!\nThe dog data is:",data);
	}
	else
	    m_text.Format("%s%ld","Write dog failed!\nThe error code is:",re);
    UpdateData(false);
	
}

void CTestDlg::OnButtonCheck() 
{
	
	// TODO: Add your control notification handler code here
	//dogcheck
	UpdateData(true);
	m_umh.SetCas(m_nCascade);
	m_umh.SetPassword(m_dwPassword);
	m_umh.SetCommand(1);
	unsigned long re=m_umh.OperateDog();
	if(!re)
	{
 		m_text.Format("%s","Check dog succeeded!");
	}
	else
	    m_text.Format("%s%ld","Check dog failed!\nThe error code is:",re);
    UpdateData(false);

}

void CTestDlg::OnButtonConvert() 
{

	// TODO: Add your control notification handler code here
	//dogconvert 
	UpdateData(true);
	CString dataconvert="112233";
	unsigned long result;
	m_umh.SetCas(m_nCascade);
	m_umh.SetPassword(m_dwPassword);
	m_umh.SetCommand(4); 
	m_umh.SetBytes(6);
	m_umh.SetMemdata((LPCTSTR)dataconvert);  
    unsigned long re=m_umh.OperateDog();
	if(!re)
	{
		result=m_umh.GetResult();
		m_text.Format("%s%u%s","Dog convert succeeded!\nThe result is:",result,".");
	}
	else
	    m_text.Format("%s%ld","Dog convert failed!\nThe error code is:",re);
	UpdateData(false);
	
}

void CTestDlg::OnButtonGetcurno() 
{
	// TODO: Add your control notification handler code here
		//getcurrent
	UpdateData(true);
	CString datacur;
	unsigned long cur;
	m_umh.SetCas(m_nCascade);
	m_umh.SetPassword(m_dwPassword);
	m_umh.SetCommand(5);
	m_umh.SetMemdata((LPCTSTR)datacur);  
	unsigned long re=m_umh.OperateDog();
	if(!re)
	{
 		cur=m_umh.GetResult();
		m_text.Format("%s%u%s","Get CurrentNo succeeded!\nThe CurrentNo is:",cur,".");
	}	
	else
		m_text.Format("%s%ld","Get CurrentNo failed!\n The error code is:",re);
	UpdateData(false);

}

void CTestDlg::OnButtonDisableshare() 
{

	// TODO: Add your control notification handler code here
	//disableshare
	UpdateData(true);
	m_umh.SetCommand(6);
	m_umh.SetCas(m_nCascade);
	m_umh.SetPassword(m_dwPassword);
	unsigned long re=m_umh.OperateDog();
	if(!re)
	{
 		m_text.Format("%s","Disable share succeeded!");
	}
	else
	    m_text.Format("%s%ld","Disable share failed!\nThe error code is:",re);
    UpdateData(false);

	
}

void CTestDlg::OnButtonSetDogCascade() 
{
	// TODO: Add your control notification handler code here
	//SetDogCascade
	UpdateData(true);
	m_umh.SetCas(m_nCascade);
	m_umh.SetPassword(m_dwPassword); 
    m_umh.SetResult((long)m_nNewCascade);//new cascade
	m_umh.SetCommand(7);//command for SetDogCascade
	unsigned long re=m_umh.OperateDog();
	if(!re)
	{
 		m_text.Format("%s%d","SetDogCascade succeeded!\nThe cascade is:",m_nNewCascade);
	}
	else
	    m_text.Format("%s%ld","SetDogCascade failed!\nThe error code is:",re);
    UpdateData(false);
	
}

void CTestDlg::OnButtonSetPassword() 
{
	// TODO: Add your control notification handler code here
	//SetPassword
	UpdateData(true);
	m_umh.SetCas(m_nCascade);
	m_umh.SetPassword(m_dwPassword); 
    m_umh.SetResult((long)m_dwNewPassword);//new password
	m_umh.SetCommand(8);//command for SetPassword
	unsigned long re=m_umh.OperateDog();
	if(!re)
	{
 		m_text.Format("%s%d","SetPassword succeeded!\nThe password is:",m_dwNewPassword);
	}
	else
	    m_text.Format("%s%ld","SetPassword failed!\nThe error code is:",re);
    UpdateData(false);
}
