// VCSampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "VCSample.h"
#include "VCSampleDlg.h"
#include "rc6.h"
#include "md5.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

typedef struct _UMH_DLL_PARA
    {
    	BYTE	Command;
    	BYTE	Cascade;
    	WORD	DogAddr;
    	WORD	DogBytes;
    	DWORD	DogPassword;
    	DWORD	DogResult;
    	BYTE	DogData[200];
    }UMH_DLL_PARA,  far * PUMH_DLL_PARA;

UMH_DLL_PARA umhp;

typedef unsigned long ( * RC_UMHDOG)(PUMH_DLL_PARA pmdp);
typedef unsigned long ( * RCDOG_AUTHDOG)(int,PUCHAR,int,PUCHAR,UCHAR,ULONG);


HINSTANCE mlib;
RCDOG_AUTHDOG RC_AuthDog=NULL;
RC_UMHDOG RC_UMHDog=NULL;

/////////////////////////////////////////////////////////////////////////////
// CVCSampleDlg dialog

CVCSampleDlg::CVCSampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVCSampleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CVCSampleDlg)
	m_info = _T("");
	m_password = 0;
	m_cascade = 0;
	m_AuthKey = _T("abcdef");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CVCSampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVCSampleDlg)
	DDX_Text(pDX, IDC_STATIC_INFO, m_info);
	DDX_Text(pDX, IDC_EDIT_PASSWORD, m_password);
	DDX_Text(pDX, IDC_EDIT_DOGCASCADE, m_cascade);
	DDX_Text(pDX, IDC_EDITAUTHKEY, m_AuthKey);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CVCSampleDlg, CDialog)
	//{{AFX_MSG_MAP(CVCSampleDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_CONVERT, OnButtonConvert)
	ON_BN_CLICKED(IDC_BUTTON_DISABLESHARE, OnButtonDisableshare)
	ON_BN_CLICKED(IDC_BUTTON_DOGCHECK, OnButtonDogcheck)
	ON_BN_CLICKED(IDC_BUTTON_GETCUR, OnButtonGetcur)
	ON_BN_CLICKED(IDC_BUTTON_READDOG, OnButtonReaddog)
	ON_BN_CLICKED(IDC_BUTTON_WRITEDOG, OnButtonWritedog)
	ON_BN_CLICKED(IDC_BUTTON_AUTHDOG, OnButtonAuthdog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVCSampleDlg message handlers

BOOL CVCSampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	mlib = LoadLibrary(TEXT("win32hdll.dll"));
	if(mlib != NULL)
	{
		RC_UMHDog =(RC_UMHDOG)::GetProcAddress((HMODULE)mlib,"RC_UMHDog");
		RC_AuthDog=(RCDOG_AUTHDOG)::GetProcAddress((HMODULE)mlib,"RCDog_AuthDog");
	}
	else
	{
		::MessageBox(NULL,"WIN32HDLL.DLL not found!","Error",MB_OK);
		CDialog::OnCancel();
		return TRUE;

	}

	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CVCSampleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CVCSampleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CVCSampleDlg::OnButtonConvert() 
{
	// TODO: Add your control notification handler code here
	UpdateData();

	char ConvertData[]="UMH Dog";
	DWORD dwStatus;
	char Message[100];

	umhp.Command = 4;
	umhp.Cascade = m_cascade;
	umhp.DogBytes = 8;
	umhp.DogPassword = m_password;
	strcpy((char *)umhp.DogData , (char *)ConvertData);
	
	dwStatus = RC_UMHDog(&umhp);
	if (dwStatus==0)
	{
		wsprintf (Message, "Dog convert succeeded.\rConvert string = '%s'\rResult = %ld   (0x%lX)",ConvertData,umhp.DogResult,umhp.DogResult);
	}
	else
	{
		wsprintf (Message, "Dog convert failed.\rError code = %ld", dwStatus);
	}
	m_info=Message;
	UpdateData(false);
}

void CVCSampleDlg::OnButtonDisableshare() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	DWORD dwStatus;
	char Message[100];

	umhp.Command = 6;
	umhp.Cascade = m_cascade;
	dwStatus = RC_UMHDog(&umhp);
	if (dwStatus==0)
	{
		wsprintf (Message, "Disable share succeeded.");
	}
	else
	{
		wsprintf (Message, "Disable failed.\rError code = %ld", dwStatus);
	}
	m_info=Message;
	UpdateData(false);
	
}

void CVCSampleDlg::OnButtonDogcheck() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	DWORD dwStatus;
	char Message[100];

	umhp.Command = 1;
	umhp.Cascade = m_cascade;
	umhp.DogPassword =m_password;
	dwStatus = RC_UMHDog(&umhp);
	if (dwStatus==0)  
		strcpy(Message,"Dog check succeeded.");
	else 
		wsprintf ( Message, "Dog check failed.\rError code = %ld",dwStatus);
	m_info=Message;
	UpdateData(false);
	
	
}

void CVCSampleDlg::OnButtonGetcur() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	DWORD dwStatus;
	char Message[100];
	DWORD CurrentNo;
	umhp.Command = 5;
	umhp.Cascade = m_cascade;
	dwStatus = RC_UMHDog(&umhp);
	CurrentNo = *(DWORD *)umhp.DogData;
	if (dwStatus==0)
	{
		wsprintf (Message, "Get current number succeeded.\rCurrent number = %ld",CurrentNo, CurrentNo);
	}
	else
	{
		wsprintf (Message, "Get current number failed.\rError code = %ld", dwStatus);
	}

	m_info=Message;
	UpdateData(false);

}

void CVCSampleDlg::OnButtonReaddog() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	DWORD dwStatus;
	DWORD dwData ;
	WORD  wData ; 
	float fData;
	char szData[10] ;
	char Message[300],msg[100];

	Message[0] = 0;

	umhp.DogPassword =m_password;
	umhp.Cascade = m_cascade;

	umhp.Command = 2;
	umhp.DogAddr = 0;
	umhp.DogBytes = 8;
	dwStatus = RC_UMHDog(&umhp);
	strcpy((char *)szData ,(char *)umhp.DogData);
	szData[8] = 0;
	if (dwStatus==0)
	{
		wsprintf (msg, "Read string succeeded.\rRead: \"%s\"  from address: %d\r\r",szData,umhp.DogAddr);
	}
	else
	{
		wsprintf (msg, "Read string failed.\rError code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	umhp.DogBytes = 4;
	umhp.DogAddr = 10;
	dwStatus = RC_UMHDog(&umhp);
	dwData = *(DWORD *)umhp.DogData;
	if (dwStatus==0)
	{
		wsprintf (msg, "Read dword data succeeded.\rRead: %ld   from address: %d\r\r",dwData,umhp.DogAddr);
	}
	else
	{
		wsprintf (msg, "Read dword data failed.\rError code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	umhp.DogBytes = 2;
	umhp.DogAddr = 20;
	dwStatus = RC_UMHDog(&umhp);
	wData = *(WORD *)umhp.DogData ;
	if (dwStatus==0)
	{
		wsprintf (msg, "Read word data succeeded.\rRead: %d   from address: %d\r\r",wData,umhp.DogAddr);
	}
	else
	{
		wsprintf (msg, "Read word data failed.\rError code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	umhp.DogBytes = 4;
	umhp.DogAddr = 30;
	dwStatus = RC_UMHDog(&umhp);
	fData = *(float *)umhp.DogData;
	if (dwStatus==0)
	{
		sprintf (msg, "Read float data succeeded.\rRead: %e   from address: %d",fData,umhp.DogAddr);
	}
	else
	{
		wsprintf (msg, "Read float failed.\rError code = %ld", dwStatus);
	}
	strcat (Message,msg);
	
	m_info=Message;
	UpdateData(false);
}


void CVCSampleDlg::OnButtonWritedog() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	DWORD dwStatus;
	DWORD dwData = 12345678;
	WORD  wData = 1234;
	float fData = 3.1415926F;
	char szData[] = "MicroDog";
	char Message[300],msg[100];

	Message[0] = 0;

	umhp.Command = 3;
	umhp.DogPassword =m_password;
	umhp.Cascade = m_cascade;
	strcpy((char*)umhp.DogData ,(char*) szData);
	umhp.DogAddr = 0;
	umhp.DogBytes = 8;

	dwStatus = RC_UMHDog(&umhp);
	if (dwStatus==0)
	{
		wsprintf (msg, "Write string succeeded.\rWrite: \"%s\"  at address: %d\r\r",szData,umhp.DogAddr);
	}
	else
	{
		wsprintf (msg, "Write string failed.\rError code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	umhp.DogBytes = 4;
	*(DWORD *)umhp.DogData = dwData;
	umhp.DogAddr = 10;
	dwStatus = RC_UMHDog(&umhp);
	if (dwStatus==0)
	{
		wsprintf (msg, "Write DWORD data succeeded.\rWrite: %ld   at address: %d\r\r",dwData,umhp.DogAddr);
	}
	else
	{
		wsprintf (msg, "Write DWORD data failed.\rError code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);
	
	umhp.DogBytes = 2;
	*(WORD *)umhp.DogData = wData;
	umhp.DogAddr = 20;
	dwStatus = RC_UMHDog(&umhp);
	if (dwStatus==0)
	{
		wsprintf (msg, "Write word data succeeded.\rWrite: %d   at address: %d\r\r",wData,umhp.DogAddr);
	}
	else
	{
		wsprintf (msg, "Write word data failed.\rError code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	umhp.DogBytes = 4;
	*(float *)umhp.DogData = fData;
	umhp.DogAddr = 30;
	dwStatus = RC_UMHDog(&umhp);
	if (dwStatus==0)
	{
		sprintf (msg, "Write float data succeeded.\rWrite %e   at address: %d",fData,umhp.DogAddr);
	}
	else
	{
		wsprintf (msg, "Write float failed.\rError code = %ld", dwStatus);
	}
	strcat (Message,msg);
	
	m_info=Message;
	UpdateData(false);
}

void CVCSampleDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	if(mlib!=NULL)
	{
		::FreeLibrary(mlib);
	}
	CDialog::OnCancel();
}



ULONG CVCSampleDlg::CheckDll(PUCHAR Key,int KeyLen)
{
	
	RC6_KEY RC6Key;
	MD5  md5object;

	char Md5Key[12]={'1','3','2','4','3','5','4','6','5','7','6','8'};
	UCHAR    sign[16];      
	memset(sign,0,16);

	int RandomLen=16;
	HRESULT hresult;
	unsigned char Random[16];
	unsigned char DecryptRandom[16];
	unsigned char ReturnRandom[16];

	memset(Random,0,16);
	memset(DecryptRandom,0,16);
	memset(ReturnRandom,0,16);

	srand((unsigned)time(NULL));
	for (int i=0;i<8;i++)
	{
		*(int *)&Random[2*i]=rand();
	}

	hresult=RC_AuthDog(1,Random,RandomLen,ReturnRandom,m_cascade,m_password);
	if (hresult)
	{
		return hresult;
	}
	
	md5object.SetKey(Md5Key,12);
    md5object.Encrypt((PCHAR)Key,KeyLen,sign);
	GenerateKey(sign,&RC6Key);
	DecryptData(&RC6Key,ReturnRandom,16,DecryptRandom);

	for (int j=0;j<RandomLen;j++)
	{
		if (Random[j]!=DecryptRandom[j])
		{
			return 60007;
		}
	}
	return hresult;
}

void CVCSampleDlg::OnButtonAuthdog() 
{
	UpdateData();
	//the developer should change this value according to the string which is used to generate Dog Authorization Key
	char Message[100];
 	ULONG  re=CheckDll((unsigned char*)m_AuthKey.GetBuffer(m_AuthKey.GetLength()),m_AuthKey.GetLength());
	if(!re)
	{
		wsprintf (Message, "Authenication succeeded.");
	}
	else
	{
		wsprintf (Message, "Authenication failed.");
	}
	m_info=Message;
	UpdateData(false);

}
