
#include <windows.h>

#if !defined(MD5_HPP)
#define MD5_HPP

/*#ifndef ULONG
#define ULONG unsigned long
#endif

#ifndef PUCHAR
#define PUCHAR unsigned char *
#endif

#ifndef PCHAR
#define PCHAR  char *
#endif

#ifndef UCHAR
#define UCHAR unsigned char
#endif

#ifndef UINT
#define UINT unsigned int
#endif

#ifndef INT
#define INT int
#endif
*/


class MD5
{
private:
	ULONG	state[4];
	ULONG	count[2];
	UCHAR	buffer[64];
	ULONG	Key1[4], Key2[4];

	void	Init();
	void	Update(PUCHAR input, UINT inputLen);
	void	Final(unsigned char [16]);
	void	Transform(unsigned char [64]);
	void	Encode(unsigned char *, ULONG *, unsigned int);
	void	Decode(ULONG *, unsigned char *, unsigned int);
	void	Memcpy(PUCHAR, PUCHAR, unsigned int);
	void	Memset(PUCHAR, int, unsigned int);
public:
	MD5();
	void	SetKey(PCHAR key, int Length);
	void	HmacMd5(PCHAR text, INT text_len, PCHAR key, INT key_len, PUCHAR outBuf);
	void	HmacMd5(PCHAR text, INT text_len, PCHAR key, PUCHAR outBuf);
	void	HmacMd5(PCHAR text, PCHAR key, INT key_len, PUCHAR outBuf);
	void	HmacMd5(PCHAR text, PCHAR key, PUCHAR outBuf);
	void	HmacMd5(PCHAR text, INT text_len, PUCHAR outBuf);
	void	HmacMd5(PCHAR text, PUCHAR outBuf);
	void	Encrypt(PCHAR text, INT text_len, PUCHAR outBuf);
	void	Encrypt(PCHAR text, PUCHAR outBuf);
};

#endif
