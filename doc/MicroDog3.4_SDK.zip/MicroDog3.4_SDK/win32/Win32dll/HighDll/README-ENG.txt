
                 -------------------------------------------------------
                             MicroDog Suite 32-bit Windows Application
                                    Illustration of DLL sample 
                 -------------------------------------------------------
                         Copyright (c) 2003, Rainbow China Co., Ltd.
  
     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME,
Windows 2000 and Windows XP. The current version of MicroDog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate USBDog in that environment.


=========
Functions
=========
  MicroDog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.  Microdog Suite has six basic functions 
including verifying of the correct Hardware Dog, writing data into and reading data from the 
memory, changing data, checking the current manufacturing number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six basic functions specified above will secure your software products from any unauthorized use. 
For detailed description of protection strategy, please read The Developer's Manual .

=======================
Introduction to HighDll
=======================
   Add the function ULONG RCDog_AuthDog to authorize the dll first.Only If authorizing 
successfully other operations can be realized.The authorizing key is recorded in the key field
of the Dog.It occupy 16 bytes(DogBytes=16),Beginning address is 164(DogAddr=164).The key can
also be generated with special algorithm by developers.


==========================
The Process of authorizing
==========================
  Generating the random number used to authenticate.Transfer this random number to interface
of dll,check the dog in the dll and get the key from the key field in the dog.Return the 
result of encoding.Decode the result of encoding with the authentication key in the application
of developers(In VcSample, the default authentication key is "abcdef",you can change it in
DogEdt32.exe from mutiple modules memory edit property page).Compare the result of 
decoding with the random number.If they are same,the authentication process is successful. 


=========
File list
=========

   README-ENG.TXT  This file
   win32hdll.dll   The dll calling interface function
   VcSample<Dir>   Example for Visual C++ 


===============================
Introduction to DLL programming
===============================

  Under 32-bit WINDOWS environment, the MicroDog Dynamic Linking Library can be made 
through MS Visual C++ or Borland C++ compiler. The approach is to call the MHWIN32C.OBJ
standard API (in win32\WIN32C\Msvc folder) in the DLL, so as to operate the MicroDog. Thus, 
the applications calling this DLL will be able to judge whether the proper MicroDog exists 
through the result of the operation. The application is then protected. See below the 
illustration for the calling to dynamic linking library by an application:
	  
          Application            DLL              MHWIN32C.OBJ
	  -----------            ---              ------------
	       |
	       |----------------> |
				  |----------------> |
					      Operate the Dog 
				  |<-----------------|
	       |<-----------------|
	       |


==========================
API Functions introduction
==========================
1. This DLL is made by C language.It actually calling the WIN32C API module to 
   operate the hardware Dog. 
  
2. The sample DLL only defines 2 functions.
          
   ULONG RCDog_AuthDog(int isel,PUCHAR pRandom,int Len,PUCHAR pReturnRandom,UCHAR Cascade,ULONG Password)
   Function description:This function authorize the dll.
   Parameter:
	int isel:			Only support RC6 algorithm and must be 1 now.
	PUCHAR *pRandom:		Pointer to the 16-byte data
	int Len:			Data length
	PUCHAR * pReturnRandom:         Pointer to the encoded data
        UCHAR Cascade:                  Cascade
        ULONG Password:                 Password
	
	
   unsigned long RC_UMHDog(MH_DLL_PARA *)	
   Function description:This function realize the following operation: Readdog,Writedog,Chenkdog,
                        GetCurrentNo,DisableShare,Convert.
   Return 0 if successful,other values are code error.                           
   Parameter:
	typedef struct _MH_DLL_PARA
	{
		BYTE 	Command;	//Command code
		BYTE	Cascade;	//Cascade
		WORD	DogAddr;	//Beginning address
		WORD	DogBytes;	//Byte number of operation
		DWORD	DogPassword;	//Password
		DWORD   DogResult;	//Convert Result
		BYTE  	DogData[200];	//I/O data buffer
	} MH_DLL_PARA;

   The structure member Command is a command code, defined as following:
   DogCheck	   1	Check the hardware Dog
   ReadDog	   2	Read data from the Dog
   WriteDog	   3	Write data to the Dog
   DogConvert	   4	Convert a string into a 32-bit integer
   GetCurrentNo   5	Get ID number of the hardware Dog
   DisableShare   7	Disable share


============
Error code
============
   Refer to ERRCODE.TXT in the root of the installation directory for detailed 
   information about error codes.


=================
Technical support
=================
   If you have any technical problems, please contact Rainbow China Co., Ltd., 
   our branches, or our distributors.  
   Please Refer to  /Address.txt for the contact address.

