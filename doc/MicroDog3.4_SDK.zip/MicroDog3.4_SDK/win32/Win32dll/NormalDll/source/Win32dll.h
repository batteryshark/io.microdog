
//	File:GSMHYI.H
//	Author:HouHongWei  Change:zhenzhi
//	Date:1998-8-28  Change: 2002-1-9

//	Change: Link new mhwin32c.obj file			Jason Jiang		2002-8-30

#ifndef _GSMHYI_H_
#define _GSMHYI_H_

#ifndef ULONG
#define ULONG unsigned long
#endif

#ifndef HUINT
#define HUINT unsigned short
#endif

#ifndef UCHAR
#define UCHAR unsigned char
#endif

#ifndef WORD
#define WORD unsigned short
#endif

#define MHSTATUS ULONG

    typedef struct _MH_DLL_PARA
    {
    	WORD/*BYTE*/	Command;
    	WORD/*BYTE*/	DogCascade;
    	WORD	DogAddr;
    	WORD	DogBytes;
    	DWORD	DogPassword;
    	DWORD	DogResult;
        DWORD/*BYTE*/    NewPassword;
    	BYTE	DogData[200];		
    }MH_DLL_PARA, * PMH_DLL_PARA;

//	unsigned long FAR PASCAL GS_MHDog(PMH_DLL_PARA pmdp);

#ifdef  __cplusplus
extern "C" {
#endif

/*Begin of my modification*/
//extern unsigned long PASCAL GS_MHDog(PMH_DLL_PARA);
/*End of my modification*/

short int DogBytes,DogAddr;
unsigned long DogPassword;
unsigned long NewPassword;//add by Zhengzh
unsigned long DogResult;
unsigned char DogCascade;
void * DogData;

extern unsigned long DogCheck(void);
extern unsigned long ReadDog(void);
extern unsigned long DogConvert(void);
extern unsigned long WriteDog(void);
extern unsigned long DisableShare(void);
extern unsigned long GetCurrentNo(void);
extern unsigned long SetDogCascade(void);//add by Zhengzh
extern unsigned long SetPassword(void);//add by Zhengzh

extern unsigned long GetDogExSize(void);
extern unsigned long ReadDogEx(void);
extern unsigned long WriteDogEx(void);


extern unsigned long DogEncrypt(void);
extern unsigned long DogDecrypt(void);
extern unsigned long DogHash(void);
extern unsigned long DogSign(void);
extern unsigned long SetCryptKey(void);
extern unsigned long SetSignKey(void);
#ifdef  __cplusplus
}
#endif
    
#endif
