//  Copyright (C) 2001 Rainbow China Co.,Ltd. All Rights Reserved.

#include "stdio.h"
#include "windows.h"
#include "win32dll.h"

#define MH_SUCCESS   0

//default Load DLL
BOOL PASCAL DllMain (HINSTANCE hDLL, DWORD dwReason, LPVOID lpReserved)
{                          
    return 1;
}

//---------------------------------------------------------------------
//Routine Description:
//	the DLL(Dynamic-Link Library) only one interface function
//
//	Return Value:
//		if the function succeeds, the return value is MH_SUCCESS
//		if the function fails, the return valuse is error code
//			For details on error code, see the ErrCode.txt
//
//Parameters:
//	pmdp 
//		Points to a MH_DLL_PARA structure. You must fill the 
//		structure with the appropriate command and data before 
//		passing it to the function, and it to be filled in by 
//		this function. 
//
//typedef struct _MH_DLL_PARA
//{
//	WORD 	Command;	
//	WORD	Cascade;	
//	WORD	DogAddr;	
//	WORD	DogBytes;
//	DWORD	DogPassword;
//	DWORD   DogResult;
//	BYTE  	DogData[200];
//} MH_DLL_PARA;
//
// Command code:
// 1 DogCheck
// 2 ReadDog
// 3 WriteDog
// 4 DogConvert
// 5 GetCurrentNo
// 6 EnableShare
// 7 DisableShare
// 8 SetDogCascade
// 9 SetPassword
// 10 GetDogExSize
// 11 ReadDogEx
// 12 WriteDogEx
// 13 SetCryptKey
// 14 SetSignKey
// 15 DogEncrypt
// 16 DogDecrypt
// 17 DogHash
// 18 DogSign
//----------------------------------------------------------------------
unsigned long PASCAL GS_MHDog(PMH_DLL_PARA pmdp)
{            
	MHSTATUS resu;
	
	DogCascade = (unsigned char)pmdp->DogCascade;
	DogAddr = pmdp->DogAddr;
	DogBytes = pmdp->DogBytes;
	DogPassword = pmdp->DogPassword;
	DogResult = pmdp->DogResult;	
	NewPassword = pmdp->NewPassword;
	DogData = pmdp->DogData;
        
	switch(pmdp->Command)
	{
	case 1:          
		resu = DogCheck();
		break;
	case 2:
		resu = ReadDog();
		break;
	case 3:                           
		resu = WriteDog();
		break;
	case 4:
		resu = DogConvert();
		break;
	case 5:
		resu = GetCurrentNo();
		break;
	case 6:
		resu = MH_SUCCESS;
		break;
	case 7:
		resu = DisableShare();
		break;
    //Add by Zhengzh
	case 8:
		{        
		 resu = SetDogCascade();
         memcpy(&DogCascade,pmdp -> DogData,1);
		 break;	
		}
	case 9:
		{
		 resu = SetPassword();
         memcpy(&DogPassword,&(pmdp -> NewPassword),4);
		 break;
		}
		//Pwang modify begin 2003-06-11
		
	case 10:          
		resu = GetDogExSize();
		break;
	case 11:
		resu = ReadDogEx();
		break;
	case 12:                           
		resu = WriteDogEx();
		break;
	case 13:
		resu = SetCryptKey();
		break;
	case 14:
		resu = SetSignKey();
		break;
	case 15:
		resu = DogEncrypt();
		break;
	case 16:
		resu = DogDecrypt();
		break;
    case 17:
		resu = DogHash();
        break;	
	case 18:
	    resu = DogSign();
        break;
	default:
		resu = 60100; //not support this function
		//Pwang end 2003-06-11

	}
    pmdp->DogCascade = DogCascade;
    pmdp->DogPassword = DogPassword;
	pmdp->DogAddr = DogAddr;
	pmdp->DogResult = DogResult;
	
	return resu;
}

