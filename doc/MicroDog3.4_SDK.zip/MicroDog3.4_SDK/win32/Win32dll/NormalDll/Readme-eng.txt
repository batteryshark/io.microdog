
                     -------------------------------------------------------
                               MicroDog Suite 32-bit Windows Application
                                    Illustration of DLL sample 
                     -------------------------------------------------------
                         Copyright (c) 2003, Rainbow China Co., Ltd.
  
     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of MicroDog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

=========
Functions
=========
  MicroDog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, 
writing data into and reading data from the memory, changing data, checking the current 
manufacturing number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well. The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte descriptors 
can be selected for each algorithm, thus more than 16 million different algorithm descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is Activated.
  The six basic functions specified above will secure your software products from any unauthorized use. 
For detailed description of protection strategy, please read The Developer's Manual .


=========
File list
=========
   File name             Description
   --------------        -----------------------------------------------------
   README-ENG.TXT        Readme file   
   WIN32DLL.DLL          Sample of DLL provided
   VC <DIR>              Visual C++ demo program
   PB <DIR>              PowerBulid demo program
   VB <DIR>              VB demo program
   VF <DIR>              Visual Foxpro demo program
   VBA <DIR>             VBA demo program
   DELPHI <DIR>          DELPHI demo program
   INSTALLSHIELD <DIR>   INSTALLSHIELD demo program
   SOURCE <DIR>          DLL original code
   
   
  

===============================
Introduction to DLL programming
===============================

  Under 32-bit WINDOWS environment, the MicroDog Dynamic Linking Library can be made 
through MS Visual C++ or Borland C++ compiler. The approach is to call the MHWIN32C.OBJ 
standard API (in win32\WIN32C\Msvc folder) in the DLL, so as to operate the MicroDog. Thus, 
the applications calling this DLL will be able to judge whether the proper MicroDog exists 
through the result of the operation. The application is then protected. See below the 
illustration for the calling to dynamic linking library by an application:
	  
          Application            DLL              MHWIN32C.OBJ
	  -----------            ---              ------------
	       |
	       |----------------> |
				  |----------------> |
					      Operate the Dog 
				  |<-----------------|
	       |<-----------------|
	       |


  One important thing is that, because the DLL is separated from the protected application, 
the calling interfaceof DLL functions is then exposed to hacker(because of the nature of DLL). 
Here comes the importance for the hiding of DLLfunctions' name and function calling. Therefore, 
we strongly recommend you to use static API Library (such as C API) to protect your application 
other than DLL in general. If DLL method must be used, and the strength of the protection comes 
from the complexity of your own DLL, the software developer must make the DLL as complicated as 
possible. The functions' calling interface of DLL must be hidden well, and the functions' names 
in the DLL should not be relative with the Dog operation.
 The sequence of parameters passing should also be baffling for hackers, and the 
dog operation functions should be merged with your own other DLL functions. For your benefits,
please remember that WIN32DLL.dll we provided is only a sample program.It should not be used for 
any kind of protection work.

==========================
API Functions introduction
==========================
1. WIN32DLL.DLL is made by C language.It actually calling the WIN32C API module to 
   operate the hardware Dog. 
  
2. The sample DLL only defines one function.
           WINAPI unsigned long GS_MHDog(MH_DLL_PARA *)	
   The return value is the result of command execution, 0 means success, Other is error code.

3. ALL data are defined in the structure MH_DLL_PARA:
    typedef struct _MH_DLL_PARA
    {
	WORD 	Command;	//Command code
	WORD	Cascade;	//Cascade number must be 0 in this version
	WORD	DogAddr;	//Beginning address
	WORD	DogBytes;	//Byte number of operation
	DWORD	DogPassword;	//Access password
	DWORD   DogResult;	//Conversion result
	DWORD   NewPassword     //NewPassword
        BYTE  	DogData[200];	//I/O data buffer
    } MH_DLL_PARA;

4. The structure member Command is a command code, defined as following:
    DogCheck	   1	Check the hardware Dog
    ReadDog	   2	Read data from the Dog
    WriteDog	   3	Write data to the Dog
    DogConvert	   4	Convert a string into a 32-bit integer
    GetCurrentNo   5	Get ID number of the hardware Dog
    EnableShare	   6    Enable share
    DisableShare   7	Disable share
    SetDogCascade   8   Set the Cascade      
    SetNewPassword  9   Set the new password

5. unsigned long DogCheck(void)
     Input parameter: DogCascade
     Output parameter: None
     Return value: Returns zero if successful; returns an error code if the function fails.
     Function: Checks whether the hardware Dog exists.  Only a Dog that has the same serial
               number as the OBJ file can be detected.This version supports the cascading 
               function of RC-MH dog of same serial number.The DogCascade in the USBdog must
               be 0.   


6. unsigned long ReadDog(void)
   Input parameter:  DogCascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter:  DogData
   Return value:     0 = operation succeeded. All others are error codes.
   Function: Reads data from the hardware Dog. The Dog contains a 200-byte nonvolatile 
             memory.  ReadDog reads data from the Dog memory beginning at the address 
             indicated by DogAddr.  The bytes number of the read data is indicated 
             by DogBytes.  The read data is stored in the space DogData points to.
             MicroDog verifies the DogPassword. DogPassword is the password for
             read/write operations stored on the hardware Dog.  It can be set by the 
             utility tool DOGEDT32.EXE in UTILITY folder or the SetPassword() function. 
             Applications must ensure enough space to buffer the data being read.ReadDog 
             does not check whether the buffer size is sufficient.


7. unsigned long WriteDog(void)
   Input parameter: DogCascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Writes data to the hardware Dog. Carries out the same operation as ReadDog,
             except that the data flow direction is different.

   *Caution:
         The last 4 bytes are used to define the conversion algorithm. Therefore, better
         not use these 4 bytes unless you want to change the algorithm.
  

8. unsigned long DogConvert(void)
   Input parameter: DogCascade, DogBytes, DogData
   Output parameter: DogResult
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Transfers data to MicroDog.  The hardware Dog converts the data 
             and returns the converted result Dogresult as a 32-bit integer. 
             DogBytes indicates the number of bytes of the date, which DogData 
             points to, being converted.The conversion algorithm can be specified
             by the developer.  
   *Caution: The last 4 bytes of memory affects the conversion 
             algorithm.  The 196th byte is used to specify the algorithm.  Therefore,
             a developer can define 256 kinds of algorithms. The algorithm descriptors
             are made up of the 197th, 198th and 199th byte, so it have a maximum of 
             16,777,215 different combinations.
               
          
9. unsigned long DisableShare(void)
   Input parameter: DogCascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Disable the hardware Dog's sharing ability.The parallel port hub is a kind of
             hardware share device that allows multiple copies of the protected program share
             the same Dog.Factory setting for share ability is Enable. You may call DisableShare   
             function to to prevent pirates from using a parallel port hub. So that only the      
             machine that has the Dog can run the protected program.DisableShare only affects the      
             functions ReadDog, WriteDog and DogConvert. 

   * Caution:
             Do not call on this function multiple times. It is designed to be called no more
             than once in an application.


10. unsigned long GetCurrentNo(void)
   Input Parameter: DogCascade, DogData
   Output parameter: DogData
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads the Manufacturing code of the hardware Dog.Some of the hardware
             Dogs may have the same ID, but every hardware Dog has its unique
             Manufacturing code. The Manufacturing code can help developers manage
             user accounts.
             The Manufacturing code is 4 bytes.

11. unsigned long SetDogCascade(void)
    Input parameter: DogCascade, DogPassword, DogData
    Output parameter: None
    Return value: Returns zero if successful; returns an error code if the function fails.
    Function: Set the DogCascade. The new cascade is put into the DogData.



12. unsigned long SetPassword(void)
   Input parameter: DogCascade, DogPassword, NewPassword
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Modifies the Dog password.DogPassword is the current password, and NewPassword
             is the one that would replace it.




=====
Note:
=====

1. For your benefits, you should create your own dll and add your own algorithms in it.

2. Both the USBdog and the Parallel Dog can be used to protect applications when
    running on Windows 98, Windows ME, Windows 2000 and Windows XP.

3. The data type of the DogPassword is 4-byte unsigned long.The range of it is 0-4294967295.
   But the max limit of range of data some programming language is as much as unsigned long,
   so their password will be limited to some extent. 


============
Error code
============
   Refer to ERRCODE.TXT in the root of the installation directory for detailed 
   information about error codes.


=================
Technical support
=================
   If you have any technical problems, please contact Rainbow China Co., Ltd., 
   our branches, or our distributors.  
   Please Refer to  /Address.txt for the contact address.


