/****************************************************************************

    PROGRAM: DOGDEMO

    PURPOSE: This application demonstrates how to invoke the dog's
             API for Win32 Application
             
    Copyright(C) 2001 Rainbow China Co.,Ltd. All Rights Reserved

****************************************************************************/

#include "windows.h"		    /* required for all Windows applications */
#include "string.h"
#include "stdio.h"
#include "dogdemo.h"                /* specific to this program              */
#include "resource.h"

#include "gsmh.h"


MH_DLL_PARA mhp;
PMH_DLL_PARA pmhp = &mhp;

HANDLE hInst;

/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

****************************************************************************/

int PASCAL WinMain(HANDLE hInstance, HANDLE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{

    DLGPROC lpDialogProc;
	HINSTANCE mlib;

	mlib = LoadLibrary(TEXT("win32dll.dll"));
	if(mlib != NULL)
	{
		GS_MHDog = GetProcAddress(mlib, "GS_MHDog");
	}
	else
	{
	  MessageBox(/*hInstance*/NULL,"WIN32DLL.DLL not found!","Error",MB_OK);
	  return 0;
	}

    hInst = hInstance;

    lpDialogProc = MakeProcInstance(DemoDlg, hInstance);

    DialogBox(hInstance,(LPCSTR)IDD_DIALOG, NULL,lpDialogProc);

    FreeProcInstance(lpDialogProc);

	//add by Zhengzh


    return 0;
}


/****************************************************************************

    FUNCTION: About(HWND, unsigned, WORD, LONG)

****************************************************************************/

BOOL FAR PASCAL About(HWND hDlg, unsigned message, WORD wParam, LONG lParam)
{
    switch (message)
    {
    case WM_INITDIALOG:
	CenterWindow(hDlg);
        return (TRUE);

    case WM_COMMAND:                  
	if (wParam == IDOK|| wParam == IDCANCEL) {
	   EndDialog(hDlg, TRUE);
	   return (TRUE);
	}
	break;
    }
    return (FALSE);                       
}




/****************************************************************************

    FUNCTION: OnDialogInit (HWND)

****************************************************************************/

void OnDialogInit(HWND hDlg)
{
	HMENU hSysMenu;

	hSysMenu = GetSystemMenu(hDlg,FALSE);
    AppendMenu (hSysMenu,MF_SEPARATOR,0,0);
    AppendMenu (hSysMenu,MF_STRING,IDM_ABOUT,"About...");
    RemoveMenu (hSysMenu,SC_SIZE,MF_BYCOMMAND);
    RemoveMenu (hSysMenu,SC_MAXIMIZE,MF_BYCOMMAND);
	RemoveMenu (hSysMenu,SC_MINIMIZE,MF_BYCOMMAND);

	SetDlgItemInt(hDlg,IDC_EDIT_PASSWORD,0,TRUE);
    //add by Zhengzh
    SetDlgItemInt(hDlg,IDC_EDIT_CASCADE,0,TRUE);
    SetDlgItemInt(hDlg,IDC_EDIT_NEWCASCADE,0,TRUE);
    SetDlgItemInt(hDlg,IDC_EDIT_NEWPASSWORD,0,TRUE);
	CenterWindow(hDlg);
    

}


/****************************************************************************

    FUNCTION: OnButtonWriteClicked (HWND)

****************************************************************************/

void OnButtonCheck(HWND hDlg) 
{
	DWORD dwStatus;
	char Message[100];
	char tempmessage[100];

	pmhp -> Command = 1;
    //add by Zhengzh
	pmhp -> Cascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	pmhp -> DogPassword = GetDlgItemInt ( hDlg,IDC_EDIT_PASSWORD,NULL,FALSE);
	dwStatus = GS_MHDog(pmhp);

	if (dwStatus==0)  
		strcpy(Message,"Dog check succeeded.");
	else 
		wsprintf ( Message, "Dog check failed.\rError code = %ld",dwStatus);
	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
}

void OnButtonConvert(HWND hDlg) 
{
	char ConvertData[]="MicroDog";
	DWORD dwStatus;
	char Message[100];

	pmhp -> Command = 4;
	pmhp -> DogBytes = 8;
    pmhp -> DogAddr = 0;

    pmhp -> Cascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	pmhp -> DogPassword = GetDlgItemInt ( hDlg,IDC_EDIT_PASSWORD,NULL,FALSE);
	strcpy(	pmhp -> DogData , ConvertData);
	
	dwStatus = GS_MHDog(pmhp);
	if (dwStatus==0)
	{
		wsprintf (Message, "Dog convert succeeded.\rConvert string = '%s'\rResult = %ld   (0x%lX)",ConvertData,pmhp -> DogResult,pmhp -> DogResult);
	}
	else
	{
		wsprintf (Message, "Dog convert failed.\rError code = %ld", dwStatus);
	}
	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
}

void OnButtonWrite(HWND hDlg) 
{
	DWORD dwStatus;
	DWORD dwData = 12345678;
	WORD  wData = 1234;
	float fData = 3.1415926F;
	char szData[] = "MicroDog";
	char Message[300],msg[100];


	Message[0] = 0;

	pmhp -> Command = 3;

    pmhp -> Cascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	pmhp -> DogPassword = GetDlgItemInt ( hDlg,IDC_EDIT_PASSWORD,NULL,FALSE);
	strcpy(pmhp -> DogData , szData);
	pmhp -> DogAddr = 0;
	pmhp -> DogBytes = 8;

	dwStatus = GS_MHDog(pmhp);
	if (dwStatus==0)
	{
		wsprintf (msg, "Write string succeeded.\rWrite: \"%s\" at address: %d\r\r",szData,pmhp -> DogAddr);
	}
	else
	{
		wsprintf (msg, "Write string failed.\rError code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	pmhp -> DogBytes = 4;
	*(DWORD *)pmhp -> DogData = dwData;
	pmhp -> DogAddr = 10;
	dwStatus = GS_MHDog(pmhp);
	if (dwStatus==0)
	{
		wsprintf (msg, "Write DWORD data succeeded.\rWrite: %ld at address: %d\r\r",dwData,pmhp -> DogAddr);
	}
	else
	{
		wsprintf (msg, "Write DWORD data failed.\rError code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);
	
	pmhp -> DogBytes = 2;
	*(WORD *)pmhp -> DogData = wData;
	pmhp -> DogAddr = 20;
	dwStatus = GS_MHDog(pmhp);
	if (dwStatus==0)
	{
		wsprintf (msg, "Write word data succeeded.\rWrite: %d at address: %d\r\r",wData,pmhp -> DogAddr);
	}
	else
	{
		wsprintf (msg, "Write word data failed.\rError code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	pmhp -> DogBytes = 4;
	*(float *)pmhp -> DogData = fData;
	pmhp -> DogAddr = 30;
	dwStatus = GS_MHDog(pmhp);
	if (dwStatus==0)
	{
		sprintf (msg, "Write float data succeeded.\rWrite %e at address: %d",fData,pmhp -> DogAddr);
	}
	else
	{
		wsprintf (msg, "Write float failed.\rError code = %ld", dwStatus);
	}
	strcat (Message,msg);
	
	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
}

void OnButtonRead(HWND hDlg) 
{
	DWORD dwStatus;
	DWORD dwData ;
	WORD  wData ; 
	float fData;
	char szData[10] ;
	char Message[300],msg[100];

	Message[0] = 0;

    pmhp -> Cascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	pmhp -> DogPassword = GetDlgItemInt ( hDlg,IDC_EDIT_PASSWORD,NULL,FALSE);

	pmhp -> Command = 2;
	pmhp -> DogAddr = 0;
	pmhp -> DogBytes = 8;
	dwStatus = GS_MHDog(pmhp);
	strcpy(szData , pmhp -> DogData);
	szData[8] = 0;
	if (dwStatus==0)
	{
		wsprintf (msg, "Read string succeeded.\rRead: \"%s\" from address: %d\r\r",szData,pmhp -> DogAddr);
	}
	else
	{
		wsprintf (msg, "Read string failed.\rError code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	pmhp -> DogBytes = 4;
	pmhp -> DogAddr = 10;
	dwStatus = GS_MHDog(pmhp);
	dwData = *(DWORD *)pmhp -> DogData;
	if (dwStatus==0)
	{
		wsprintf (msg, "Read dword data succeeded.\rRead: %ld from address: %d\r\r",dwData,pmhp -> DogAddr);
	}
	else
	{
		wsprintf (msg, "Read dword data failed.\rError code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	pmhp -> DogBytes = 2;
	pmhp -> DogAddr = 20;
	dwStatus = GS_MHDog(pmhp);
	wData = *(WORD *)pmhp -> DogData ;
	if (dwStatus==0)
	{
		wsprintf (msg, "Read word data succeeded.\rRead: %d from address: %d\r\r",wData,pmhp -> DogAddr);
	}
	else
	{
		wsprintf (msg, "Read word data failed.\rError code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	pmhp -> DogBytes = 4;
	pmhp -> DogAddr = 30;
	dwStatus = GS_MHDog(pmhp);
	fData = *(float *)pmhp -> DogData;
	if (dwStatus==0)
	{
		sprintf (msg, "Read float data succeeded.\rRead: %e from address: %d",fData,pmhp -> DogAddr);
	}
	else
	{
		wsprintf (msg, "Read float failed.\rError code = %ld", dwStatus);
	}
	strcat (Message,msg);
	
	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
	
}

void OnButtonDisable(HWND hDlg) 
{
	DWORD dwStatus;
	char Message[100];

	pmhp -> Command = 7;
	//add by Zhengzh
	pmhp -> Cascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	dwStatus = GS_MHDog(pmhp);
	if (dwStatus==0)
	{
		wsprintf (Message, "Disable share succeeded.");
	}
	else
	{
		wsprintf (Message, "Disable failed.\rError code = %ld", dwStatus);
	}
	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
}

void OnButtonCurno(HWND hDlg) 
{
	DWORD dwStatus;
	char Message[100];
	DWORD CurrentNo;

	pmhp -> Command = 5;
	pmhp -> Cascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	dwStatus = GS_MHDog(pmhp);
	CurrentNo = *(DWORD *)pmhp -> DogData;
	if (dwStatus==0)
	{
		wsprintf (Message, "Get current number succeeded.\rCurrent number = %u",CurrentNo);
	}
	else
	{
		wsprintf (Message, "Get current number failed.\rError code = %ld", dwStatus);
	}

	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
}

void OnButtonSetDogCascade(HWND hDlg)
{
    DWORD dwStatus;
	char Message[400];
	BYTE NewCascade;
    pmhp -> Command = 8;
	pmhp -> DogPassword = GetDlgItemInt( hDlg,IDC_EDIT_PASSWORD,NULL,FALSE );
    pmhp -> Cascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	//NewCascade=1;
	NewCascade=GetDlgItemInt ( hDlg,IDC_EDIT_NEWCASCADE,NULL,TRUE );

	strcpy(pmhp -> DogData, &NewCascade);
    pmhp -> DogAddr = 0;
	pmhp -> DogBytes = 1;

    dwStatus = GS_MHDog(pmhp);
    
	if (dwStatus==0)
	{
	
		wsprintf (Message, "Set dog cascade succeeded.\rThe new cascade is %d \r\rBe careful that Current Cascade = %u.\rInput this value in the CurrentCascade Editbox when restarting this program or use our utility DogEdt32 to reset it to 0.",pmhp->Cascade,pmhp->Cascade);
		SetDlgItemInt(hDlg,IDC_EDIT_CASCADE,pmhp->Cascade,TRUE);
	}
	else
	{
		wsprintf (Message, "Set dog cascade  failed.\rError code = %ld", dwStatus);
	}
	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
}

void OnButtonSetPassword(HWND hDlg)
{
    DWORD dwStatus;
	char Message[400];
    
	pmhp -> Command = 9;
	pmhp -> DogPassword = GetDlgItemInt( hDlg,IDC_EDIT_PASSWORD,NULL,FALSE );
    pmhp -> Cascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	pmhp-> NewPassword = GetDlgItemInt ( hDlg,IDC_EDIT_NEWPASSWORD,NULL,FALSE );
    	
	dwStatus = GS_MHDog(pmhp);
	
    if (dwStatus==0)
	{
	    wsprintf (Message, "Set new password succeeded.\rThe new password is %u \r\rBe careful that current Dog password = %u.\rInput this value in the CurrentPassword Editbox when restarting this program or use our utility DogEdt32 to reset it to 0 .",pmhp->DogPassword,pmhp->DogPassword);                  
	    SetDlgItemInt(hDlg,IDC_EDIT_PASSWORD,pmhp->DogPassword,FALSE);
	}
	else
	{
	    wsprintf (Message, "Set dog password failed.\rError code = %ld", dwStatus);
	}
	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
}

/****************************************************************************

    FUNCTION: DemoDlg(HWND, unsigned, WORD, LONG)

****************************************************************************/

BOOL FAR PASCAL DemoDlg(HWND hDlg, unsigned message, WORD wParam, LONG lParam)
{
	FARPROC lpProcAbout;
    
    switch (message)
    {

    case WM_INITDIALOG:
        OnDialogInit(hDlg);
		return (TRUE);

    case WM_COMMAND:
		switch(wParam)
        {
		case IDCANCEL:
			EndDialog(hDlg, TRUE);
			return (TRUE);
		
		case IDC_BUTTON_CHECK:
			OnButtonCheck(hDlg);
			break;
		
		case IDC_BUTTON_CURNO:
			OnButtonCurno(hDlg);
			break;
		
		case IDC_BUTTON_CONVERT:
			OnButtonConvert(hDlg);
			break;
		
		case IDC_BUTTON_WRITE:
			OnButtonWrite(hDlg);
			break;
		
		case IDC_BUTTON_READ:
			OnButtonRead(hDlg);
			break;

		case IDC_BUTTON_DISABLE:
			OnButtonDisable(hDlg);
			break;
		// add by Zhengzh
		case IDC_BUTTON_SETDOGCASCADE:
			OnButtonSetDogCascade(hDlg);
			break;
         
        case IDC_BUTTON_SETPASSWORD:
			OnButtonSetPassword(hDlg);	
			break;
		}
	    break;

	case WM_SYSCOMMAND:
        if (wParam==IDM_ABOUT)
        {
			lpProcAbout = MakeProcInstance(About, hInst);
			DialogBox(hInst,"AboutBox",hDlg,lpProcAbout);
			FreeProcInstance(lpProcAbout);
        }
        break;
    }
    return (FALSE);                       
}

void CenterWindow(HWND hWnd)
{
    RECT rect;
    int systemX,systemY;
    int newX,newY;
	
    GetWindowRect(hWnd,&rect);
    systemX=GetSystemMetrics(SM_CXFULLSCREEN);
    systemY=GetSystemMetrics(SM_CYFULLSCREEN);
	
    newX = (systemX-(rect.right-rect.left))/2;
    newY = (systemY-(rect.bottom-rect.top))/2;

    SetWindowPos(hWnd,NULL,newX,newY,0,0,SWP_NOSIZE);
}
