#include "resource.h"

#ifndef ULONG
#define ULONG unsigned long
#endif

#ifndef HUINT
#define HUINT unsigned short
#endif

#ifndef UCHAR
#define UCHAR unsigned char
#endif

#ifndef WORD
#define WORD unsigned short
#endif

#define MHSTATUS ULONG

    typedef struct _MH_DLL_PARA
    {
    	WORD/*BYTE*/	Command;
    	WORD/*BYTE*/	Cascade;
    	WORD	DogAddr;
    	WORD	DogBytes;
    	DWORD	DogPassword;
    	DWORD	DogResult;
		DWORD/*BYTE*/    NewPassword;
    	BYTE	DogData[200];
    }MH_DLL_PARA,  far * PMH_DLL_PARA;

	unsigned long (PASCAL *GS_MHDog)(PMH_DLL_PARA pmdp);
