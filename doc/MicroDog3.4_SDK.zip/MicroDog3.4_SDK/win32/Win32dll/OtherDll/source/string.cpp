// string.cpp : Defines the initialization routines for the DLL.
//	High Tech BASIC, Copyright (C) TransEra Corp 1999, All Rights Reserved.

#include "stdafx.h"
#include "string.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "gsmh.h"


#ifndef ULONG
#define ULONG unsigned long
#endif

#ifndef HUINT
#define HUINT unsigned short
#endif

#ifndef UCHAR
#define UCHAR unsigned char
#endif

#ifndef WORD
#define WORD unsigned short
#endif

#define MHSTATUS ULONG

#define MH_SUCCESS   0
MHSTATUS resu;
//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CStringApp

BEGIN_MESSAGE_MAP(CStringApp, CWinApp)
	//{{AFX_MSG_MAP(CStringApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStringApp construction

CStringApp::CStringApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CStringApp object

CStringApp theApp;



extern "C"
{
void _cdecl Hello(char* lpMsg,long *lpRet)
{
	strcpy(lpMsg,"Hello,this is a test!");	
	*lpRet = 0;
}

void _cdecl Check_Dog(USHORT Cascade,ULONG Password,long *lpRet)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	DogCascade =(UCHAR)Cascade;
    DogPassword=Password; 
	resu = DogCheck();
	*lpRet = resu;

//	return resu;
}

void _cdecl Read_Dog(USHORT Cascade,ULONG Password,USHORT addr,USHORT bytes,void * pdata,long *lpRet)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	DogCascade =(UCHAR)Cascade;
	DogPassword=(ULONG)Password;
	DogAddr=(USHORT)addr;
	DogBytes=(USHORT)bytes;
	DogData=pdata;
	resu = ReadDog();
	*lpRet = resu;

//	return resu;	    
}
void _cdecl Write_Dog(USHORT Cascade,ULONG Password,USHORT addr,USHORT bytes,void * pdata,long *lpRet)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	DogCascade =(UCHAR)Cascade;
	DogPassword=(ULONG)Password;
	DogAddr=(USHORT)addr;
	DogBytes=(USHORT)bytes;
	DogData=pdata;
	resu = WriteDog();
	*lpRet = resu;

//	return resu;	    
	
}
void _cdecl Convert_Dog(USHORT Cascade,ULONG Password,USHORT bytes,void * pdata,void * pResult,long *lpRet)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	DogCascade =(UCHAR)Cascade;
	DogPassword=(ULONG)Password;
	DogBytes=(USHORT)bytes;
	DogData=pdata;
	resu = DogConvert();
	if(!resu) 
	{
		//itoa(DogResult,(char *)pResult,10);	
		*(DWORD *)pResult = DogResult;
	}
	*lpRet = resu;
	
//	return resu;	    
}
void _cdecl DisableShare_Dog(USHORT Cascade,ULONG Password,long *lpRet)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	DogCascade =(UCHAR)Cascade;
	DogPassword=(ULONG)Password;
	resu = DisableShare();
	*lpRet = resu;

//	return resu;	    

}
void _cdecl SetPassword_Dog(USHORT Cascade,ULONG Password,ULONG InNewPassword,long *lpRet)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	DogCascade =(UCHAR)Cascade;
	DogPassword=(ULONG)Password;
	NewPassword=(ULONG)InNewPassword;
	resu = SetPassword();	
	*lpRet = resu;

//	return resu;	    
}
void _cdecl SetCascade_Dog(USHORT Cascade,long Password,USHORT NewCascade,long *lpRet)
{AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	DogCascade =(UCHAR) Cascade;
	DogPassword=(ULONG)Password;
//	DogData=(UCHAR *)&NewCascade;
	UCHAR temp = (UCHAR)NewCascade;
	DogData=&temp;
	DogBytes=1;
	resu = SetDogCascade();
	*lpRet = resu;

//	return resu;	    
}
void _cdecl GetCurrentNo_Dog(USHORT Cascade,long *lpCurrentNo,long *lpRet)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	DogCascade =(UCHAR) Cascade;
	DogData = lpCurrentNo;
	resu = GetCurrentNo();
	*lpRet = resu;
}
} // end extern "C"