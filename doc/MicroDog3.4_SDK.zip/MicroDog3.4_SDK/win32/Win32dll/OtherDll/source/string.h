// string.h : main header file for the STRING DLL
//	High Tech BASIC, Copyright (C) TransEra Corp 1999, All Rights Reserved.

#if !defined(AFX_STRING_H__135E7BC6_F0E2_11D2_A910_00104B9A4FD0__INCLUDED_)
#define AFX_STRING_H__135E7BC6_F0E2_11D2_A910_00104B9A4FD0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CStringApp
// See string.cpp for the implementation of this class
//

class CStringApp : public CWinApp
{
public:
	CStringApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStringApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CStringApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STRING_H__135E7BC6_F0E2_11D2_A910_00104B9A4FD0__INCLUDED_)
