' ===================================================================================
' File : Form1.vb					Author : Jason Jiang
' Date : 2002-8-30
' Description : This is the main file of Loading MicroDog's Win32 DLL.
' ===================================================================================

Option Strict On

Imports System.Runtime.InteropServices

Public Class FormPassword
    Inherits System.Windows.Forms.Form

    Dim NetDog As New Dog

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call


    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TextInfo As System.Windows.Forms.Label
    Friend WithEvents ReadDogButton As System.Windows.Forms.Button
    Friend WithEvents WriteDogButton As System.Windows.Forms.Button
    Friend WithEvents DogConvertButton As System.Windows.Forms.Button
    Friend WithEvents Dogcheck As System.Windows.Forms.Button
    Friend WithEvents GetCurNo As System.Windows.Forms.Button
    Friend WithEvents DisableShare As System.Windows.Forms.Button
    Friend WithEvents SetCascade As System.Windows.Forms.Button
    Friend WithEvents SetPassword As System.Windows.Forms.Button
    Friend WithEvents TextBoxPassword As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBoxNewPassword As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBoxCascade As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBoxNewCascade As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Dogcheck = New System.Windows.Forms.Button
        Me.TextInfo = New System.Windows.Forms.Label
        Me.ReadDogButton = New System.Windows.Forms.Button
        Me.WriteDogButton = New System.Windows.Forms.Button
        Me.DogConvertButton = New System.Windows.Forms.Button
        Me.GetCurNo = New System.Windows.Forms.Button
        Me.DisableShare = New System.Windows.Forms.Button
        Me.SetCascade = New System.Windows.Forms.Button
        Me.SetPassword = New System.Windows.Forms.Button
        Me.TextBoxPassword = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.TextBoxNewPassword = New System.Windows.Forms.TextBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.TextBoxCascade = New System.Windows.Forms.TextBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.TextBoxNewCascade = New System.Windows.Forms.TextBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Dogcheck
        '
        Me.Dogcheck.Location = New System.Drawing.Point(32, 24)
        Me.Dogcheck.Name = "Dogcheck"
        Me.Dogcheck.Size = New System.Drawing.Size(96, 24)
        Me.Dogcheck.TabIndex = 0
        Me.Dogcheck.Text = "DogCheck"
        '
        'TextInfo
        '
        Me.TextInfo.BackColor = System.Drawing.SystemColors.Window
        Me.TextInfo.Location = New System.Drawing.Point(168, 24)
        Me.TextInfo.Name = "TextInfo"
        Me.TextInfo.Size = New System.Drawing.Size(184, 248)
        Me.TextInfo.TabIndex = 1
        '
        'ReadDogButton
        '
        Me.ReadDogButton.Location = New System.Drawing.Point(32, 56)
        Me.ReadDogButton.Name = "ReadDogButton"
        Me.ReadDogButton.Size = New System.Drawing.Size(96, 24)
        Me.ReadDogButton.TabIndex = 2
        Me.ReadDogButton.Text = "ReadDog"
        '
        'WriteDogButton
        '
        Me.WriteDogButton.Location = New System.Drawing.Point(32, 88)
        Me.WriteDogButton.Name = "WriteDogButton"
        Me.WriteDogButton.Size = New System.Drawing.Size(96, 24)
        Me.WriteDogButton.TabIndex = 3
        Me.WriteDogButton.Text = "WriteDog"
        '
        'DogConvertButton
        '
        Me.DogConvertButton.Location = New System.Drawing.Point(32, 120)
        Me.DogConvertButton.Name = "DogConvertButton"
        Me.DogConvertButton.Size = New System.Drawing.Size(96, 24)
        Me.DogConvertButton.TabIndex = 4
        Me.DogConvertButton.Text = "DogConvert"
        '
        'GetCurNo
        '
        Me.GetCurNo.Location = New System.Drawing.Point(32, 152)
        Me.GetCurNo.Name = "GetCurNo"
        Me.GetCurNo.Size = New System.Drawing.Size(96, 24)
        Me.GetCurNo.TabIndex = 5
        Me.GetCurNo.Text = "GetCurNo"
        '
        'DisableShare
        '
        Me.DisableShare.Location = New System.Drawing.Point(32, 184)
        Me.DisableShare.Name = "DisableShare"
        Me.DisableShare.Size = New System.Drawing.Size(96, 24)
        Me.DisableShare.TabIndex = 6
        Me.DisableShare.Text = "DisableShare"
        '
        'SetCascade
        '
        Me.SetCascade.Location = New System.Drawing.Point(32, 216)
        Me.SetCascade.Name = "SetCascade"
        Me.SetCascade.Size = New System.Drawing.Size(96, 24)
        Me.SetCascade.TabIndex = 7
        Me.SetCascade.Text = "SetCascade"
        '
        'SetPassword
        '
        Me.SetPassword.Location = New System.Drawing.Point(32, 248)
        Me.SetPassword.Name = "SetPassword"
        Me.SetPassword.Size = New System.Drawing.Size(96, 24)
        Me.SetPassword.TabIndex = 9
        Me.SetPassword.Text = "SetPassword"
        '
        'TextBoxPassword
        '
        Me.TextBoxPassword.Location = New System.Drawing.Point(16, 24)
        Me.TextBoxPassword.Name = "TextBoxPassword"
        Me.TextBoxPassword.Size = New System.Drawing.Size(64, 21)
        Me.TextBoxPassword.TabIndex = 11
        Me.TextBoxPassword.Text = "0"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TextBoxPassword)
        Me.GroupBox1.Location = New System.Drawing.Point(32, 288)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(96, 56)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Password"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.TextBoxNewPassword)
        Me.GroupBox2.Location = New System.Drawing.Point(168, 288)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(96, 56)
        Me.GroupBox2.TabIndex = 15
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "New Password"
        '
        'TextBoxNewPassword
        '
        Me.TextBoxNewPassword.Location = New System.Drawing.Point(16, 24)
        Me.TextBoxNewPassword.Name = "TextBoxNewPassword"
        Me.TextBoxNewPassword.Size = New System.Drawing.Size(64, 21)
        Me.TextBoxNewPassword.TabIndex = 11
        Me.TextBoxNewPassword.Text = "0"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.TextBoxCascade)
        Me.GroupBox3.Location = New System.Drawing.Point(32, 360)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(96, 56)
        Me.GroupBox3.TabIndex = 16
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Cascade"
        '
        'TextBoxCascade
        '
        Me.TextBoxCascade.Location = New System.Drawing.Point(16, 24)
        Me.TextBoxCascade.Name = "TextBoxCascade"
        Me.TextBoxCascade.Size = New System.Drawing.Size(64, 21)
        Me.TextBoxCascade.TabIndex = 11
        Me.TextBoxCascade.Text = "0"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.TextBoxNewCascade)
        Me.GroupBox4.Location = New System.Drawing.Point(168, 360)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(96, 56)
        Me.GroupBox4.TabIndex = 17
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "New Cascade"
        '
        'TextBoxNewCascade
        '
        Me.TextBoxNewCascade.Location = New System.Drawing.Point(16, 24)
        Me.TextBoxNewCascade.Name = "TextBoxNewCascade"
        Me.TextBoxNewCascade.Size = New System.Drawing.Size(64, 21)
        Me.TextBoxNewCascade.TabIndex = 11
        Me.TextBoxNewCascade.Text = "0"
        '
        'FormPassword
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 14)
        Me.ClientSize = New System.Drawing.Size(392, 438)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.SetPassword)
        Me.Controls.Add(Me.SetCascade)
        Me.Controls.Add(Me.DisableShare)
        Me.Controls.Add(Me.GetCurNo)
        Me.Controls.Add(Me.DogConvertButton)
        Me.Controls.Add(Me.WriteDogButton)
        Me.Controls.Add(Me.ReadDogButton)
        Me.Controls.Add(Me.TextInfo)
        Me.Controls.Add(Me.Dogcheck)
        Me.Name = "FormPassword"
        Me.Text = "VB.NET Sample"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Dogcheck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Dogcheck.Click
        NetDog.DogCascade = CInt(TextBoxCascade.Text)
        NetDog.DogPassword = CInt(TextBoxPassword.Text)
        NetDog.Check_Dog(NetDog.DogCascade, NetDog.DogPassword, NetDog.RetCode)
        If (NetDog.RetCode = 0) Then
            TextInfo.Text = "Dog check succeed!"
        Else
            TextInfo.Text = "Dog check failed!  The errcode is:" + CStr(NetDog.RetCode)
        End If
    End Sub

    Private Sub ReadDogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReadDogButton.Click
        NetDog.DogCascade = CInt(TextBoxCascade.Text)
        NetDog.DogPassword = CInt(TextBoxPassword.Text)
        NetDog.DogAddr = 10
        NetDog.DogBytes = 4
        NetDog.Read_Dog(NetDog.DogCascade, NetDog.DogPassword, NetDog.DogAddr, NetDog.DogBytes, NetDog.DogData, NetDog.RetCode)
        If (NetDog.RetCode = 0) Then
            TextInfo.Text = "Read dog succeed!  The data is '" & ChrW(NetDog.DogData(0)) & ChrW(NetDog.DogData(1)) & ChrW(NetDog.DogData(2)) & ChrW(NetDog.DogData(3)) + "'"
        Else
            TextInfo.Text = "Read dog failed!  The errcode is:" + CStr(NetDog.RetCode)
        End If
    End Sub

    Private Sub WriteDogButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WriteDogButton.Click
        NetDog.DogCascade = CInt(TextBoxCascade.Text)
        NetDog.DogPassword = CInt(TextBoxPassword.Text)
        NetDog.DogAddr = 10
        NetDog.DogBytes = 4
        NetDog.DogData(0) = 97
        NetDog.DogData(1) = 98
        NetDog.DogData(2) = 99
        NetDog.DogData(3) = 100
        NetDog.Write_Dog(NetDog.DogCascade, NetDog.DogPassword, NetDog.DogAddr, NetDog.DogBytes, NetDog.DogData, NetDog.RetCode)
        If NetDog.RetCode = 0 Then
            TextInfo.Text = "Write dog succeed!  The data is 'abcd'."
        Else
            TextInfo.Text = "Write dog failed!  The errcode is:" & NetDog.RetCode
        End If
    End Sub

    Private Sub DogConvertButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DogConvertButton.Click
        NetDog.DogCascade = CInt(TextBoxCascade.Text)
        NetDog.DogPassword = CInt(TextBoxPassword.Text)
        NetDog.DogBytes = 4
        NetDog.DogData(0) = 97
        NetDog.DogData(1) = 98
        NetDog.DogData(2) = 99
        NetDog.DogData(3) = 100
        NetDog.Convert_Dog(NetDog.DogCascade, NetDog.DogPassword, NetDog.DogBytes, NetDog.DogData, NetDog.DogResult, NetDog.RetCode)
        If NetDog.RetCode = 0 Then
            TextInfo.Text = "Convert data succeed!  Convert 'abcd' to:" & NetDog.DogResult
        Else
            TextInfo.Text = "Convert data failed!  The errcode is:" & NetDog.RetCode
        End If
    End Sub

    Private Sub GetCurNo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetCurNo.Click
        NetDog.DogCascade = CInt(TextBoxCascade.Text)
        NetDog.GetCurrentNo_Dog(NetDog.DogCascade, NetDog.CurrentNu, NetDog.RetCode)
        If NetDog.RetCode = 0 Then
            TextInfo.Text = "GetCurrentNo succeed!  The data is :" & NetDog.CurrentNu
        Else
            TextInfo.Text = "GetCurrentNo failed!  The errcode is:" & NetDog.RetCode
        End If
    End Sub

    Private Sub DisableShare_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisableShare.Click
        NetDog.DogCascade = CInt(TextBoxCascade.Text)
        NetDog.DogPassword = CInt(TextBoxPassword.Text)
        NetDog.DisableShare_Dog(NetDog.DogCascade, NetDog.DogPassword, NetDog.RetCode)
        If NetDog.RetCode = 0 Then
            TextInfo.Text = "DisableShare succeed!"
        Else
            TextInfo.Text = "DisableShare failed!"
        End If
    End Sub

    Private Sub SetCascade_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetCascade.Click
        NetDog.DogCascade = CInt(TextBoxCascade.Text)
        NetDog.DogPassword = CInt(TextBoxPassword.Text)
        NetDog.NewCascade = CInt(TextBoxNewCascade.Text)
        NetDog.SetCascade_Dog(NetDog.DogCascade, NetDog.DogPassword, NetDog.NewCascade, NetDog.RetCode)
        If NetDog.RetCode = 0 Then
            TextInfo.Text = "Set cascade succeed!  Set cascade to " & NetDog.NewCascade
            TextBoxCascade.Text = Convert.ToString(NetDog.NewCascade)

        Else
            TextInfo.Text = "Set cascade failed!  The errcode is:" & NetDog.RetCode
        End If
    End Sub

    Private Sub SetPassword_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetPassword.Click
        NetDog.DogCascade = CInt(TextBoxCascade.Text)
        NetDog.DogPassword = CInt(TextBoxPassword.Text)
        NetDog.NewPassword = CInt(TextBoxNewPassword.Text)
        NetDog.SetPassword_Dog(NetDog.DogCascade, NetDog.DogPassword, NetDog.NewPassword, NetDog.RetCode)
        If NetDog.RetCode = 0 Then
            TextInfo.Text = "Set password succeed!  Set password to " & NetDog.NewPassword
            TextBoxPassword.Text = Convert.ToString(NetDog.NewPassword)
        Else
            TextInfo.Text = "Set password failed!  The errcode is:" & NetDog.RetCode
        End If
    End Sub

    Private Sub FormPassword_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub
End Class


'The Class implement the NetDog Function
Public Class Dog

    Public DogBytes As Integer = 0
    Public DogAddr As Integer = 1
    Public DogCascade As Integer = 0
    Public NewCascade As Integer = 0
    Public DogPassword As Integer = 0
    Public NewPassword As Integer = 0
    Public DogResult As Integer = 0
    Public CurrentNu As Integer = 0
    Public DogData(199) As Byte
    Public RetCode As Integer = 0

    Declare Function Check_Dog Lib "htbdog.dll" (ByVal DogCascade As Integer, ByVal DogPassword As Integer, ByRef RetCode As Integer) As Integer
    Declare Function Read_Dog Lib "htbdog.dll" (ByVal DogCascade As Integer, ByVal DogPassword As Integer, ByVal DogAddr As Integer, ByVal DogBytes As Integer, ByVal DogData() As Byte, ByRef RetCode As Integer) As Integer
    Declare Function Write_Dog Lib "htbdog.dll" (ByVal DogCascade As Integer, ByVal DogPassword As Integer, ByVal DogAddr As Integer, ByVal DogBytes As Integer, ByVal DogData() As Byte, ByRef RetCode As Integer) As Integer
    Declare Function Convert_Dog Lib "htbdog.dll" (ByVal DogCascade As Integer, ByVal DogPassword As Integer, ByVal DogBytes As Integer, ByVal DogData() As Byte, ByRef DogResult As Integer, ByRef RetCode As Integer) As Integer
    Declare Function DisableShare_Dog Lib "htbdog.dll" (ByVal DogCascade As Integer, ByVal DogPassword As Integer, ByRef RetCode As Integer) As Integer
    Declare Function SetPassword_Dog Lib "htbdog.dll" (ByVal DogCascade As Integer, ByVal DogPassword As Integer, ByVal NewPassword As Integer, ByRef RetCode As Integer) As Integer
    Declare Function SetCascade_Dog Lib "htbdog.dll" (ByVal DogCascade As Integer, ByVal DogPassword As Integer, ByVal NewCascade As Integer, ByRef RetCode As Integer) As Integer
    Declare Function GetCurrentNo_Dog Lib "htbdog.dll" (ByVal DogCascade As Integer, ByRef CurrentNu As Integer, ByRef RetCode As Integer) As Integer

End Class

