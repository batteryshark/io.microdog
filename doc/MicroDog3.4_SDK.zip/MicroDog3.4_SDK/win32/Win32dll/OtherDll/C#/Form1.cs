using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;
using System.Text;

[StructLayout(LayoutKind.Sequential)]

//This class complement the netdog function,and import the dll interface 
public unsafe class  UmhDog
{		

	public ushort DogBytes,DogAddr;
	public uint   DogPassword;
	public uint   NewPassword;
	public uint   DogResult,CurrentNu;
	public ushort DogCascade,NewCascade;
	public byte [] DogData;
	public uint  Retocde;

	[DllImport("htbdog.dll",CharSet=CharSet.Ansi)]
	
	public static unsafe extern  void Check_Dog(ushort Cascade,uint Password,uint *lpRet);
	[DllImport("htbdog.dll",CharSet=CharSet.Ansi)]
	public static unsafe extern  void Read_Dog(ushort Cascade,uint Password,ushort addr,ushort bytes,void * pdata,uint *lpRet);
	[DllImport("htbdog.dll",CharSet=CharSet.Ansi)]
	public static unsafe extern  void Write_Dog(ushort Cascade,uint Password,ushort addr,ushort bytes,void * pdata,uint *lpRet);
	[DllImport("htbdog.dll",CharSet=CharSet.Ansi)]
	public static unsafe extern  void Convert_Dog(ushort Cascade,uint Password,ushort bytes,void * pdata,void * pResult,uint *lpRet);
	[DllImport("htbdog.dll",CharSet=CharSet.Ansi)]
	public static unsafe extern  void DisableShare_Dog(ushort Cascade,uint Password,uint *lpRet);
	[DllImport("htbdog.dll",CharSet=CharSet.Ansi)]
	public static unsafe extern  void SetPassword_Dog(ushort Cascade,uint Password,uint InNewPassword,uint *lpRet);
	[DllImport("htbdog.dll",CharSet=CharSet.Ansi)]
	public static unsafe extern  void SetCascade_Dog(ushort Cascade,uint Password,ushort NewCascade,uint *lpRet);
	[DllImport("htbdog.dll",CharSet=CharSet.Ansi)]
	public static unsafe extern  void GetCurrentNo_Dog(ushort Cascade,uint *lpCurrentNo,uint *lpRet);

	public unsafe UmhDog(ushort num)
	{
		DogBytes=num;
		DogData=new Byte[DogBytes];
	}
	
	public  unsafe   void CheckDog()
	{
		fixed(uint *pRetcode=&Retocde)
		{
			Check_Dog(DogCascade,DogPassword,pRetcode);
		}
	}
	public  unsafe   void ReadDog()
	{
		fixed(byte * pDogData=&DogData[0])
			fixed(uint *pRetcode=&Retocde)
		{
			Read_Dog(DogCascade,DogPassword,DogAddr, DogBytes,pDogData,pRetcode);
		}
	}
	public  unsafe   void WriteDog()
	{
		fixed(byte * pDogData=&DogData[0])
			fixed(uint *pRetcode=&Retocde)
			{
				Write_Dog(DogCascade,DogPassword,DogAddr, DogBytes,pDogData,pRetcode);
			}	 
	}
	public  unsafe   void ConvertDog()
	{
		fixed(uint *pRetcode=&Retocde)
			fixed(uint *pResult=&DogResult)
				fixed(byte * pDogData=&DogData[0])
			{
				Convert_Dog(DogCascade,DogPassword,DogBytes,pDogData,pResult,pRetcode);
			}
	}
	public  unsafe   void DisableShareDog()
	{
		fixed(uint *pRetcode=&Retocde)
		{
			DisableShare_Dog(DogCascade,DogPassword,pRetcode);
		}
	}
	public  unsafe   void SetPasswordDog()
	{
		fixed(uint *pRetcode=&Retocde)
		{
			SetPassword_Dog(DogCascade,DogPassword,NewPassword,pRetcode);
		}
	}
	public  unsafe   void SetCascadeDog()
	{
		fixed(uint *pRetcode=&Retocde)
		{
			SetCascade_Dog( DogCascade, DogPassword, NewCascade,pRetcode);
		}
	}
	public  unsafe   void GetCurrentNoDog()
	{
		fixed(uint *pRetcode=&Retocde)
			fixed(uint *pCurrentNo=&CurrentNu)
			{
				GetCurrentNo_Dog( DogCascade,pCurrentNo,pRetcode);
			}
	}

}

namespace CSharpSample
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox DogInfo;
		private System.Windows.Forms.Button DogCheckbutton;
		private System.Windows.Forms.Button ReadDogbutton;
		private System.Windows.Forms.Button WriteDogbutton;
		private System.Windows.Forms.Button GetCurNoButton;
		private System.Windows.Forms.Button DogConvertbutton;
		private System.Windows.Forms.Button DisableSharebutton;
		
		
		public UmhDog dog;
		private System.Windows.Forms.Button SetCascadebutton;
		private System.Windows.Forms.Button Setpasswordbutton;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox textBoxPassword;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.TextBox textBoxNewPassword;
		private System.Windows.Forms.TextBox textBoxCascade;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.TextBox textBoxNewCascade;
		private System.Windows.Forms.GroupBox groupBox4;
			
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		
		
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			
			// TODO: Add any constructor code after InitializeComponent call
			dog=new UmhDog(200);						
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.DogInfo = new System.Windows.Forms.TextBox();
			this.DogCheckbutton = new System.Windows.Forms.Button();
			this.ReadDogbutton = new System.Windows.Forms.Button();
			this.WriteDogbutton = new System.Windows.Forms.Button();
			this.GetCurNoButton = new System.Windows.Forms.Button();
			this.DogConvertbutton = new System.Windows.Forms.Button();
			this.DisableSharebutton = new System.Windows.Forms.Button();
			this.SetCascadebutton = new System.Windows.Forms.Button();
			this.Setpasswordbutton = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.textBoxPassword = new System.Windows.Forms.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.textBoxNewPassword = new System.Windows.Forms.TextBox();
			this.textBoxCascade = new System.Windows.Forms.TextBox();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.textBoxNewCascade = new System.Windows.Forms.TextBox();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.SuspendLayout();
			// 
			// DogInfo
			// 
			this.DogInfo.Location = new System.Drawing.Point(184, 24);
			this.DogInfo.Multiline = true;
			this.DogInfo.Name = "DogInfo";
			this.DogInfo.Size = new System.Drawing.Size(216, 248);
			this.DogInfo.TabIndex = 0;
			this.DogInfo.Text = "";
			// 
			// DogCheckbutton
			// 
			this.DogCheckbutton.Location = new System.Drawing.Point(32, 24);
			this.DogCheckbutton.Name = "DogCheckbutton";
			this.DogCheckbutton.Size = new System.Drawing.Size(112, 23);
			this.DogCheckbutton.TabIndex = 1;
			this.DogCheckbutton.Text = "DogCheck";
			this.DogCheckbutton.Click += new System.EventHandler(this.DogCheckbutton_Click);
			// 
			// ReadDogbutton
			// 
			this.ReadDogbutton.Location = new System.Drawing.Point(32, 56);
			this.ReadDogbutton.Name = "ReadDogbutton";
			this.ReadDogbutton.Size = new System.Drawing.Size(112, 23);
			this.ReadDogbutton.TabIndex = 2;
			this.ReadDogbutton.Text = "ReadDog";
			this.ReadDogbutton.Click += new System.EventHandler(this.ReadDogbutton_Click);
			// 
			// WriteDogbutton
			// 
			this.WriteDogbutton.Location = new System.Drawing.Point(32, 88);
			this.WriteDogbutton.Name = "WriteDogbutton";
			this.WriteDogbutton.Size = new System.Drawing.Size(112, 23);
			this.WriteDogbutton.TabIndex = 3;
			this.WriteDogbutton.Text = "WriteDog";
			this.WriteDogbutton.Click += new System.EventHandler(this.WriteDogbutton_Click);
			// 
			// GetCurNoButton
			// 
			this.GetCurNoButton.Location = new System.Drawing.Point(32, 120);
			this.GetCurNoButton.Name = "GetCurNoButton";
			this.GetCurNoButton.Size = new System.Drawing.Size(112, 23);
			this.GetCurNoButton.TabIndex = 4;
			this.GetCurNoButton.Text = "GetCurNo";
			this.GetCurNoButton.Click += new System.EventHandler(this.GetCurNoButton_Click);
			// 
			// DogConvertbutton
			// 
			this.DogConvertbutton.Location = new System.Drawing.Point(32, 152);
			this.DogConvertbutton.Name = "DogConvertbutton";
			this.DogConvertbutton.Size = new System.Drawing.Size(112, 23);
			this.DogConvertbutton.TabIndex = 5;
			this.DogConvertbutton.Text = "DogConvert";
			this.DogConvertbutton.Click += new System.EventHandler(this.DogConvertbutton_Click);
			// 
			// DisableSharebutton
			// 
			this.DisableSharebutton.Location = new System.Drawing.Point(32, 184);
			this.DisableSharebutton.Name = "DisableSharebutton";
			this.DisableSharebutton.Size = new System.Drawing.Size(112, 23);
			this.DisableSharebutton.TabIndex = 6;
			this.DisableSharebutton.Text = "DiasableShare";
			this.DisableSharebutton.Click += new System.EventHandler(this.DisableSharebutton_Click);
			// 
			// SetCascadebutton
			// 
			this.SetCascadebutton.Location = new System.Drawing.Point(32, 248);
			this.SetCascadebutton.Name = "SetCascadebutton";
			this.SetCascadebutton.Size = new System.Drawing.Size(112, 23);
			this.SetCascadebutton.TabIndex = 7;
			this.SetCascadebutton.Text = "Setcascade";
			this.SetCascadebutton.Click += new System.EventHandler(this.SetCascadebutton_Click);
			// 
			// Setpasswordbutton
			// 
			this.Setpasswordbutton.Location = new System.Drawing.Point(32, 216);
			this.Setpasswordbutton.Name = "Setpasswordbutton";
			this.Setpasswordbutton.Size = new System.Drawing.Size(112, 23);
			this.Setpasswordbutton.TabIndex = 8;
			this.Setpasswordbutton.Text = "SetPassword";
			this.Setpasswordbutton.Click += new System.EventHandler(this.Setpasswordbutton_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Location = new System.Drawing.Point(32, 288);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(112, 48);
			this.groupBox1.TabIndex = 9;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Password";
			// 
			// textBoxPassword
			// 
			this.textBoxPassword.Location = new System.Drawing.Point(48, 304);
			this.textBoxPassword.Name = "textBoxPassword";
			this.textBoxPassword.Size = new System.Drawing.Size(80, 21);
			this.textBoxPassword.TabIndex = 10;
			this.textBoxPassword.Text = "0";
			// 
			// groupBox2
			// 
			this.groupBox2.Location = new System.Drawing.Point(184, 288);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(112, 48);
			this.groupBox2.TabIndex = 11;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "New Password";
			// 
			// textBoxNewPassword
			// 
			this.textBoxNewPassword.Location = new System.Drawing.Point(200, 304);
			this.textBoxNewPassword.Name = "textBoxNewPassword";
			this.textBoxNewPassword.Size = new System.Drawing.Size(80, 21);
			this.textBoxNewPassword.TabIndex = 12;
			this.textBoxNewPassword.Text = "0";
			// 
			// textBoxCascade
			// 
			this.textBoxCascade.Location = new System.Drawing.Point(48, 368);
			this.textBoxCascade.Name = "textBoxCascade";
			this.textBoxCascade.Size = new System.Drawing.Size(80, 21);
			this.textBoxCascade.TabIndex = 14;
			this.textBoxCascade.Text = "0";
			// 
			// groupBox3
			// 
			this.groupBox3.Location = new System.Drawing.Point(32, 352);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(112, 48);
			this.groupBox3.TabIndex = 13;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Cascade";
			// 
			// textBoxNewCascade
			// 
			this.textBoxNewCascade.Location = new System.Drawing.Point(200, 368);
			this.textBoxNewCascade.Name = "textBoxNewCascade";
			this.textBoxNewCascade.Size = new System.Drawing.Size(80, 21);
			this.textBoxNewCascade.TabIndex = 16;
			this.textBoxNewCascade.Text = "0";
			// 
			// groupBox4
			// 
			this.groupBox4.Location = new System.Drawing.Point(184, 352);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(112, 48);
			this.groupBox4.TabIndex = 15;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "New Cascade";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.ClientSize = new System.Drawing.Size(440, 422);
			this.Controls.Add(this.textBoxNewCascade);
			this.Controls.Add(this.groupBox4);
			this.Controls.Add(this.textBoxCascade);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.textBoxNewPassword);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.textBoxPassword);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.Setpasswordbutton);
			this.Controls.Add(this.SetCascadebutton);
			this.Controls.Add(this.DisableSharebutton);
			this.Controls.Add(this.DogConvertbutton);
			this.Controls.Add(this.GetCurNoButton);
			this.Controls.Add(this.WriteDogbutton);
			this.Controls.Add(this.ReadDogbutton);
			this.Controls.Add(this.DogCheckbutton);
			this.Controls.Add(this.DogInfo);
			this.Name = "Form1";
			this.Text = "CSharpDemo";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private unsafe void DogCheckbutton_Click(object sender, System.EventArgs e)
		{	

			dog.DogCascade= (ushort)Convert.ToInt32(textBoxCascade.Text);
			dog.DogPassword= (uint)Convert.ToInt32(textBoxPassword.Text);

			dog.CheckDog();
			if(dog.Retocde==0)
			{
				DogInfo.Text="Dog check succeeded!" ;
			}
			else
			{
				DogInfo.Text="Dog check failed!The errcode is:" +dog.Retocde;
			}
		}

		private unsafe void ReadDogbutton_Click(object sender, System.EventArgs e)
		{
			dog.DogCascade= (ushort)Convert.ToInt32(textBoxCascade.Text);
			dog.DogPassword= (uint)Convert.ToInt32(textBoxPassword.Text);
			dog.DogAddr=0;
			dog.DogBytes=4;

			dog.ReadDog();
			if(dog.Retocde==0)
			{
				DogInfo.Text="Read dog succeeded!The data is:" +dog.DogData[0]+dog.DogData[1]+dog.DogData[2]+dog.DogData[3];
			}
			else
			{
				DogInfo.Text="Read dog failed!The errcode is:" +dog.Retocde;
			}
		
		}

		private unsafe void WriteDogbutton_Click(object sender, System.EventArgs e)
		{
			dog.DogCascade= (ushort)Convert.ToInt32(textBoxCascade.Text);
			dog.DogPassword= (uint)Convert.ToInt32(textBoxPassword.Text);
			dog.DogAddr=0;
			dog.DogBytes=4;
			dog.DogData[0]=0;dog.DogData[1]=1;dog.DogData[2]=2;dog.DogData[3]=3;

			dog.WriteDog();

			if(dog.Retocde==0)
			{
				DogInfo.Text="Write dog succeeded!The data is:" +dog.DogData[0]+dog.DogData[1]+dog.DogData[2]+dog.DogData[3];
			}
			else
			{
				DogInfo.Text="Write dog failed!The errcode is:" +dog.Retocde;
			}
		
		}

		private unsafe void GetCurNoButton_Click(object sender, System.EventArgs e)
		{
			dog.DogCascade= (ushort)Convert.ToInt32(textBoxCascade.Text);
			dog.DogPassword= (uint)Convert.ToInt32(textBoxPassword.Text);
			dog.GetCurrentNoDog();

			if(dog.Retocde==0)
			{
				DogInfo.Text="Get current number succeeded!The current number is:" +dog.CurrentNu;
			}
			else
			{
				DogInfo.Text="Get current number failed!The errcode is:" +dog.Retocde;
			}
		}

		private unsafe void DogConvertbutton_Click(object sender, System.EventArgs e)
		{
			dog.DogCascade= (ushort)Convert.ToInt32(textBoxCascade.Text);
			dog.DogPassword= (uint)Convert.ToInt32(textBoxPassword.Text);				
			dog.DogBytes=4;
			dog.DogData[0]=0;dog.DogData[1]=1;dog.DogData[2]=2;dog.DogData[3]=3;

			dog.ConvertDog();

			if(dog.Retocde==0)
			{
				DogInfo.Text="Convert data succeeded!The dogresult is:" +dog.DogResult;
			}
			else
			{
				DogInfo.Text="Convert data failed!The errcode is:" +dog.Retocde;
			}
		
		}

		private unsafe void DisableSharebutton_Click(object sender, System.EventArgs e)
		{
			dog.DogCascade= (ushort)Convert.ToInt32(textBoxCascade.Text);
			dog.DogPassword= (uint)Convert.ToInt32(textBoxPassword.Text);
 
			dog.DisableShareDog();
			if(dog.Retocde==0)
			{
				DogInfo.Text="Disableshare succeeded!" ;
			}
			else
			{
				DogInfo.Text="Disableshare failed!The errcode is:" +dog.Retocde;
			}
		}

		private unsafe void SetCascadebutton_Click(object sender, System.EventArgs e)
		{
			DogInfo.ResetText();
			dog.DogCascade= (ushort)Convert.ToInt32(textBoxCascade.Text);
			dog.DogPassword= (uint)Convert.ToInt32(textBoxPassword.Text);
			dog.NewCascade= (ushort)Convert.ToInt32(textBoxNewCascade.Text); 
			dog.SetCascadeDog();

			if(dog.Retocde==0)
			{

				DogInfo.AppendText("Set cascade succeeded!\n");
				DogInfo.AppendText("The old cascade is:");
				DogInfo.AppendText(Convert.ToString(dog.DogCascade,10));
				DogInfo.AppendText("\n");
				DogInfo.AppendText("The new cascade is:");
				DogInfo.AppendText(Convert.ToString(dog.NewCascade,10));
				textBoxCascade.Text = Convert.ToString(dog.NewCascade,10);
				//textBoxCascade.Text = "1";
			}
			else
			{
				DogInfo.Text="Set Cascade failed!\nThe errcode is:" +dog.Retocde;
			}
		}

		private unsafe void Setpasswordbutton_Click(object sender, System.EventArgs e)
		{
			DogInfo.ResetText();
			dog.DogCascade= (ushort)Convert.ToInt32(textBoxCascade.Text);
			dog.DogPassword= (uint)Convert.ToInt32(textBoxPassword.Text);
			dog.NewCascade= (ushort)Convert.ToInt32(textBoxNewCascade.Text); 
			dog.NewPassword= (uint)Convert.ToInt32(textBoxNewPassword.Text);
			dog.SetPasswordDog();

			if(dog.Retocde==0)
			{

				DogInfo.AppendText("Set Password succeeded!\n");
				DogInfo.AppendText("The old password is:");
				DogInfo.AppendText(Convert.ToString(dog.DogPassword,10));
				DogInfo.AppendText("\n");
				DogInfo.AppendText("The new password is:");
				DogInfo.AppendText(Convert.ToString(dog.NewPassword,10));
				textBoxPassword.Text = Convert.ToString(dog.NewPassword,10);
			}
			else
			{
				DogInfo.Text="Set Password failed!\nThe errcode is:" +dog.Retocde;
			}
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			
		}
	}
}
