		     -------------------------------------------------------
                               MicroDog Suite 32-bit Windows Application
                                    Illustration of DLL sample 
                     -------------------------------------------------------
                         Copyright (c) 2003, Rainbow China Co., Ltd.
  
     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of MicroDog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.


=========
Functions
=========
  MicroDog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, 
writing data into and reading data from the memory, changing data, checking the current 
manufacturing number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well. The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte descriptors 
can be selected for each algorithm, thus more than 16 million different algorithm descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is Activated.
  The six basic functions specified above will secure your software products from any unauthorized use. 
For detailed description of protection strategy, please read The Developer's Manual .


=========
File list
=========
   File name             Description
   --------------        -----------------------------------------------------
   README-ENG.TXT        Readme file     
   Highdll    <DIR>      High intensity DLL and example for VC
   Normaldll  <DIR>      Normal DLL and example for delphi,installshield,pb,vb,vba,vc and 			 visual foxpro
   Otherdll   <DIR>      Other DLL and example for C#,VB.NET and OMNI

===============================
Introduction to DLL programming
===============================
  Under 32-bit WINDOWS environment, the MicroDog Dynamic Linking Library can be made 
through MS Visual C++ or Borland C++ compiler. The approach is to call the MHWIN32C.OBJ
standard API (in win32\WIN32C\Msvc folder) in the DLL, so as to operate the MicroDog. Thus, 
the applications calling this DLL will be able to judge whether the proper MicroDog exists 
through the result of the operation. The application is then protected. See below the 
illustration for the calling to dynamic linking library by an application:
	  
          Application            DLL              MHWIN32C.OBJ
	  -----------            ---              ------------
	       |
	       |----------------> |
				  |----------------> |
					      Operate the Dog 
				  |<-----------------|
	       |<-----------------|
	       |

=================
Technical support
=================
   If you have any technical problems, please contact Rainbow China Co., Ltd., 
   our branches, or our distributors.  Be prepared to provide us your software part 
   number.  This will accelerate our help.

   Please Refer to  /Address.txt for the contact address.
   