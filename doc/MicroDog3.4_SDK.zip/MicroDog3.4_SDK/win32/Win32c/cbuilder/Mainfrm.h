//---------------------------------------------------------------------------

#ifndef MainfrmH
#define MainfrmH
//---------------------------------------------------------------------------
/*
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
*/
 #include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ExtCtrls.hpp>

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TButton *ButtonDisableShare;
        TButton *ButtonDogCheck;
        TButton *ButtonDogConvert;
        TButton *ButtonWriteDog;
        TButton *ButtonReadDog;
        TButton *ButtonGetCurrentNo;
        TButton *ButtonCancel;
        TGroupBox *GroupBox2;
        TLabel *LabelResult;
        TGroupBox *GroupBox3;
        TLabel *Label1;
        TLabel *Label2;
        TEdit *CurCascade;
        TEdit *CurrentPassword;
        TEdit *NewPassWord;
        TButton *ButtonSetCascade;
        TButton *ButtonSetPassword;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TEdit *NewCascade;
        void __fastcall ButtonDisableShareClick(TObject *Sender);
        void __fastcall ButtonDogCheckClick(TObject *Sender);
        void __fastcall ButtonDogConvertClick(TObject *Sender);
        void __fastcall ButtonWriteDogClick(TObject *Sender);
        void __fastcall ButtonReadDogClick(TObject *Sender);
        void __fastcall ButtonGetCurrentNoClick(TObject *Sender);
        void __fastcall ButtonSetPasswordNoClick(TObject *Sender);
        void __fastcall ButtonSetCascadeNoClick(TObject *Sender);
        void __fastcall ButtonCancelClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
