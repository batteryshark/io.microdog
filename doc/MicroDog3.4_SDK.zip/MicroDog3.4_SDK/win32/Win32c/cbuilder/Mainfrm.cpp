//---------------------------------------------------------------------------

#include <vcl\vcl.h>
#pragma hdrstop
#include <stdio.h>

#include "Mainfrm.h"
#include "gsmh.h"

short int DogBytes,DogAddr;
unsigned long DogPassword,NewPassword;
unsigned long DogResult;
unsigned char DogCascade;
void * DogData;

      

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonDisableShareClick(TObject *Sender)
{
    DWORD dwStatus;
    char Message[500];

    DogCascade = StrToInt(CurCascade->Text);
    dwStatus = DisableShare();
    if (dwStatus == 0)
    {
    	wsprintf (Message,"disable share succeeded.");
    }
    else
    {
    	wsprintf (Message,"disable share failed, error: %ld.",dwStatus);
    }
    LabelResult->SetTextBuf(Message);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonDogCheckClick(TObject *Sender)
{
    DWORD dwStatus;
    char Message[500];

    DogCascade = StrToInt(CurCascade->Text);
    dwStatus = DogCheck();
    if (dwStatus==0)
    {
    	wsprintf (Message,"check dog succeeded.");
    }
    else
    {
    	wsprintf (Message,"check dog failed, error: %ld.",dwStatus);
    }

    LabelResult->SetTextBuf(Message);

}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonDogConvertClick(TObject *Sender)
{
    DWORD dwStatus;
    char Message[500];
    char ConvertData[]="112233";
    DogCascade = StrToInt(CurCascade->Text);
    DogBytes = 6;
    DogData = ConvertData;
    dwStatus = DogConvert();
    if (dwStatus==0)
    {
        wsprintf (Message, " convert succeeded.\r convert string = %s\r result = %ld   (0x%lX)",ConvertData,DogResult,DogResult);
    }
    else
    {
        wsprintf (Message, " convert failed.\r error code = %ld", dwStatus);
    }
    LabelResult->SetTextBuf(Message);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonWriteDogClick(TObject *Sender)
{
    DWORD dwStatus;
    DWORD dwData = 12345678;
    WORD  wData = 1234;
    float fData = 3.1415926F;
    char szData[] = "112233";
    char Message[300],msg[100];
    Message[0] = 0;
    DogCascade = StrToInt(CurCascade->Text);
    DogBytes = 6;
    DogPassword = StrToInt(CurrentPassword->Text);
    DogData = szData;
    DogAddr = 0;
    dwStatus = WriteDog();
    if (dwStatus==0)
    {
        wsprintf (msg, " write string succeeded.\r write: \"%s\"  at: %d\r\r",szData,DogAddr);
    }
    else
    {
        wsprintf (msg, " write string failed.\r error code = %ld\r\r", dwStatus);
    }
    strcat (Message,msg);

    DogBytes = 4;
    DogData = & dwData;
    DogAddr = 10;
    dwStatus = WriteDog();
    if (dwStatus==0)
    {
        wsprintf (msg, " write dword data succeeded.\r write: %ld   at: %d\r\r",dwData,DogAddr);
    }
    else
    {
        wsprintf (msg, " write dword data failed.\r error code = %ld\r\r", dwStatus);
    }
    strcat (Message,msg);

    DogBytes = 2;
    DogData = & wData;
    DogAddr = 20;
    dwStatus = WriteDog();
    if (dwStatus==0)
    {
        wsprintf (msg, " write word data succeeded.\r write: %d   at: %d\r\r",wData,DogAddr);
    }
    else
    {
        wsprintf (msg, " write word data failed.\r error code = %ld\r\r", dwStatus);
    }
    strcat (Message,msg);

    DogBytes = 4;
    DogData = & fData;
    DogAddr = 30;
    dwStatus = WriteDog();
    if (dwStatus==0)
    {
        sprintf (msg, " write float data succeeded.\r write %e   at: %d",fData,DogAddr);
    }
    else
    {
        wsprintf (msg, " write float failed.\r error code = %ld", dwStatus);
    }
    strcat (Message,msg);

    LabelResult->SetTextBuf(Message);


}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonReadDogClick(TObject *Sender)
{
        DWORD dwStatus;
	DWORD dwData ;
	WORD  wData ;
	float fData;
	char szData[10] ;
	char Message[300],msg[100];

	Message[0] = 0;

        DogCascade = StrToInt(CurCascade->Text);
	DogBytes = 6;
	szData[6] = 0;
	DogPassword = StrToInt(CurrentPassword->Text);
	DogData = szData;
	DogAddr = 0;
	dwStatus = ReadDog();
	if (dwStatus==0)
	{
		wsprintf (msg, " read string succeeded.\r read: \"%s\"  from: %d\r\r",szData,DogAddr);
	}
	else
	{
		wsprintf (msg, " read string failed.\r error code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	DogBytes = 4;
	DogData = & dwData;
	DogAddr = 10;
	dwStatus = ReadDog();
	if (dwStatus==0)
	{
		wsprintf (msg, " read dword data succeeded.\r read: %ld   from: %d\r\r",dwData,DogAddr);
	}
	else
	{
		wsprintf (msg, " read dword data failed.\r error code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	DogBytes = 2;
	DogData = & wData;
	DogAddr = 20;
	dwStatus = ReadDog();
	if (dwStatus==0)
	{
		wsprintf (msg, " read word data succeeded.\r read: %d   from: %d\r\r",wData,DogAddr);
	}
	else
	{
		wsprintf (msg, " read word data failed.\r error code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	DogBytes = 4;
	DogData = & fData;
	DogAddr = 30;
	dwStatus = ReadDog();
	if (dwStatus==0)
	{
		sprintf (msg, " read float data succeeded.\r read: %e   from: %d",fData,DogAddr);
	}
	else
	{
		wsprintf (msg, " read float failed.\r error code = %ld", dwStatus);
	}
	strcat (Message,msg);

    LabelResult->SetTextBuf(Message);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonGetCurrentNoClick(TObject *Sender)
{
   	DWORD dwStatus;
	char Message[100];
	DWORD CurrentNo;

        DogCascade = StrToInt(CurCascade->Text);
	DogData = & CurrentNo;
	dwStatus = GetCurrentNo();
	if (dwStatus==0)
	{
		wsprintf (Message, " get current No. succeeded.\r current No. = %u",CurrentNo, CurrentNo);
	}
	else
	{
		wsprintf (Message, " get current No. failed.\r error code = %u", dwStatus);
	}

    LabelResult->SetTextBuf(Message);
}


void __fastcall TForm1::ButtonSetPasswordNoClick(TObject *Sender)
{
   	DWORD dwStatus;
	char Message[100];
	DWORD CurrentNo;

        DogCascade = StrToInt(CurCascade->Text);
	DogData = & CurrentNo;
        DogPassword=  StrToInt(CurrentPassword->Text);
        NewPassword= StrToInt(NewPassWord->Text);
	dwStatus = SetPassword();
	if (dwStatus==0)
	{
		wsprintf (Message, " Set Password succeeded.\r");
                CurrentPassword->Text=NewPassWord->Text;
	}
	else
	{
		wsprintf (Message, " Set Password  failed.\r error code = %u", dwStatus);
	}

    LabelResult->SetTextBuf(Message);
}
void __fastcall TForm1::ButtonSetCascadeNoClick(TObject *Sender)
{
   	DWORD dwStatus;
	char Message[100];
	DWORD CurrentNo;
        DWORD dwNewCascade;

        DogCascade = StrToInt(CurCascade->Text);
        dwNewCascade=StrToInt(NewCascade->Text);
	DogData = & dwNewCascade;
        DogPassword=  StrToInt(CurrentPassword->Text);
	dwStatus = SetDogCascade();
	if (dwStatus==0)
	{
		wsprintf (Message, " Set Cascade succeeded.\r");
                CurCascade->Text=NewCascade->Text;
	}
	else
	{
		wsprintf (Message, " Set Cascade  failed.\r error code = %u", dwStatus);
	}

    LabelResult->SetTextBuf(Message);
}

//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonCancelClick(TObject *Sender)
{
  	Close();
}
//---------------------------------------------------------------------------


