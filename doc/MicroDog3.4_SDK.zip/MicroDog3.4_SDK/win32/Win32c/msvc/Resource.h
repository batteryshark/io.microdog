//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dogdemo.rc
//
#define ID_CANCEL                       10002
#define IDC_STATIC                      -1
#define IDM_ABOUT                       100
#define IDM_DEMO                        101
#define IDD_DIALOG                      101
#define IDC_BUTTON_WRITE                1002
#define IDC_BUTTON_READ                 1003
#define IDC_BUTTON_SN                   1004
#define IDC_RADIO_INTEGER               1005
#define IDC_RADIO_LONG                  1006
#define IDC_RADIO_FLOAT                 1007
#define IDC_RADIO_STRING                1008
#define IDC_STATIC_OPERATION            1009
#define IDC_STATIC_RESULT               1010
#define IDC_BUTTON_CURNO                1011
#define IDC_BUTTON_CHECK                1012
#define IDC_BUTTON_CONVERT              1013
#define IDC_EDIT_PASSWORD               1014
#define IDC_BUTTON_ENABLE               1016
#define IDC_BUTTON_DISABLE              1017
#define IDC_BUTTON_SETCASCADE			1018
#define IDC_BUTTON_SETPASSWORD			1019
#define IDC_EDIT_CUR_CASCADE			1020
#define IDC_EDIT_NEW_CASCADE			1021
#define IDC_EDIT_CUR_PASSWORD			1022
#define IDC_EDIT_NEW_PASSWORD			1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
