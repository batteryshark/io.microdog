/****************************************************************************

    PROGRAM: DOGDEMO

    PURPOSE: This application demonstrates how to invoke the dog's
             API for Win32 Application

    Copyright 2001 Rainbow China Co.,Ltd. All Rights Reserved

****************************************************************************/

#include "windows.h"		    /* required for all Windows applications */
#include "string.h"
#include "stdio.h"
#include "dogdemo.h"                /* specific to this program              */
#include "resource.h"

#include "gsmh.h"

short int DogAddr,DogBytes;
unsigned long DogPassword,NewPassword, DogResult;
unsigned char DogCascade;
void far * DogData;

HANDLE hInst;

/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

****************************************************************************/

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{

    DLGPROC lpDialogProc;

    hInst = hInstance;

    lpDialogProc = MakeProcInstance(DemoDlg, hInstance);

    DialogBox(hInstance,(LPCSTR)IDD_DIALOG, NULL,lpDialogProc);

    FreeProcInstance(lpDialogProc);

    return 0;
}


/****************************************************************************

    FUNCTION: About(HWND, unsigned, WORD, LONG)

****************************************************************************/

BOOL FAR PASCAL About(HWND hDlg, unsigned message, WORD wParam, LONG lParam)
{
    switch (message)
    {
    case WM_INITDIALOG:
	CenterWindow(hDlg);
        return (TRUE);

    case WM_COMMAND:                  
	if (wParam == IDOK|| wParam == IDCANCEL) {
	   EndDialog(hDlg, TRUE);
	   return (TRUE);
	}
	break;
    }
    return (FALSE);                       
}




/****************************************************************************

    FUNCTION: OnDialogInit (HWND)

****************************************************************************/

void OnDialogInit(HWND hDlg)
{
	HMENU hSysMenu;

	hSysMenu = GetSystemMenu(hDlg,FALSE);
    AppendMenu (hSysMenu,MF_SEPARATOR,0,0);
    AppendMenu (hSysMenu,MF_STRING,IDM_ABOUT,"About...");
    RemoveMenu (hSysMenu,SC_SIZE,MF_BYCOMMAND);
    RemoveMenu (hSysMenu,SC_MAXIMIZE,MF_BYCOMMAND);
	RemoveMenu (hSysMenu,SC_MINIMIZE,MF_BYCOMMAND);
	
	SetDlgItemInt(hDlg,IDC_EDIT_PASSWORD,0,TRUE);

	CenterWindow(hDlg);
}


/****************************************************************************

    FUNCTION: OnButtonWriteClicked (HWND)

****************************************************************************/

void OnButtonCheck(HWND hDlg) 
{
	DWORD dwStatus;
	char Message[100];

	DogCascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	dwStatus = DogCheck();
	if (dwStatus==0)  
		strcpy(Message," check dog succeeded.");
	else 
		wsprintf ( Message, " check dog failed.\r error code = %ld",dwStatus);
	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
}

void OnButtonConvert(HWND hDlg) 
{
	char ConvertData[]="112233";
	DWORD dwStatus;
	char Message[100];

	DogCascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	DogBytes = 6;
	DogData = ConvertData;
        DogResult=0;
	dwStatus = DogConvert();
	if (dwStatus==0)
	{
		wsprintf (Message, " convert succeeded.\r convert string=%s\r result=%ld   (0x%lX)",ConvertData,DogResult,DogResult);
	}
	else
	{
		wsprintf (Message, " convert failed.\r error code = %ld", dwStatus);
	}
	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
}

void OnButtonWrite(HWND hDlg) 
{
	DWORD dwStatus;
	DWORD dwData = 12345678;
	WORD  wData = 1234;
	float fData = 3.1415926F;
	char szData[] = "112233";
	char Message[300],msg[100];


	Message[0] = 0;

	DogPassword = GetDlgItemInt ( hDlg,IDC_EDIT_PASSWORD,NULL,TRUE );
	DogCascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );

	DogData = szData;
	DogAddr = 0;
	DogBytes = 6;
	dwStatus = WriteDog();
	if (dwStatus==0)
	{
		wsprintf (msg, " write string succeeded.\r write: \"%s\"  at: %d\r\r",szData,DogAddr);
	}
	else
	{
		wsprintf (msg, " write string failed.\r error code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	DogBytes = 4;
	DogData = & dwData;
	DogAddr = 10;
	dwStatus = WriteDog();
	if (dwStatus==0)
	{
		wsprintf (msg, " write dword data succeeded.\r write: %ld   at: %d\r\r",dwData,DogAddr);
	}
	else
	{
		wsprintf (msg, " write dword data failed.\r error code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	DogBytes = 2;
	DogData = & wData;
	DogAddr = 20;
	dwStatus = WriteDog();
	if (dwStatus==0)
	{
		wsprintf (msg, " write word data succeeded.\r write: %d   at: %d\r\r",wData,DogAddr);
	}
	else
	{
		wsprintf (msg, " write word data failed.\r error code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	DogBytes = 4;
	DogData = & fData;
	DogAddr = 30;
	dwStatus = WriteDog();
	if (dwStatus==0)
	{
		sprintf (msg, " write float data succeeded.\r write %e   at: %d",fData,DogAddr);
	}
	else
	{
		wsprintf (msg, " write float failed.\r error code = %ld", dwStatus);
	}
	strcat (Message,msg);

	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);

}

void OnButtonRead(HWND hDlg)
{

	DWORD dwStatus;
	DWORD dwData ;
	WORD  wData ;
	float fData;
	char szData[10] ;
	char Message[300],msg[100];

	Message[0] = 0;

	DogPassword = GetDlgItemInt ( hDlg,IDC_EDIT_PASSWORD,NULL,TRUE );
	DogCascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );

	DogData = szData;
	DogAddr = 0;
	DogBytes = 6;
	szData[6] = 0;
	dwStatus = ReadDog();
	if (dwStatus==0)
	{
		wsprintf (msg, " read string succeeded.\r read: \"%s\"  from: %d\r\r",szData,DogAddr);
	}
	else
	{
		wsprintf (msg, " read string failed.\r error code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	DogBytes = 4;
	DogData = & dwData;
	DogAddr = 10;
	dwStatus = ReadDog();
	if (dwStatus==0)
	{
		wsprintf (msg, " read dword data succeeded.\r read: %ld   from: %d\r\r",dwData,DogAddr);
	}
	else
	{
		wsprintf (msg, " read dword data failed.\r error code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	DogBytes = 2;
	DogData = & wData;
	DogAddr = 20;
	dwStatus = ReadDog();
	if (dwStatus==0)
	{
		wsprintf (msg, " read word data succeeded.\r read: %d   from: %d\r\r",wData,DogAddr);
	}
	else
	{
		wsprintf (msg, " read word data failed.\r error code = %ld\r\r", dwStatus);
	}
	strcat (Message,msg);

	DogBytes = 4;
	DogData = & fData;
	DogAddr = 30;
	dwStatus = ReadDog();
	if (dwStatus==0)
	{
		sprintf (msg, "read float data succeeded.\r read: %e   from: %d",fData,DogAddr);
	}
	else
	{
		wsprintf (msg, "read float failed.\r error code = %ld", dwStatus);
	}
	strcat (Message,msg);
	
	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
	
}

void OnButtonDisable(HWND hDlg) 
{
	DWORD dwStatus;
	char Message[100];

	DogCascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	dwStatus = DisableShare();
	if (dwStatus==0)
	{
		wsprintf (Message, " disable share succeeded.");
	}
	else
	{
		wsprintf (Message, " disable failed.\r error code = %ld", dwStatus);
	}
	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
}

void OnButtonCurno(HWND hDlg) 
{
	DWORD dwStatus;
	char Message[100];
	DWORD CurrentNo;

	DogCascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	DogData = & CurrentNo;
	dwStatus = GetCurrentNo();
	if (dwStatus==0)
	{
		wsprintf (Message, " get current No. succeeded.\r current No. = %u",CurrentNo, CurrentNo);
	}
	else
	{
		wsprintf (Message, " get current No. failed.\r error code = %ld", dwStatus);
	}

	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
}


void OnButtonSetCascade(HWND hDlg) 
{

	DWORD dwStatus;
	char Message[100];
	DWORD NewCascade;

	DogCascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	DogPassword = GetDlgItemInt ( hDlg,IDC_EDIT_PASSWORD,NULL,TRUE );
	NewCascade= GetDlgItemInt ( hDlg,IDC_EDIT_NEW_CASCADE,NULL,TRUE );
	DogData = & NewCascade;
	dwStatus = SetDogCascade();
	if (dwStatus==0)
	{
		wsprintf (Message, " Set Cascade succeeded.\r");
		SetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NewCascade,TRUE );
	}
	else
	{
		wsprintf (Message, " Set Cascade  failed.\r error code = %ld", dwStatus);
	}

	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
		
}


void OnButtonSetPassword(HWND hDlg) 
{

	DWORD dwStatus;
	char Message[100];
	DWORD NewCascade;

	DogCascade = GetDlgItemInt ( hDlg,IDC_EDIT_CASCADE,NULL,TRUE );
	DogPassword = GetDlgItemInt ( hDlg,IDC_EDIT_PASSWORD,NULL,TRUE );
	NewPassword= GetDlgItemInt ( hDlg,IDC_EDIT_NEW_PASSWORD,NULL,TRUE );
	
	dwStatus = SetPassword();
	if (dwStatus==0)
	{
		wsprintf (Message, " Set Password succeeded.\r");
		SetDlgItemInt ( hDlg,IDC_EDIT_PASSWORD,NewPassword,TRUE );
	}
	else
	{
		wsprintf (Message, " Set Password failed.\r error code = %ld", dwStatus);
	}

	SetWindowText ( GetDlgItem( hDlg, IDC_STATIC_RESULT ), Message);
		
}

/****************************************************************************

    FUNCTION: DemoDlg(HWND, unsigned, WORD, LONG)

****************************************************************************/

BOOL FAR PASCAL DemoDlg(HWND hDlg, unsigned message, WORD wParam, LONG lParam)
{
	FARPROC lpProcAbout;
    
    switch (message)
    {

    case WM_INITDIALOG:
        OnDialogInit(hDlg);
		return (TRUE);

    case WM_COMMAND:
		switch(wParam)
        {
		case IDCANCEL:
			EndDialog(hDlg, TRUE);
			return (TRUE);
		
		case IDC_BUTTON_CHECK:
			OnButtonCheck(hDlg);
			break;
		
		case IDC_BUTTON_CURNO:
			OnButtonCurno(hDlg);
			break;
		
		case IDC_BUTTON_CONVERT:
			OnButtonConvert(hDlg);
			break;
		
		case IDC_BUTTON_WRITE:
			OnButtonWrite(hDlg);
			break;
		
		case IDC_BUTTON_READ:
			OnButtonRead(hDlg);
			break;

		case IDC_BUTTON_DISABLE:
			OnButtonDisable(hDlg);
			break;
		case IDC_BUTTON_SetCascade:
			OnButtonSetCascade(hDlg);
			break;
		case IDC_BUTTON_SetPassword:
			OnButtonSetPassword(hDlg);
			break;	
			
		}
		break;

	case WM_SYSCOMMAND:
        if (wParam==IDM_ABOUT)
        {
			lpProcAbout = MakeProcInstance(About, hInst);
			DialogBox(hInst,"AboutBox",hDlg,lpProcAbout);
			FreeProcInstance(lpProcAbout);
        }
        break;
    }
    return (FALSE);                       
}

void CenterWindow(HWND hWnd)
{
    RECT rect;
    int systemX,systemY;
    int newX,newY;
	
    GetWindowRect(hWnd,&rect);
    systemX=GetSystemMetrics(SM_CXFULLSCREEN);
    systemY=GetSystemMetrics(SM_CYFULLSCREEN);
	
    newX = (systemX-(rect.right-rect.left))/2;
    newY = (systemY-(rect.bottom-rect.top))/2;

    SetWindowPos(hWnd,NULL,newX,newY,0,0,SWP_NOSIZE);
}
