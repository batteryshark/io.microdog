

                  -------------------------------------------------------
	                    MicroDog Suite 32-bit WINDOWS Application
                                     API Guide to C/C++
                  -------------------------------------------------------

                        Copyright (c) 2003, Rainbow China Co., Ltd.
  
     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of MicroDog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

   The API module for C/C++ language is a module for WINDOWS 9x/NT/2000 and is suitable for protecting C /C++ application.

=========
Functions
=========
  Microdog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.  Microdog Suite has six basic functions 
including verifying of the correct Hardware Dog, writing data into and reading data from the 
memory, changing data, checking the current manufacturing number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six basic functions specified above will secure your software products from any unauthorized use. 
For detailed description of protection strategy, please read The Developer's Manual .

=========
File list
=========
   File name             Description
   --------------        -----------------------------------------------------
   README-ENG.TXT        This file
   BORLANDC <DIR>        Application interface module and calling example
                         For BORLAND C++ compiler
   CBUILDER <DIR>        Calling BorlandC interface example written with 
                         C++Builder
   MFCDEMO  <DIR>        Calling Win32C interface example written with MFC 
                         (for Visual C++)
   MSVC     <DIR>        Application interface module and calling example
                         (for MS VC compiler)

===================
Tested Environments
===================
  Microsoft Visual C++ 2.0 - 6.0 ( Use the OBJ under MSVC in linking)
  Borland C++ 4.5 - 5.0  ( Use the OBJ under BORLANDC in linking) 
  C++ Builder 1.0 - 5.0  ( Use the OBJ under BORLANDC in linking)


=============
API Functions
=============
  The APIs here refer to the file .OBJ. The version used by MFCDEMO and MSVC is 
MHWIN32C.OBJ.We put it into the directory MSVC.The version used by BORLAND C and 
C++ BUILDER is MHWIN32BC.OBJ. Please Include the head file GSMH.H when coding.

     
  1. API define the following functions:
       unsigned long  DogCheck(void);         //check the dog     
       unsigned long  ReadDog(void);          //read the dog
       unsigned long  WriteDog(void);         //write the dog
       unsigned long  DogConvert(void);       //change
       unsigned long  GetCurrentNo(void);     //get the Manufacturing code
       unsigned long  DisableShare(void);     //disable share
       unsigned long  SetPassword(void)           //set password
       unsigned long  SetDogCascade(void)         //set cascade
   

   
  2. Developers must define the following global variables in their application:
       short int DogAddr           //The beginning address of the storing (0~199)
       short int DogBytes          //Size of operation data(1~200)
       unsigned long DogPassword   //Password
       unsigned long NewPassword   //NewPassword
       unsigned long DogResult     //Result of conversion
       void * DogData              //A pointer points to operation data
       unsigned char DogCascade    //Used for RC-MH dog. The DogCascade in the USBdog must 
                                   //be 0     


  3. unsigned long DogCheck(void)
     Input parameter: DogCascade
     Output parameter: None
     Return value: Returns zero if successful; returns an error code if the function fails.
     Function: Checks whether the hardware Dog exists.  Only a Dog that has the same serial
               number as the OBJ file can be detected.This version supports the cascading 
               function of RC-MH dog of same serial number.The DogCascade in the USBdog must
               be 0.   


  4. unsigned long ReadDog(void)
     Input parameter:  DogCascade, DogAddr, DogBytes, DogData, DogPassword
     Output parameter:  DogData
     Return value:     0 = operation succeeded. All others are error codes.
     Function: Reads data from the hardware Dog. The Dog contains a 200-byte nonvolatile 
               memory.  ReadDog reads data from the Dog memory beginning at the address 
               indicated by DogAddr.  The bytes number of the read data is indicated 
               by DogBytes.  The read data is stored in the space DogData points to.
               MicroDog verifies the DogPassword. DogPassword is the password for
               read/write operations stored on the hardware Dog.  It can be set by the 
               utility tool DOGEDT32.EXE in UTILITY folder or the SetPassword() function. 
               Applications must ensure enough space to buffer the data being read.ReadDog 
               does not check whether the buffer size is sufficient.


  5. unsigned long WriteDog(void)
     Input parameter: DogCascade, DogAddr, DogBytes, DogData, DogPassword
     Output parameter: None
     Return value: Returns zero if successful; returns an error code if the function fails.
     Function: Writes data to the hardware Dog. Carries out the same operation as ReadDog,
              except that the data flow direction is different.

     *Caution:
         The last 4 bytes are used to define the conversion algorithm. Therefore, better
         not use these 4 bytes unless you want to change the algorithm.
  

  6. unsigned long DogConvert(void)
     Input parameter: DogCascade, DogBytes, DogData
     Output parameter: DogResult
     Return value: Returns zero if successful; returns an error code if the function fails.
     Function: Transfers data to MicroDog.  The hardware Dog converts the data 
               and returns the converted result Dogresult as a 32-bit integer. 
               DogBytes indicates the number of bytes of the date, which DogData 
               points to, being converted.The conversion algorithm can be specified
               by the developer.  
     *Caution: The last 4 bytes of memory affects the conversion 
              algorithm.  The 196th byte is used to specify the algorithm.  Therefore,
              a developer can define 256 kinds of algorithms. The algorithm descriptors
              are made up of the 197th, 198th and 199th byte, so it have a maximum of 
              16,777,215 different combinations.
               
          
  7. unsigned long DisableShare(void)
     Input parameter: DogCascade
     Output parameter: None
     Return value: Returns zero if successful; returns an error code if the function fails.
     Function: Disable the hardware Dog's sharing ability.The parallel port hub is a kind of
               hardware share device that allows multiple copies of the protected program share
               the same Dog.Factory setting for share ability is Enable. You may call DisableShare 
               function to prevent pirates from using a parallel port hub. Sothat only the machine 
               that has the Dog can run the protected program.DisableShare only affects the functions 
               ReadDog, WriteDog and DogConvert. 

     * Caution:
             Do not call on this function multiple times. It is designed to be called no more
             than once in an application.


  8. unsigned long GetCurrentNo(void)
     Input Parameter: DogCascade, DogData
     Output parameter: DogData
     Return value: Returns zero if successful; returns an error code if the function fails.
     Function: Reads the Manufacturing code of the hardware Dog.Some of the hardware
               Dogs may have the same ID, but every hardware Dog has its unique
               Manufacturing code. The Manufacturing code can help developers manage
               user accounts.The Manufacturing code is 4 bytes.


  9. unsigned long SetPassword(void)
     Input parameter: DogCascade, DogPassword, NewPassword
     Output parameter: None
     Return value: Returns zero if successful; returns an error code if the function fails.
     Function: Modifies the Dog password.DogPassword is the current password, and NewPassword
               is the one that would replace it.


  10. unsigned long SetDogCascade(void)
      Input parameter: DogCascade, DogPassword, DogData
      Output parameter: None
      Return value: Returns zero if successful; returns an error code if the function fails.
      Function: Set the DogCascade. The new cascade is put into the DogData.

============
Error code
============
   Refer to ERRCODE.TXT in the root of the installation directory for detailed 
   information about error codes.


=========
Cautions
=========
  1. When you write data to the Dog, changing the last 4 bytes of the 
     memory will affect the result of function DogConvert().

  2. This version of software can operate the GS-MD/GS-MF,but it can't 
     use the new function of the GS-MH. The return value is without 
     meaning when calling DisableShare and GetCurrentNo.
   
  3. If you want to operate GS-MD/GS-MF,the functions  DogCheck,DogConvert are 
     related with DogPassword.Please set the DogPassword first when calling the 2 
     functions.

 4. When you use the MS VC/C++ compiler to compile and link your program and 
    MHWN32C.OBJ, there may be a link warning: "LINK : warning LNK4098: 
    defaultlib "LIBC" conflicts with use of other libs; use /NODEFAULTLIB:library" 
    or similar information. This is caused by running different lib types: MHWIN32C.OBJ
    is defaulted to use single thread LIBC.LIB, and your program maybe use multi-thread
    running lib. You may ignore this warning. If you do not want to see it again, 
    you can add this link parameter: "/NODEFAULTLIB:libc.lib".
 
 5. The protected application needs installing device driver program when running
    on Windows 98, Windows ME, Windows 2000 and Windows XP. 

 6. Both the USBdog and the Microdog can be used to protect applications when
    running on Windows 98, Windows ME, Windows 2000 and Windows XP.


=================
Technical support
=================
   If you have any technical problems, please contact Rainbow China Co., Ltd., 
   our branches, or our distributors.  Be prepared to provide us your software part 
   number.  This will accelerate our help.

   The part number of this module is RC-UMH-LM-W32INTF   version number is 3.4.9.0
   
   The version number can also be extracted by using Utility/Getver.exe.The two values
   should be same.  If not, refer to the result returned by Getver.exe  first.  The 
   version information can be helpful in pinpointing and solving problems.

   Please Refer to  /Address.txt for the contact address.





