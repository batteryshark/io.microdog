/////////////////////////////////////////////////////////////////////////
/* 
	Copyright (C) Rainbow China Co., Ltd.	
	All rights reserved.

  File name:	arxmfctmpl.h
  File description:	
	declare function table refered to Autolisp

*/ 
/////////////////////////////////////////////////////////////////////////
#ifndef _ARXMFCTMPL_H
#define _ARXMFCTMPL_H

#include "Demo.h"

// Define function table entry
typedef struct 
{
    char        *name;
    short		(*fptr)(struct resbuf *);
} FunctionTableEntry;


FunctionTableEntry g_FunctionTable[] = 
{
	{"DOGCHECK",      Check}, // <--- Replace with entries
	{"DOGCONVERT",    Convert}, // <--- for your functions
	{"WRITEDOG",      Write}, // <--- Replace with entries
	{"READDOG",       Read}, // <--- for your functions
	{"DISABLESHARE",  Disable}, // <--- Replace with entries
	{"GETCURRENTNO",  Curno}, // <--- Replace with entries
	{"SETPASSWORD",   Setp}, // <--- Replace with entries
	{"SETDOGCASCADE", Setc}, // <--- Replace with entries
};

#endif