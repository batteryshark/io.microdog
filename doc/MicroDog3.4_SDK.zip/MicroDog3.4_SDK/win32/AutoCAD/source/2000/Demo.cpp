/////////////////////////////////////////////////////////////////////////
/* 
	Copyright (C) Rainbow China Co., Ltd.	
	All rights reserved.

  File name:	Demo.cpp
  File description:	
	source file

*/ 
/////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Demo.h"

// *****************************************************************************************
// Declare function and variable refered from obj 
#ifdef  __cplusplus
extern "C" {
#endif

	/**************************************************************************/
	/*  EXTERNAL FUNCTION DECLARATIONS  */
	/**************************************************************************/
extern unsigned long DogCheck(void);
extern unsigned long ReadDog(void);
extern unsigned long DogConvert(void);
extern unsigned long WriteDog(void);
extern unsigned long DisableShare(void);
extern unsigned long GetCurrentNo(void);
extern unsigned long SetPassword(void);
extern unsigned long SetDogCascade(void);

	/**************************************************************************/
	/*  EXTERNAL VARIABLE DECLARATIONS  */
	/**************************************************************************/
unsigned char DogCascade;
		// Used for micro dog. The DogCascade in the USBdog must be 0    
unsigned short DogAddr;			
        // The beginning address of the storing (0~199)
unsigned short DogBytes;			
        //Size of operation data(1~200)
void  * DogData;
		// A pointer points to operation data
unsigned long DogResult;
		// Result of conversion
unsigned long DogPassword;
		// Password
unsigned long NewPassword;
		// NewPassword
#ifdef  __cplusplus
}
#endif

// ****************************************************************************************
short Check(struct resbuf *rb)
{
	union ads_u_val *resval;
	unsigned long dwStatus;
    unsigned int ret;
	struct resbuf *pBuffer = NULL;

	// get cascade passed by autolisp
	resval = getArg(rb,RTSHORT,0);	
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}

	DogCascade = (unsigned char)resval->rint;
	dwStatus = DogCheck();
	
	if (dwStatus==0)	// success
       ret = 0;
	else				// failed
       ret = dwStatus;

	pBuffer = ads_buildlist(RTLONG,ret,RTNONE);		//pass to autolisp with a list
	ads_retlist(pBuffer);
	ads_relrb(pBuffer);
	pBuffer = NULL;

	return 0;
}

short Convert(struct resbuf *rb)
{
	union ads_u_val *resval;
	unsigned long dwStatus;
	struct resbuf *pBuffer = NULL;

	// get cascade passed by autolisp
	resval = getArg(rb, RTSHORT, 0);  

	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	
	DogCascade = (unsigned char)resval->rint;

	// get bytes passed by autolisp
	resval = getArg(rb,RTSHORT,1);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}

	DogBytes = resval->rint;

	// get data passed by autolisp
	resval = getArg(rb,RTSTR,2);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogData = resval->rstring;

	dwStatus = DogConvert();

	pBuffer = ads_buildlist(RTLONG,dwStatus,RTLONG,DogResult,RTNONE);
	ads_retlist(pBuffer);
	ads_relrb(pBuffer);
	pBuffer = NULL;

	return 0;
		
}

//void Write() 
short Write(struct resbuf *rb)
{
	// TODO: Add your control notification handler code here
	union ads_u_val *resval;
	unsigned long dwStatus;
	struct resbuf *pBuffer = NULL;
	
	// get cascade passed by autolisp
	resval = getArg(rb,RTSHORT,0);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}

	DogCascade = (unsigned char)resval->rint;

	// get dogaddr passed by autolisp
	resval = getArg(rb, RTSHORT, 1);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogAddr = resval->rint;

	// get dogbytes passed by autolisp
	resval = getArg(rb, RTSHORT, 2);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogBytes = resval->rint;

	// get dogdata passed by autolisp
	resval = getArg(rb, RTSTR, 3);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogData = resval->rstring;	

	// get password passed by autolisp
	resval = getArg(rb, RTSHORT, 4); 
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogPassword = resval->rlong;

	dwStatus = WriteDog();
	pBuffer = ads_buildlist(RTLONG,dwStatus,RTNONE);
	ads_retlist(pBuffer);
	ads_relrb(pBuffer);

	return 0;
}

short Read(struct resbuf *rb)
{
    union ads_u_val *resval;
	unsigned long dwStatus;
	struct resbuf *pBuffer = NULL;

	// get cascade passed by autolisp
	resval = getArg(rb,RTSHORT,0);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogCascade = (unsigned char)resval->rint;

	// get dogaddr passed by autolisp
	resval = getArg(rb, RTSHORT, 1);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogAddr = resval->rint;

	// get dogbytes passed by autolisp
	resval = getArg(rb, RTSHORT, 2); 
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogBytes = resval->rint;

	// get password passed by autolisp
	resval = getArg(rb, RTSHORT, 3); 
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogPassword = resval->rlong;

	// allocate memory space for readdog
	char *lpstrData = new char[DogBytes+1];
	if (lpstrData == NULL)
	{
		ads_printf("allocate memory failed.");
		ads_retvoid();
		return 0;
	}
	
	memset(lpstrData,0,DogBytes+1);

	// read dog
	DogData = lpstrData;
	dwStatus = ReadDog();
	pBuffer = ads_buildlist(RTLONG,dwStatus,RTSTR,lpstrData,RTNONE);


	ads_retlist(pBuffer);
	delete lpstrData;
	ads_relrb(pBuffer);
	
   	return 0;
}

short Disable(struct resbuf *rb)
{
	unsigned long dwStatus;
	union ads_u_val *resval;
	struct resbuf *pBuffer = NULL;

	// get cascade passed by autolisp
	resval = getArg(rb,RTSHORT,0);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogCascade = (unsigned char)resval->rint;

	dwStatus = DisableShare();

	pBuffer = ads_buildlist(RTLONG,dwStatus,RTNONE);
	ads_retlist(pBuffer);
	ads_relrb(pBuffer);

    return 0;
}

short Curno(struct resbuf *rb)
{
	unsigned long dwStatus;
	unsigned long DogCurrentNo;
	struct resbuf *pBuffer = NULL;
	union ads_u_val *resval;

	// get cascade passed by autolisp
	resval = getArg(rb,RTSHORT,0);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogCascade = (unsigned char)resval->rint;

    DogData = &DogCurrentNo;
	dwStatus = GetCurrentNo();

	pBuffer = ads_buildlist(RTLONG,dwStatus,RTLONG,DogCurrentNo,RTNONE);
	ads_retlist(pBuffer);
	ads_relrb(pBuffer);

	return 0;
}

short Setp(struct resbuf *rb)
{
	union ads_u_val *resval;
	unsigned long dwStatus;
	struct resbuf *pBuffer = NULL;

	// get cascade passed by autolisp
	resval = getArg(rb,RTSHORT,0);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogCascade = (unsigned char)resval->rint;

	// get old password passed by autolisp
	resval = getArg(rb,RTSHORT,1);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogPassword = resval->rint;

	// get new password passed by autolisp
	resval = getArg(rb,RTSHORT,2);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	NewPassword = resval->rint;

	dwStatus = SetPassword();

	pBuffer = ads_buildlist(RTLONG,dwStatus,RTNONE);
	ads_retlist(pBuffer);
	ads_relrb(pBuffer);

	return 0;
}

short Setc(struct resbuf *rb)
{
	union ads_u_val *resval;
	unsigned long dwStatus;
//	unsigned short wData;
	struct resbuf *pBuffer = NULL;	
	
	// get old cascade passed by autolisp
	resval = getArg(rb,RTSHORT,0);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogCascade = (unsigned char)resval->rint;

	// get password passed by autolisp
	resval = getArg(rb,RTSHORT,1);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogPassword = resval->rint;

	// get new cascade passed by autolisp
	resval = getArg(rb,RTSHORT,0);
	if (resval == NULL)
	{
		ads_printf("****ERROR:input parameter error.****");
		ads_retvoid();
		
		return 0;
	}
	DogData = &(resval->rint);
	
	dwStatus = SetDogCascade();

	pBuffer = ads_buildlist(RTLONG,dwStatus,RTNONE);
	ads_retlist(pBuffer);
	ads_relrb(pBuffer);

	return 0;
}

union ads_u_val * getArg(struct resbuf *rb, int restype, unsigned int position)
{
	unsigned int i;

	for (i = 0; i < position && rb != NULL; i++)
		rb = rb->rbnext;

	if (rb == NULL || rb->restype != restype)
		return NULL;

	return &(rb->resval);
}