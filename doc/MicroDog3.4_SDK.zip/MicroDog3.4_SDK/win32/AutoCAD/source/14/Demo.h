/////////////////////////////////////////////////////////////////////////
/* 
	Copyright (C) Rainbow China Co., Ltd.	
	All rights reserved.

  File name:	Demo.h
  File description:	
	header file
*/ 
/////////////////////////////////////////////////////////////////////////
#ifndef _DEMO_H
#define _DEMO_H

// Declare all functions refered to in the ADS Function Table here
short Check(struct resbuf *);
short Convert(struct resbuf *);
short Write(struct resbuf *);
short Read(struct resbuf *);
short Disable(struct resbuf *);
short Curno(struct resbuf *);
short Setp(struct resbuf *);
short Setc(struct resbuf *);

// Get param from AutoLisp
union ads_u_val * getArg(struct resbuf *rb, int restype, unsigned int position);

#endif
