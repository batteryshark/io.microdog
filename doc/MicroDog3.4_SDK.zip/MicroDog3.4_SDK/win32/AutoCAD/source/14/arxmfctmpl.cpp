//
// (C) Copyright 1998-1999 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
//
//
#include "stdafx.h"
#include "arxmfctmpl.h"

// Marco
#define ELEMENTS(array) (sizeof(array) / sizeof((array)[0]))

/////////////////////////////////////////////////////////////////////////////
//
// Rx interface
//
/////////////////////////////////////////////////////////////////////////////

void initApp()
{
	for (int i = 0; i < ELEMENTS(g_FunctionTable); i++)
	{
        if (ads_defun(g_FunctionTable[i].name, (short)i) != RTNORM)
		{
            char strMsg[100];
			sprintf(strMsg, "ads_defun fail.\nThe function name:%s.\n", g_FunctionTable[i].name);

			ads_printf(strMsg);
		}
    }
}

void unloadApp()
{
}

int dofun()
{
	struct resbuf *rb;
	unsigned short func;


    func = (unsigned short)ads_getfuncode();
	if (func >= ELEMENTS(g_FunctionTable))
	{
		ads_fail("Received nonexistent function code.");
		return RTERROR;
	}

    rb =  ads_getargs();

    short retval = (*g_FunctionTable[func].fptr)(rb);

	ads_relrb(rb);

	if (retval == 0)
    	return RTNORM;
    
	else
		return RTERROR;
}

/////////////////////////////////////////////////////////////////////////////
//
// Entry points
//
/////////////////////////////////////////////////////////////////////////////

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	// Remove this if you use lpReserved
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
	}
	
	return 1;   // ok
}


extern "C" AcRx::AppRetCode 
acrxEntryPoint(AcRx::AppMsgCode msg, void* p)
{
	switch( msg ) 
	{
	case AcRx::kInitAppMsg: 
		acrxDynamicLinker->unlockApplication(p);
		initApp(); 
		break;
	case AcRx::kUnloadDwgMsg:
		break;
	case AcRx::kUnloadAppMsg: 
		unloadApp(); 
		break;
	case AcRx::kInvkSubrMsg:
		dofun();
		break;
	default:
		break;
	}
	return AcRx::kRetOK;
}
