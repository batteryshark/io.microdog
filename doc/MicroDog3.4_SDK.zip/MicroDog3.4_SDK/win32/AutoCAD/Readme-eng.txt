           	    -------------------------------------------
			 MicroDog Suite 32-bit Windows Application
			      Illustration of AUTOCAD
        	    -------------------------------------------
                       	Copyright (c) 2003 Rainbow China Co., Ltd.

     MicroDog Suite combines all advantages and features of USBDog(UMC type) and Parallel 
Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel Dog(PMH type) 
which are compatible with each other.The protected applications can use either USBDog or 
Parallel Dog when running in the operating systems such as Windows 98, Windows ME,Windows 2000 
and Windows XP. The current version of MicroDog can support only Parallel dog when the application
is running in Windows NT 4.0 , so please contact us if you need to operate USBDog in that environment.
          
=========
Functions
=========
  MicroDog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, 
writing data into and reading data from the memory, changing data, checking the current 
manufacturing number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six basic functions specified above will secure your software products from any unauthorized
use. For detailed description of protection strategy, please read The Developer's Manual .

==========
File list
==========

   File name             Description
   --------------        -----------------------------------------------------
   README-ENG.TXT        This file
   dogmh14.arx	         autocad 14 file
   dogmh2k.arx           autocad 2000 file
   source<dir>		 arx original code
   

====================================
Introduction to arx programming
====================================

 Under 32-bit WINDOWS environment, the MicroDog Arx can be made through MS Visual C++ 
compiler. The approach is to call the WIN32 C standard API (in win32\win32c\msvc folder) in 
the Arx, so as to operate the MicroDog. Thus, the applications calling this Arx will 
be able to judge whether the proper MicroDog exists through the result of the operation.
The application is then protected. See below the illustration for the calling to arxy 
by an application:
	  Application            ARX                  Mhwin32c.obj
	  -----------            -------              -------
	       |
	       |-------------------->|
				     |----------------->|
						  Operate the Dog 
				     |<-----------------|
	       |<--------------------|
	       |


==================
API Functions introduction
==================

1. Parameters:
	DogAddr:(WORD)
	If not using multi-modules, read/write dog, the sum of operating dog's memory first 
	address(0-199) and bytes can not more than 200.

	DogBytes: (WORD)
	Read/write dog(0-200) ,and the sum of dogaddr with dogbytes can not be more than 200.

	Password: (ULONG)
	The password of operating microdog.

	DogResult: (ULONG)
	Result of dog convert.

     	DogCascade:  Used for Microdog dog. The DogCascade in the USBdog must be 0

2.the usage of interface function: 
(1).Dog Check function
	DogCheck
	parameter(in) :	 	null
	parameter(out ) :	null
	Returned value :   	1 means success, other value is error code.
	Function :	Check the hardware Dog.

(2)Read dog function
	ReadDog  DogAddr
	parameter(in) :	    	DogAddr.
	parameter(out ) :    	null.
	Returned value:         0 means failure, other value is read out data.
	Function: Read data from the Hardware Dog. The MicroDog has an storage of 200 bytes
	to keep the data when the power is off. Read Dog will read data from the Hardware 
	Dog with the starting point defined by DogAddr. The byte number is 2 bytes. The data 
	read out is returned . 

(3)Write Dog function
	WriteDog DogAddr, WData
	parameters(in):       DogAddr, Wdata.
	parameters(out):      null.
	Returned value:       1 means success, other value is error code.
	Function: Write data into the Hardware Dog. The MicroDog has an storage of 200 bytes
	to keep the data when the power is off.  It will write data into the Hardware Dog with 
	the starting point defined by DogAddr. The byte number is 2 bytes. The data write into 
	is stored in the area pointed by WData. 

(4)Convert function 
	DogConvert Data(STRING)
	parameters(in):     Data.
	parameters(out):    null.
	Returned value:     0 means failure, other value is convert result.
	Function: Execute a convert function. You may transfer a data that are indicated by Data 
	(pointer variable to indicate where the data placed) to the Dog, and the dog will execute 
	a convert function to return a 32-bit Result,the pDogResult point to the. The conversion 
	algorithm can be selected by developer, last 4 bytes of user storage area in Hardware Dog 
	may take effect on the converting result, you may select a algorithm through 196th byte, 
	that means there are 256 kinds of algorithms you can choice. And 4 bytes from 197th to 199th
	are descriptors of the converting algorithm you selected, that means there are 16,777,215 
	kinds of variations.

(5)Get Current Number function
	GetCurrentNo
	parameter(in) :	    null
	Returned value:     0 means failure, other value is read data.
	Function: 	Get ID number of the hardware Dog.

(6)DisableShare function
     DisableShare
     parameter(in) :	 null
     parameters(out):    null.
     Return value: Returns zero if successful; returns an error code if the function fails.
     Function: Disable the hardware Dog's sharing ability.The parallel port hub is a kind of
               hardware share device that allows multiple copies of the protected program share
               the same Dog.Factory setting for share ability is Enable. You may call DisableShare 
               function to prevent pirates from using a parallel port hub. Sothat only the machine 
               that has the Dog can run the protected program.DisableShare only affects the functions 
               ReadDog, WriteDog and DogConvert. 

     * Caution:
             Do not call on this function multiple times. It is designed to be called no more
             than once in an application.

(7)Set Dog password function
	SetPassword Data(int)
	parameters(in):       Data.
	parameters(out):      null.
	Returned value:       1 means success, other value is error code.
	Function: Set Dog password. 

(8)Set Dog Cascade function
	SetDogCascade Data(int)
	parameters(in):       Data.
	parameters(out):      null.
	Returned value:       1 means success, other value is error code.
	Function: Set Dog cascade. 

==========================
Run the demo program
==========================
1)  Run AutoCAD.

2)  Load Arx and demo.lsp.

3)  Run demo at Command editor.

============
Error code
============
   Refer to ERRCODE.TXT in the root of the installation directory for detailed 
   information about error codes.

========
Cautions
========
1. When you write data to the Dog, changing the last 4 bytes of the 
   Hardware Dog memory will affect the result of function DogConvert().

2. If you use MD or MF, the functions DogCheck() and DogConvert() require
   DogPassword, and the functions DisableShare() and GetCurrentNo() are 
   not functional.

3. If you want to run the protected application in other computer in Windows 9x/ME or 
   Windows NT/2000/XP, you should install the corresponding device driver 
   for the hardware Dog. Please use MicroDogInstdrv.EXE in the DRIVER folder to install 
   the correct driver.

4. Please copy mhwin32c.obj (at the folder win32c\msvc) to this folder when compiling
   and linking arx .

====
Note
====
   The protected applications can use either USBDog or MicroDog when running in the operating
   systems such as Windows 98 ,Windows ME ,Windows 2000 and Windows XP. The current version of 
   Microdog can support only Parallel Dog when the application is running in Windows NT 4.0, 
   so please contact us if you need to operate USBDog in that environment.

=================
Technical support
=================
   If you have any technical problems, please contact Rainbow China Co., Ltd., 
   our branches, or our distributors.  

  
   Please Refer to  /Address.txt for the contact address.

