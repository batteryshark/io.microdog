///////////////////////////////////////////////////////
//	GSDOG.java
//	
// 	Contains class GSDOG defining variables and native methods to
// 	interface with GTD DOG device driver.
//
//
///////////////////////////////////////////////////////



class GSDOG 
{
	
        //in most cases, this Global variable should be set zero.
        public int DogCascade;

	//The globle variable DogAddr indicates the first memory
	//address(range from 0 to 199) of user area in the MicroDog
	//The sum of DogAddr and DogBytes should not exceed 200
	public int DogAddr;
	
	//The globle variable DogBytes indicates the number of bytes
	//in reading/writing operation or convertion
	//The sum of DogAddr and DogBytes should not exceed 200
	public int DogBytes;
	
	//The globle variable DogCode refers to the user code in
	//the MicroDog and can be changed by DOGEDIT.exe
	public int DogPassword;
	
	//The globle variable refers to the result of convererting operation
	public int DogResult;
	
	//the globle variable DogData refers to the pointer variable 
	//which points to the data for writing/reading or converting
	public byte[] DogData;
		
	public GSDOG()		
	{
	}	
		
	
   /**
	* Perform Dog Check Service 
	* @param none.
	*/

	public native int DogCheck();  

	/**
	* Perform Dog Convert Service 
	* @param none.
	*/

	public native int DogConvert();  

	/**
        * Perform Dog Write Service 
	* @param none.
	*/

	public native int WriteDog();
	
	/**
        * Perform Dog Read Service 
	* @param none.
	*/

	public native int ReadDog();
	
	/**
        * Perform Dog DisableShare Service 
	* @param none.
	*/

	public native int  DisableShare();

	/**
        * Perform Dog GetCurrentNo Service 
	* @param none.
	*/

	public native int  GetCurrentNo();
	
	/**
	 *	Static initializer 
	 */

    static 
    {
        try 
        {
                System.loadLibrary("DOGJava"); 
        }
        catch( UnsatisfiedLinkError e )
        {
            System.err.println("Can't find library DOGJava.DLL"); 
            e.printStackTrace();
            System.exit( -1 );
        }
     }
}         

// End of file GSDOG.java

