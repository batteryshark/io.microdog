///////////////////////////////////////////////////////
//	DOGGSMH.java
//	
//      Contains class DOGGSMH to show methods to call base class GSDOG's 
//      native methods
// 
//
///////////////////////////////////////////////////////

class DOGGSMH extends GSDOG
{

	/**
	 *Checks whether a Dog is plugged in the parallel ports
	 *return 0 if success
	 *
	 */

	public void CallDogCheck()
		throws DOGException
	{
		int retCode;

		if((retCode=DogCheck())!=0)
			throw new DOGException(retCode);
		else	
			System.out.println("Dog Check is OK!");
	}


	/**
	 *send a byte array to Dog and convert it to an int
	 *return 0 if success
	 *
	 */

	public void CallDogConvert()
		throws DOGException
	{
		int retCode;

		if((retCode=DogConvert())!=0)
			throw new DOGException(retCode);
		else	
		{
			System.out.println("Dog Convert is OK!" + "  Convert result is: "+ DogResult);
		}
	}

	/**
	 *write a byte array to Dog memory 
	 *return 0 if success
	 *
	 */

	public void CallWriteDog()
		throws DOGException
	{
		int retCode;

		if((retCode=WriteDog())!=0)
			throw new DOGException(retCode);
		else	
		{
			System.out.println("WriteDog is OK!");
		}
	}


	/**
	 *read Dog memory
	 *return 0 if success
	 *
	 */

	public void CallReadDog()
		throws DOGException
	{
		int retCode;
		char[] toPrint;
		int i;

		toPrint=new char[DogBytes];

		if((retCode=ReadDog())!=0)
			throw new DOGException(retCode);
		else	
		{
			for(i=0;i<DogBytes;i++)	toPrint[i]=(char)DogData[i];
			System.out.println("ReadDog is OK!" + "  read result is: "+ toPrint);
		}
	}

	/**
	 *get the current no
	 *return 0 if success
	 *
	 */
	public void CallGetCurrentNo()
		throws DOGException
	{
		int retCode;

		if((retCode=GetCurrentNo())!=0)
			throw new DOGException(retCode);
		else	
		{
			System.out.println("GetCurrentNo is OK!" + "  current no is: " + DogResult);
		}
	}

	/**
	 * disable share
	 *return 0 if success
	 *
	 */
	public void CallDisableShare()
		throws DOGException
	{
		int retCode;

		if((retCode=DisableShare())!=0)
			throw new DOGException(retCode);
		else	
			System.out.println("DisableShare is OK!");
	}

}

