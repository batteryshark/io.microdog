
                     -------------------------------------------------------
	                         MicroDog Suite 32-bit WINDOWS Application
                                         API Guide to JDK1.1.4
                     -------------------------------------------------------

                   Copyright (c) 2003, Rainbow China Co., Ltd.

     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of MicroDog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

=========
Functions
=========
  MicroDog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, 
writing data into and reading data from the memory, changing data, checking the current 
manufacturing number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six basic functions specified above will secure your software products from any unauthorized
use. For detailed description of protection strategy, please read The Developer's Manual .
  

=========
File list
=========
   File name       Description
   ----------      ----------------------------------------------------------
   readme-eng.txt      This file
     DOGDEMO.JAVA      Sample program for using MicroDog in encryption. 
       GSDOG.JAVA      Source code for class GSDOG, with envelop for operations on MicroDog. 
                       And sample of calling DLL in JAVA.
     DOGGSMH.JAVA      A source program of DOGGSMH that realized the operation on MicroDog, 
                       with inheriting GSDOG class. 
DOGException.JAVA      Source code for DOGException, error handling.
      DOGJava.dll      DLL which realizes the operation on MicroDog called by JAVA applications. 
  

 
===================
Introduction to API    
===================
  Class GSDOG envelops the operating methods and variables for the Dog, including six 
variables:
  unsigned char DogCascade:
     The parameter for cascade capability, it should be equal the number saved in hardware dog.
     The DogCascade is the number from 0 to 15.

  int  DogAddr:
     Indicates the start address (0~199) of Hardware Dog internal user area during read 
     operation. The sum of adding DogAddr with DogBytes will not be allowed to be 
     over 200.

  int  DogBytes:
     Byte number of read operation (1~200) or conversion operation (1~63). In  read 
     operation, The sum of adding DogAddr with DogBytes will not be allowed to be 
     over 200.

  int  DogPassword:
     Access operation password.

  int  DogResult:
     Result after conversion. Function DogConvert will put the converted result 
     into this variable. Be careful, if the operation of DogConvert fails, the original 
     NetDogResult value will not be changed. 
 

  byte[] DogData:
     Pointer variable to indicate buffer of read/write/conversion operation. 


  ============================
  Explanation to API functions
  ============================
a. public native int DogCheck();  
   Input parameter: Cascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Checks whether the hardware Dog exists.  Only a Dog has the same serial
         number as the OBJ file can be detected. 

b. public native int DogConvert();  
   Input parameter: Cascade, DogBytes, DogData
   Output parameter: DogResult
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Transfers data to MicroDog.  The hardware Dog converts the data 
       and returns the converted result Dogresult as a 32-bit integer.  DogBytes indicates
       the number of bytes of the date, which DogData points to, being converted. 
       The conversion algorithm can be specified by the developer.  The last 4 bytes 
       of memory affects the conversion algorithm.  The 196th byte is used to 
       specify the algorithm.  Therefore, a developer can define 256 kinds of algorithms. 
       The algorithm descriptors are made up of the 197th, 198th and 199th byte, so it have 
       a maximum of 16,777,215 different combinations.

c. public native int WriteDog();
   Input parameter: Cascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Writes data to the hardware Dog. Carries out the same operation as ReadDog,
      except that the data flow direction is different.

*Caution:
     The last 4 bytes are used to define the conversion algorithm. Therefore, better
     not use these 4 bytes unless you want to change the algorithm.


d. public native int ReadDog();
   Input parameter:  Cascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter:  DogData
   Return value:     0 = operation succeeded. All others are error codes.
   Function: Reads data from the hardware Dog. The Dog contains a 200-byte nonvolatile 
         memory.  ReadDog reads data from the Dog memory beginning at the address 
         indicated by DogAddr.  The bytes number of the read data is indicated 
         by DogBytes.  The read data is stored in the space DogData points to.
         MicroDog verifies the DogPassword. DogPassword is the password for
         read/write operations stored on the hardware Dog.  It can be set by the 
         utility tool DOGEDIT.EXE in UTILITY folder or the SetPassword() function. 
         Applications must ensure enough space to buffer the data being read.  ReadDog 
         does not check whether the buffer size is sufficient.

e. public native int DisableShare();
   Input parameter: Cascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Disable the hardware Dog's sharing ability.
         The parallel port hub is a kind of hardware share device that allows multiple 
         copies of the protected program share the same Dog. 
         Factory setting for share ability is Enable. You may call DisableShare function to 
         to prevent pirates from using a parallel port hub. So that only the machine that 
         has the Dog can run the protected program.  
         DisableShare only affects the functions ReadDog, WriteDog and DogConvert. 

* Caution:
         Do not call on this function multiple times. It is designed to be called no more
         than once in an application.

f. public native int GetCurrentNo();
   Input Parameter: Cascade, DogData
   Output parameter: DogData
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads the Manufacturing code of the hardware Dog.Some of the hardware
             Dogs may have the same ID, but every hardware Dog has its unique
             Manufacturing code. The Manufacturing code can help developers manage
             user accounts.
             The Manufacturing code is 4 bytes.

Remark:
    Please refer DOGGSMH.JAVA, DOGDEMO.JAVA to learn how to use these functions. 

============
Error code
============
   Refer to ERRCODE.TXT in the root of the installation directory for detailed 
   information about error codes.

=======================================
Compiling and running of sample program
=======================================
  
  This Java sample program is written with Java JDK for Windows NT/95, with the 
following environment:
         Java JDK 1.1.4
 
  Steps:

  1. Compile the java sample program
    Enter:
	JAVAC DogDemo.java
    The following are generated:
         DogDemo.class
         GSDOG.class
         DOGGSMH.class
         DOGException.class     

  2. Run java sample program:
    To run the sample program, device driver should be installed. With regard to 
installation for device drivers, please refer readme file in DRIVER folder.
    To run the sample, enter:
	java DogDemo
  
  Note:
  
  For running java program, user need add CLASSPATH envionment variables into system, including
  .; and /jdk directory/include;


====================
Generate DOGJava.dll
====================

    DLL subfolder contains the following files, which may be used to generate 
DOGJava.dll. 
    This version of DogJava.dll is written with Java JDK for Windows NT/95 . 
    Compiling environment: Visual C++ 6.0, Java JDK 1.1.4


    DOGIMP.c       native method source code in GSDOG 
    GSDOG.c        The stub file generated directly from GSDOG.class.
                   Method: under command prompt, input;
                   javah -stubs GSDOG.class
    GSDOG.h        Header file generated directly from GSDOG.class.
                   Method: under command prompt, input;
                   javah GSDOG.class
    MHWIN32C.OBJ   The Win32 C API module for MicroDog.(in WIN32\WIN32C\MSVC)
    GSMH.H         Header file needed to link MHWIN32C.OBJ. (in WIN32\WIN32C\MSVC)
    dogjava.rc     Resource file
    resource.h	   Resource head file
    dll.dsp        Project file
    Dll.dsw        Project file

Remark:   When developing your own DLL, you should replace the file MHWIN32C.OBJ in the make 
file with Microdog\WIN32\WIN32C\MSVC\MHWIN32C.OBJ. 

=========
Cautions
=========
1. For your benefits, please remember that DOGJAVA.DLL we provided is only a sample 
   program. It should not be used for any kind of protection work, since its source 
   code is already open to public. You should follow the above principles to develop 
   your own class and DLLs, and add your own algorithm in the DLL by calling the 
   MHWIN32C module. 

2. When you write data to the Dog, changing the last 4 bytes of the 
   hardware Dog memory will affect the result of function DogConvert().

3. If you use MD or MF, the functions DogCheck() and DogConvert() require
   DogPassword, and the functions DisableShare() and GetCurrentNo() are 
   not functional.

4. If you want to run the protected application in other computer in Windows 9x/ME or 
   Windows NT or Windows 2000/XP, you should install the corresponding device driver 
   for the hardware Dog. Please use MicroDogInstdrv.exe in the DRIVER folder to install 
   the correct driver.

5. If you want to release your protected programs to your end-users, please include
   installing tool in the DRIVER folder in your SETUP process,and execute installing 
   the device drivers for the Dog first. 

 
=====
Note
=====
  When you use this module to encrypt,not only Parallel Dog but also USBDog can be operated
in Windows 2K/XP or Windows 98/ME.

=================
Technical Support
=================
    For technical issues, please contact Rainbow China Co., Ltd. or its distributors 
immediately. 

    For contact address, please see Address.txt under installation path.

