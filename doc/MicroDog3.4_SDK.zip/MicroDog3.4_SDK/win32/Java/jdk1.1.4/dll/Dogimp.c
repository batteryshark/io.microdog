 /*************************************************************
 *
 *      @project:        DOGJava.dll
 *
 *
 *      @filename:       DOGimp.c this is for jdk1.1.4
 *        
 *      @description:    Implementation of low-level functions.
 *
 *      Author :		 anhm
 *      CopyRight:       Rainbow China Co.,Ltd
 *************************************************************
 *
 */

#include "StubPreamble.h"
#include "gsdog.h"
#include "gsmh.h" //please copy this file from WIN32C\MSVC

short int DogBytes,DogAddr;
unsigned long DogPassword;
unsigned long NewPassword;
unsigned long DogResult;
unsigned char DogCascade;
void * DogData;


//Transform
long GSDOG_DogConvert(struct HGSDOG * this)
{
	long retCode;

        DogResult = 0; // first, clear it.
	
        DogCascade = (unsigned char )unhand(this)->DogCascade;
	DogBytes = (short int) unhand(this)->DogBytes;
	DogData = unhand((unhand(this)->DogData))->body;
	
	retCode = DogConvert();
	
	unhand(this)->DogResult = DogResult;
	
	return retCode;
}

//Write dog
long GSDOG_WriteDog(struct HGSDOG * this)
{
	int retCode;
	
    DogCascade = (unsigned char )unhand(this)->DogCascade;
	DogBytes = (short int) unhand(this)->DogBytes;
	DogAddr = (short int) unhand(this)->DogAddr;
	DogPassword  = unhand(this)->DogPassword;
	DogData  =  unhand((unhand(this)->DogData))->body;
	
	retCode=WriteDog();
	
	return retCode;
}
//Read dog
long GSDOG_ReadDog(struct HGSDOG * this)
{
	int retCode;
	
        DogCascade = (unsigned char )unhand(this)->DogCascade;
	DogBytes = (short int) unhand(this)->DogBytes;
	DogAddr = (short int) unhand(this)->DogAddr;
	DogPassword  =  unhand(this)->DogPassword;
	DogData  =  unhand((unhand(this)->DogData))->body;
	
	retCode = ReadDog();
	
	return retCode;
}

//Check dog
long GSDOG_DogCheck(struct HGSDOG * this)
{
	int retCode;
	
        DogCascade = (unsigned char )unhand(this)->DogCascade;
	
	retCode = DogCheck();
	
	return retCode;
}

//Disable sharing dog
long GSDOG_DisableShare(struct HGSDOG * this)
{
	int retCode;
	
        DogCascade = (unsigned char )unhand(this)->DogCascade;
	
	retCode = DisableShare();
	
	return retCode;
}

//Get current number
long GSDOG_GetCurrentNo(struct HGSDOG * this)
{
	int retCode;
	
        DogCascade = (unsigned char )unhand(this)->DogCascade;
	DogData = & DogResult;
	
	retCode=GetCurrentNo();
	
	unhand(this)->DogResult = DogResult;
        DogResult = 0;

	return retCode;
}
