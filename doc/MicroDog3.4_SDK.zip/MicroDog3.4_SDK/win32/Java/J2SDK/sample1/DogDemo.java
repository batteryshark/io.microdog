///////////////////////////////////////////////////////
//	DogDemo.java
//	
// 	Contains class DogDemo to show as a sample
//  to protect software with MicroDog by Rainbow China  
//
//
///////////////////////////////////////////////////////

class DogDemo 
{
	
	/**
	 ***************************************
	 *
	 *  @Method:            main
	 *
	 *  @Description:       This method runs first.
	 *
	 ***************************************
	 */
	
	public static void    main( String Args[] )
	{
		int retCode,i;
		
		System.out.println( "MicroDog Sample Program for Java." );
        	System.out.println( "Implemented by JDK 1.2 release\n" );
		
		
		DOGGSMH sample = new DOGGSMH();
		sample.DogCascade = 0;
		sample.DogPassword=0;

		sample.DogData = new byte[200];
		for (i=0;i<200;i++)
			sample.DogData[i]=(byte)(i+48);
		
		try 
		{
		sample.CallDisableShare();
		}
		catch(DOGException e)
		{
			System.err.println( "  DisableShare Error: " + e.Error);
		} 
		
		
		try 
		{
			sample.CallDogCheck();
		}
		catch(DOGException e)
		{
			System.err.println( "  Dog Check Error: " + e.Error);
		} 
		
                sample.DogBytes=6;
		
		try 
		{
			sample.CallDogConvert();
		}
		catch(DOGException e)
		{
			System.err.println( "  Dog Convert Error: " +e.Error);;
		}
		
                sample.DogBytes=190;
                sample.DogAddr = 0;
		try 
		{
			sample.CallWriteDog();
		}
		catch(DOGException e)
		{
			System.err.println( "  WriteDog Error: " +e.Error);
		}
		
		
                sample.DogBytes=200;
                sample.DogAddr=0;

		try 
		{
			sample.CallReadDog();
		}
		catch(DOGException e)
		{
			System.err.println( "  ReadDog Error: " +e.Error);
		}

		try 
		{
			sample.CallGetCurrentNo();
		}
		catch(DOGException e)
		{
			System.err.println( "  GetCurrnetNo Error: " + e.Error);
		} 

		System.out.println("\nProgram Finished.\n");
	}
}         
// End of file DogDemo.java
