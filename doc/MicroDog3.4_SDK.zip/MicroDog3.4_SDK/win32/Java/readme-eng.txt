                     -------------------------------------------------------
	                         Microdog Suite 32-bit WINDOWS Application
                                         API Guide to JAVA
                     -------------------------------------------------------
				Copyright(c) 2003 Rainbow China Co.,Ltd

     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of MicroDog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

==========
File list
==========

    jdk1.1.4 <dir>	We provide the dynamic library in the jdk1.1.4 platform and the example
			of using this dynamic library. 

    j2sdk    <dir>	We provide the dynamic library in the j2sdk platform and the example of
			using this dynamic library. 
    readme-eng.txt      This file.