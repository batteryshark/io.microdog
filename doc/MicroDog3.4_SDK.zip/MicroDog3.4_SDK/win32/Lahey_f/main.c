//Name:			Main.c
//Function:		Make output functions for Lahey Fortran4.0
//				via DLL.
//Author:		Zhang Jing
//Date:			9/20/98

#define DLL_PROCESS_DETACH 0    
#define DLL_PROCESS_ATTACH 1    

unsigned short DogAddr;
unsigned short DogBytes;
unsigned long DogPassword;
unsigned long DogResult;
void * DogData;
unsigned char DogCascade;
unsigned long NewPassword;

extern unsigned long DogCheck();
extern unsigned long DogConvert();
extern unsigned long ReadDog();
extern unsigned long WriteDog();
extern unsigned long GetCurrentNo();
extern unsigned long DisableShare();
extern unsigned long EnableShare();

//Output function CheckDog(unsigned char*, unsigned long*)
//Hold DogCheck() function for LF4.0
_declspec(dllexport) unsigned long _stdcall CheckDog (unsigned char *cas, unsigned long *pass)
{
        DogCascade = *cas;
        DogPassword = *pass;
        return DogCheck();
}

//Output function ConvertDog(unsigned char*, unsigned short*, void*, 
//							unsigned long*, unsigned long*, unsigned long)
//Hold DogConvert() function for LF4.0
_declspec(dllexport) unsigned long _stdcall ConvertDog (unsigned char*cas, 
														unsigned short * DBytes,
														void * DData,
														unsigned long *result,
                                                        unsigned long *pass,
														unsigned long DataLen)
{
	unsigned long i;
	DogBytes=*DBytes;
	DogData=DData;
	DogCascade = *cas;
    DogPassword = *pass;
	i = DogConvert();
	*result = DogResult;
	return i;
}

//Output function DogRead(unsigned char*, unsigned short*, 
//							unsigned short*, unsigned long*, void*, 
//							unsigned long)
//Hold ReadDog() function for LF4.0
_declspec(dllexport) unsigned long _stdcall DogRead (unsigned char*cas,
													 unsigned short* DBytes,
													 unsigned short* DAddr,
													 unsigned long* DCode,
													 void* DData,
													 unsigned long DataLen)
{ 
	DogCascade = *cas;
	DogBytes = *DBytes;
	DogData = DData;
	DogAddr = *DAddr;
	DogPassword = *DCode;
	return ReadDog();
}

//Output function DogWrite(unsigned char*, unsigned short*, 
//							unsigned short*, unsigned long*, void*, 
//							unsigned long)
//Hold WriteDog() function for LF4.0
_declspec(dllexport) long _stdcall DogWrite (unsigned char* cas,
											 unsigned short* DBytes,
											 unsigned short* DAddr,
											 unsigned long* DCode,
											 void* DData, 
											 unsigned long DataLen)
{
	DogCascade = *cas;
	DogBytes = *DBytes;
	DogData = DData;
	DogAddr = *DAddr;
	DogPassword = *DCode;
	return WriteDog();
}

//Output function ShareDisable(unsigned char*)
//Hold DisableShare() function for LF4.0
_declspec(dllexport) long _stdcall ShareDisable(unsigned char* cas)
{
	DogCascade = *cas;
	return DisableShare();
}

//Output function GetSerial(unsigned char*, void*, unsigned long)
//Hold GetCurrentNo() function for LF4.0
_declspec(dllexport) long _stdcall GetSerial(unsigned char* cas,
											 void* DData, 
											 unsigned long DataLen)
{
	DogCascade = *cas;
	DogData = DData;

	return GetCurrentNo();
}

//DLL Entry, do the function as main in C Language
unsigned long __stdcall DllEntryPoint(void *hDll, unsigned long Reason, void *Reserved)
{
    if (Reason == DLL_PROCESS_ATTACH)
    {
        /*perform DLL initialization tasks here*/
    }
    return (1);
}
