
                     -------------------------------------------------------
	                         MicroDog Suite 32-bit WINDOWS Application
                                         API Guide to DELPHI
                     -------------------------------------------------------

                          Copyright (c) 2002 Rainbow China Co., Ltd.

     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of MicroDog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

      
=========
Functions
=========
  MicroDog Suite contains two Hardware Dogs (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, writing 
data into and reading data from the memory, changing data, checking the current manufacturing 
number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six functions specified above will secure your software products from any unauthorized 
use.  For detailed description of protection strategy, please read The Developer's Manual .


=========
File list
=========
   
   Readme-eng.txt        This file
   MHWIN32C.OBJ		 The API module
   Dogdemo.dpr	         Delphi5 Poject file
   Dogdemo.exe        	 Execute file
   Dogdemo.res        	 resource file
   Mainfrm.drm        	 delphi drm file
   Mainfrm.pas           SOurce code file

===================
Tested Environments
===================
   Borland Delphi 2.0, 3.0, 4.0, 5.0, 6.0
This demo is created by Delphi 5.0.


=============
API Functions
=============
  The API module here refer to the file MHDELPHI.OBJ .  

1. This module provides 6 interface functions, these functions should be defined in 
   implementation part of unit in your PASCAL source file (.PAS):	
     function DogCheck: longint; external;       
     function ReadDog: longint; external;        
     function WriteDog: longint; external;       
     function DogConvert: longint; external;     
     function GetCurrentNo: longint; external;   
     function DisableShare: longint; external;  
     function SetPassword: longint; external;   
     function SetDogCascade: longint; external;  
     {$L MHDELPHI.OBJ }


2. Meanwhile, the following global variables need to be declared in interface part of 
   unit in your PASCAL source file (.PAS):
     DogAddr:integer;  
     DogBytes:integer; 
     DogPassword:longint;
     DogResult:longint;  
     DogData:^byte;      
     DogCascade:integer;
     NewPassword:longint; 

   Explanation for global variables
   --------------------------------
     a. DogAddr:  Indicates the start address (0~199) of hardware Dog internal 
                  user area during read operation. The sum of adding DogAddr with 
                  DogBytes will not be allowed to be over 200.

     b. DogBytes: Byte number of read operation (1~200) or conversion operation 
                  (1~63). In read operation, The sum of adding DogAddr with DogBytes 
                  will not be allowed to be over 200.

     c. DogPassword: Access password. The factory setting in the hardware Dog is 
                     0, it may be changed by DOGEDT32.EXE in UTILITY folder. It 
                     will only take effect for the functions of ReadDog and WriteDog, 
                     not for DogCheck and DogConvert.

     d. DogResult: Result after conversion. Function DogConvert will put the 
                   converted result into this variable. Be careful, if the 
                   operation of DogConvert fails, the original DogResult value will 
                   not be changed. 

     e. DogCascade: Used for RC-MH dog. The DogCascade in the USBdog must be 0.

     f. DogData: Buffer of read/write/conversion operation. 

     g. NewPassword: New password to be set. In this version, the module does not 
                     have a function to set the password .It can be set by the program 
                     DOGEDT32.EXE in the UTILITY directory.

3. function DogCheck : longint; external;
   Input parameter: DogCascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Checks whether the hardware Dog exists.  Only a Dog that has the same serial
             number as the OBJ file can be detected.        

4. function ReadDog : longint; external;
   Input parameter:  DogCascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter:  DogData
   Return value:     0 = operation succeeded. All others are error codes.
   Function: Reads data from the hardware Dog. The Dog contains a 200-byte nonvolatile 
         memory.  ReadDog reads data from the Dog memory beginning at the address 
         indicated by DogAddr.  The bytes number of the read data is indicated 
         by DogBytes.  The read data is stored in the space DogData points to.
         Hardware Dog verifies the DogPassword. DogPassword is the password for
         read/write operations stored on the hardware Dog.  It can be set by the 
         utility tool DOGEDT32.EXE in UTILITY folder . 
         Applications must ensure enough space to buffer the data being read.  ReadDog 
         does not check whether the buffer size is sufficient.

5. function WriteDog : longint; external;
   Input parameter: DogCascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Writes data to the hardware Dog. Carries out the same operation as ReadDog,
             except that the data flow direction is different.

   *Caution:
     The last 4 bytes are used to define the conversion algorithm. Therefore, better
     not use these 4 bytes unless you want to change the algorithm.

6. function DogConvert : longint; external;

   Input parameter: DogCascade, DogBytes, DogData
   Output parameter: DogResult
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Transfers data to hardware Dog.  The hardware Dog converts the data 
       and returns the converted result DogResult as a 32-bit integer.  DogBytes indicates
       the number of bytes of the date, which DogData points to, being converted. 
       The conversion algorithm can be specified by the developer.  The last 4 bytes 
       of memory affects the conversion algorithm.  The 196th byte is used to 
       specify the algorithm.  Therefore, a developer can define 256 kinds of algorithms. 
       The algorithm descriptors are made up of the 197th, 198th and 199th byte, so it have 
       a maximum of 16,777,215 different combinations.

   *Caution:
     The last 4 bytes in the Dog memory are used to define the conversion algorithm. 
     Therefore, better not use these 4 bytes unless you want to change the algorithm.

7. function DisableShare : longint; external;
   Input parameter: DogCascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Disable the hardware Dog's sharing ability.
         The parallel port hub is a kind of hardware share device that allows multiple 
         copies of the protected program share the same Dog. 
         Factory setting for share ability is Enable. You may call DisableShare function to 
         to prevent pirates from using a parallel port hub. So that only the machine that 
         has the Dog can run the protected program.  
         DisableShare only affects the functions ReadDog, WriteDog and DogConvert. 

   * Caution:
         Do not call on this function multiple times. It is designed to be called no more
         than once in an application.

8. function GetCurrentNo: longint; external;
   Input Parameter: Cascade, DogData
   Output parameter: DogData
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads the Manufacturing code of the hardware Dog.Some of the hardware
             Dogs may have the same ID, but every hardware Dog has its unique
             Manufacturing code. The Manufacturing code can help developers manage
             user accounts.
             The Manufacturing code is 4 bytes.

9. function SetPassword: longint; external; 
   Input parameter: DogCascade, DogPassword, NewPassword
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Modifies the Dog password.DogPassword is the current password, and NewPassword
             is the one that would replace it.

10. function SetDogCascade: longint; external;
    Input parameter: DogCascade, DogPassword, DogData
    Output parameter: None
    Return value: Returns zero if successful; returns an error code if the function fails.
    Function: Set the DogCascade. The new cascade is put into the DogData.

==========
Error code
==========
   Refer to ERRCODE-ENG.TXT in the root of the installation directory for detailed 
   information about error codes.

========
Cautions
========
1. When you write data to the Dog, changing the last 4 bytes of the 
   Hardware Dog memory will affect the result of function DogConvert().

2. If you use MD or MF, the functions DogCheck() and DogConvert() require
   DogPassword, and the functions DisableShare() and GetCurrentNo() are 
   not functional.

3. If you want to run the protected application in other computer in Windows 9x/ME or 
   Windows NT/2000/XP, you should install the corresponding device driver 
   for the hardware Dog. Please use INSTDRV.EXE in the DRIVER folder to install 
   the correct driver.

=================
Technical support
=================
If you have any technical problems, please contact Rainbow China Co., Ltd., 
our branches, or our distributors.  Be prepared to provide us your software part 
number and version number. This will accelerate our help.

The part number of this module is RC-UMH-W32-DELPHI .

The version number can be extracted by using Utility/Getver.exe. The version information
can be helpful in pinpointing and solving problems.

Please Refer to  Address.txt for the contact address.
