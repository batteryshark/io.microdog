
                     -------------------------------------------------------
	                      MicroDog Suite 32-bit WINDOWS Application
                                  API Guide to Visual Fortran  
                     -------------------------------------------------------

                              Copyright (C) 2003 Rainbow China Co., Ltd.

     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of MicroDog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

      
=========
Functions
=========
  MicroDog Suite contains two Hardware Dogs (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, writing 
data into and reading data from the memory, changing data, checking the current manufacturing 
number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six functions specified above will secure your software products from any unauthorized 
use.  For detailed description of protection strategy, please read The Developer's Manual .


=========
File list
=========
   File name             Description
   --------------        ------------------------------------------
   Readme-eng.txt        This file
   MHWIN32C.OBJ		 The API module
   MHDATA.INC	         The file of declaring COMMON BLOCK Variables             
   MHFUNC.INC            The file of declaring API functions
   test.for		 The demo source file 
   test.dsp              The project file
   test.dsw		 The project file
   test.exe		 The demo file

===================
Tested Environments
===================
   Visual Fortran 6.0 . 
   In Windows NT/2K/XP and Windows 9x/ME, you must install device driver progarm,the 
corresponding method of installation refer to the readme file in driver directory. 
Not only at the time of encrypting developer need install corresponding device driver, 
but also at the time of releasing developer need install corresponding device driver 
according to the end-users' operating system. 

=============
API Functions
=============
  The API module here refer to the file MHWIN32C.OBJ.  
  The module provides 8 functions of Visual Fortran language, namely: 
     DOGCHECK (check hardware dog), DOGCVT (dog convert), READDOG (read hardware dog), 
     WRITEDOG (write hardware dog), DSHARE (disable share), GETNO (read the current 
     manufacturing number), SETCAS (set cascade for micro dog) and SETPWD (set dog 
     password).
  You should declare following 7 variables in COMMON block and above 8 functions 
  before using the 8 functions. The 7 variables are DOGADDR, DOGBYTES, DOGPASSWORD, 
  NEWPASSWORD, DOGRESULT, CASCADE and DOGDATA.  Please refer the demo program TEST.FOR.

(1) COMMON BLOCK Variables
   They are defined in MHDATA.INC, so add the following line to the begin of the 
   function which will operate the hardware dog:
	INCLUDE 'MHDATA.INC'

a. INTEGER*2 DOGADDR: Indicate the beginning memory address (range 0 to 199) of 
                      user area in the hardware Dog when you use reading and/or 
                      writing operations. The sum of DOGADDR and DOGBYTES  should 
                      not be over 200.

b. INTEGER*2 DOGBYTES: The number(1-200) of bytes in the operation of reading
                       /writing or converting. The sum of DOGADDR and DOGBYTES
                       should not be over 200.

c. INTEGER*4 DOGDATA: Indicate the variable point the data of the operation
                      of reading/writing or converting.You must use it like this:
                                        CHARACTER*100 MFDATA
                                        DOGDATA=LOC(MFDATA)
                      Here MFDATA represent data buffer ,and LOC(MFDATA) get the 
                      address of the data buffer.

d. INTEGER*4 DOGPASSWORD: Access password in the hardware Dog (factory setting is zero),
                          used in the reading/writing operation. It can be changed
                          by the program DOGEDT32.EXE in the UTILITY directory.

e. INTEGER*4 DOGRESULT: The result of convertion operation.

f. INTEGER*2 CASCADE: Used for RC-MH dog. The CASCADE in the USBdog must be 0.

g. INTEGER*4 NEWPASSWORD: New password to be set. 

(2) The Usage Method of 8 External Functions

a. INTEGER*4 DOGCHECK()
   Needed parameter: CASCADE
   Function: Checks whether the hardware Dog exists. Only a Dog that has the same serial
         number as the OBJ file can be detected.        

b. INTEGER*4 DOGCVT()
   Needed parameter: CASCADE, DOGBYTES, DOGDATA
   Function: Transfers data to hardware Dog.  The hardware Dog converts the data 
       and returns the converted result DOGRESULT as a 32-bit integer.  DOGBYTES 
       indicates the number of bytes of the date, which DOGDATA points to, being converted. 
       The conversion algorithm can be specified by the developer.  The last 4 bytes 
       of memory affects the conversion algorithm.  The 196th byte is used to 
       specify the algorithm.  Therefore, a developer can define 256 kinds of algorithms. 
       The algorithm descriptors are made up of the 197th, 198th and 199th byte, so it have 
       a maximum of 16,777,215 different combinations.

c. INTEGER*4 READDOG()
   Needed parameter:  CASCADE, DOGADDR, DOGBYTES, DOGDATA, DOGPASSWORD
   Function: Reads data from the hardware Dog. The Dog contains a 200-byte nonvolatile 
         memory.  READDOG reads data from the Dog memory beginning at the address 
         indicated by DOGADDR.  The bytes number of the read data is indicated 
         by DOGBYTES.  The read data is stored in the space DOGDATA points to.
         MicroDog verifies the DOGPASSWORD. DOGPASSWORD is the password for
         read/write operations stored on the hardware Dog.  It can be set by the 
         utility tool DOGEDT32.EXE in UTILITY folder . 
         Applications must ensure enough space to buffer the data being read.  READDOG 
         does not check whether the buffer size is sufficient.

d. INTEGER*4 WRITEDOG()
   Needed parameter: CASCADE, DOGADDR, DOGBYTES, DOGDATA, DOGPASSWORD
   Function: Writes data to the hardware Dog. Carries out the same operation as READDOG,
      except that the data flow direction is different.

*Caution:
     The last 4 bytes are used to define the conversion algorithm. Therefore, better
     not use these 4 bytes unless you want to change the algorithm.

e. INTEGER*4 DSHARE()
   Needed parameter: CASCADE
   Function: Disable the hardware Dog's sharing ability.
         The parallel port hub is a kind of hardware share device that allows multiple 
         copies of the protected program share the same Dog. Factory setting for share 
         ability is Enable. You may call DisableShare function to prevent pirates from
         using a parallel port hub. So that only the machine that has the Dog can run 
         the protected program. DSHARE only affects the functions READDOG, WRITEDOG
         and DOGCVT. 

* Caution:
         Do not call on this function multiple times. It is designed to be called no more
         than once in an application.

f. INTEGER*4 GETNO()
   Needed variables: CASCADE, DOGDATA
   Function: Reads the Manufacturing code of the hardware Dog. Some of the hardware
             Dogs may have the same ID, but every hardware Dog has its unique
             Manufacturing code. The Manufacturing code can help developers manage
             user accounts.

g. INTEGER*4 SETCAS()
   Input parameter: DogCascade, DogPassword, DogData
      Output parameter: None
      Return value: Returns zero if successful; returns an error code if the function fails.
      Function: Set the DogCascade. The new cascade is put into the DogData.

h. INTEGER*4 SETPWD()
   Input parameter: DogCascade, DogPassword, NewPassword
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Modifies the Dog password. DogPassword is the current password, and NewPassword
               is the one that would replace it.

(3)Remarks:

a. To use these functions, add the following sentence to the begin of program file:
	INCLUDE 'MHFUNC.INC'

b. Detailed using methods are shown in example test.for .

============
Error code
============
   Refer to ERRCODE-ENG.TXT in the root of the installation directory for detailed 
   information about error codes.

=========
Cautions
=========
   If you want to run the protected application in other computer in Windows 9x/ME or 
   Windows NT/2000/XP, you should install the corresponding device driver 
   for the hardware Dog. Please use MicroDogInstdrv.exe in the DRIVER folder to install 
   the correct driver.

=====
Note
=====
   The protected applications can use either USBDog or Parallel Dog when running in the operating
   systems such as Windows 98, Windows ME, Windows 2000 and Windows XP. The current version of 
   MicroDog can support only Parallel Dog when the application is running in Windows NT 4.0, 
   so please contact us if you need to operate USBDog in that environment.

=================
Technical support
=================
   If you have any technical problems, please contact Rainbow China Co., Ltd., 
   our branches, or our distributors. Please Refer to Address.txt for the contact address.
