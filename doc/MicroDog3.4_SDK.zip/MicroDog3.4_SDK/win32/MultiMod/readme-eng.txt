            ----------------------------------------------------------------
		MicroDog Suite API Guide to Multimodule Dynamic Library 
            ----------------------------------------------------------------
                          	Copyright (c) 2003 Rainbow China Co., Ltd.

     MicroDog Suite combines all advantages and features of USBDog(UMC type) and Parallel 
Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel Dog(PMH type) 
which are compatible with each other.The protected applications can use either USBDog or 
Parallel Dog when running in the operating systems such as Windows 98, Windows ME,Windows 2000 
and Windows XP. The current version of MicroDog can support only Parallel dog when the application
is running in Windows NT 4.0 , so please contact us if you need to operate USBDog in that environment.

===========
Functions
===========
   Using multi-module dynamic library can encrypt the multi-modules of software effectively
and limit the times of using module.

===============================
Set  Authentication Secret Key
===============================
   You must set the authentication secret key first before using the sample program which 
call the DogMM.dll. The step of setting the authentication secret key as follows.

1 Run DogEdt32.exe in Utility directory

2 Click the "Memory Edit" button,then check the "using multimod" checkbox,then click the 
  "Multimod Memory Edit"sheet

3 Input the authentication secret key in the Editbox,now we set <abcdef>(This is same with
  the key in the sample program ),the developer can set the validity of module and the count
  of module according the demand.   The developer can modify the authentication secret key 
  arbitrarily, but the corresponding modification must be done in the corresponding sample 
  program.In the sample of test,the developer need do corresponding modification to the char 
  array of DogKey. 

4 Click write button to finish setting,then you can use sample program to test.

Caution:During Delpi calls the multi-module Dll, the interface of authentication key is not 
	necessary, so the step for setting the key is ignored.
=================
The API of DLL
=================

1.HRESULT RCDog_Open(DWORD Password,BYTE Cascade)
  This function is used to open dog,it must be called first. If the developer want open the 
  another dog,he must call the  RCDog_Close() fuctoin before calling RCDog_Open.Now we don't 
  support operate the mutil_dogs at the same time. 
  Input Parameter: password of reading or writing dog,cascade. cascade is the number from 0 to 15.

	
2.void RCDog_Close()
  Close dog and release the corresponding resource.If the developer already opened a dog,he must 
  call this function before opening another dog.

3.BOOL RCDog_CheckModule(WORD ModuleNo)
  This function is used to check the validity of module.If the module is valid, this function 
  return TRUE.If the module is invlid or occuring mistake , this function return FALSE.(especial 
  instance: if the module is valid and can be decrease, but the module count is ZERO,the function
  return FALSE)

4.HRESULT RCDog_GetModule(WORD ModuleNo,WORD *ret)
  This function is used to get the using count of module
  Input Parameter: the ModuleNo and the address which is used to store the count.
  The developer can only use DogEdt32.exe to set module using count. 

5.HRESULT RCDog_DecModule(WORD ModuleNo)
  This function is used to subtract 1 from the current module count.
  Input Parameter: the ModuleNo which is needed to subtract 1. 


6.HRESULT RCDog_GetSecureWord(DWORD WordNum,WORD *ret);
  This function is used to get the restricted word.
  Input Parameter:the number of restricted word and the address which is used to 
                  store the return value
  If WordNum equal 1, the validity restricted word is returned.
  If WordNum equal 2, the degressive restricted word is returned.

7.HRESULT RCDog_AuthDog(DWORD AriNo,BYTE * Random,DWORD RanLen,BYTE * ret)
  This function is used to verify the dog's authentication secret key.
  The dog's authentication secret key is a string with random length which is defined 
  by the developer,the developer can use DogEdt32.exe to set the key.We use the MD5 
  algorithm to convert the key into 16 bytes HASH value and store this HASH value in 
  the Hardware dog.
  Input Parameter:
  AriNo now it must be 1,we only support the 128 bit RC6 algorithm at present.
  Random The random number pointer
  RanLen The length of random number
  ret    The address which is used to store the encrypted value.

Caution:During Delpi calls the multi-module Dll, the interface of authentication key is not 
	necessary.

8.DWORD RCDog_GetLastDogError()
  This function is to used to get the dog's error code when the mistake occur.
  If you call 1,3,3,5,6,7 functions , you can call this function get the dog's 
  error code when the error code equal E_FAIL. 

===========
Caution:
===========
In order to assure the security,the developer may reference our sample program and 
use the DogMM.dll with the following step.

1 Load the dynamic library 

2 Mapping the API function of DogMM.dll

3 Call RCDog_Open to open dog

4 Call Checkdll function to verify the dog's authentication secret key.(The CheckDll 
  function include the call of RCDog_AuthDog function)

  Caution:During Delpi calls the multi-module Dll, the interface of authentication key is not 
	necessary, so the step for checking DLL is ignored.

5 Use RCDog_CheckModule,RCDog_GetModule,RCDog_DecModule to check the validity of module,
  get the current module's count,subtract 1 from the current module's count.

6 Use RCDog_Close function to close dog

7 Free the handle of the dynamic library



================
Error code list
================

0XA0010001L  //not use RCDog_Open function
0XA0010002L  //the module is invalid
0XA0010003L  //the ModuleNo is not in the range(from 0 to 15)
0XA0010004L  //restricted word is invalid
0XA0010005L  //AlgorithmNo is invalid
0XA0010006L  //restricted word is 0
0XA0010007L  //degression restricted bit is 0
0XA0010008L  //The count of module is 0

The other error code please reference Errcode.txt



===========
File list
===========
README-ENG.TXT   This file
DogMM.dll        The dynamic library of multi-module

Delphisample  <dir>	 Delphi6.0 sample program for calling multi-module DLL
	Demo.dfm		The form file
	Demo.pas		The source file
	Project.dpr		The project file
	Project.res		The res file
	Project.exe		The execute file


VcSample  <dir>  It provides the sample of testing DogMM.dll and using DogMM.dll(in the 
                 sample program the dog's authentication secret key is <abcdef> default,
                 the developer can modify this key according to the real demand) 
               
	moduletest.exe   The execute file
	moduletest.dsw   The project file
	moduletest.dsp   The project file
	moduletest.cpp   The source file of sample
	moduletest.h     The head file of sample
	moduletest.rc    The resource file of sample
	variblefunc.h    The head file of the API function and variable declaration 
	RC6.obj	   	 The obj file of RC6 algorithm
	MD5.obj          The obj file of MD5 algorithm
	MD5.H            The head file of MD5 algorithm
	RC6.H            The head file of RC6 algorithm
	ErrorCode.h	 The error code file

=================
Technical Support
=================
    For technical issues, please contact Rainbow China Co., Ltd. or its distributors 
immediately. 

    For contact address, please see Address.txt under installation path.


