//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by moduletest.rc
//
#define IDD_MODULETEST_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON0                     1002
#define IDC_BUTTON1                     1003
#define IDC_BUTTON2                     1008
#define IDC_BUTTON3                     1009
#define IDC_BUTTON4                     1010
#define IDC_BUTTON5                     1011
#define IDC_BUTTON6                     1012
#define IDC_BUTTON7                     1013
#define IDC_BUTTON8                     1014
#define IDC_BUTTON9                     1015
#define IDC_BUTTON10                    1016
#define IDC_BUTTON11                    1017
#define IDC_BUTTON12                    1018
#define IDC_BUTTON13                    1019
#define IDC_BUTTON14                    1020
#define IDC_BUTTON15                    1021
#define IDC_STATIC_RESULT_GROUP         1022
#define IDC_STATIC_RESULT_TEXT          1023
#define IDC_BUTTON_CHECKDLL             1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
