
//Varibles for calling the dll
    HINSTANCE hDog;
	ULONG DogPassword;
	BYTE DogCascade;
	HRESULT hresult;
	WORD    ModuleNo;
	BOOL    bValid;
	WORD    ModuleCount;
	char	DogKey[6]={'a','b','c','d','e','f'};//the developer should change this value according to the string which is used to generate Dog Authorization Key
	int     DogKeyLen=6;//DogKeyLen is the real size of DogKey;

//Declaration of interface function of calling dll
HRESULT(* RCDog_Open)(DWORD Password,BYTE Cascade);
void( * RCDog_Close)();
BOOL(* RCDog_CheckModule)(WORD ModuleNo);
HRESULT(* RCDog_GetModule)(WORD ModuleNo,WORD *ret);
HRESULT(* RCDog_DecModule)(WORD ModuleNo);
HRESULT(* RCDog_AuthDog)(DWORD AriNo,BYTE * Random,DWORD RanLen,BYTE * ret);
DWORD(* RCDog_GetLastDogError)();
BOOL CheckDll(PCHAR Key,int KeyLen);
