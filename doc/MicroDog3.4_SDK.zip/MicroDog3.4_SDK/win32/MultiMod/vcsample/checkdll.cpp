#include "stdafx.h"
#include "md5.h"
#include "rc6.h"
extern HRESULT(* RCDog_AuthDog)(DWORD AriNo,BYTE * Random,DWORD RanLen,BYTE * ret);


BOOL CheckDll(PCHAR Key,int KeyLen)
{

	MD5  md5object;
	char Md5Key[12]={'1','3','2','4','3','5','4','6','5','7','6','8'};//Encrypt key of md5
	UCHAR    sign[16];                                            // Signature string of MD5
	RC6_KEY RC6Key;
	int RandomLen=16;
	HRESULT hresult;
	unsigned char Random[16];
	unsigned char Random1[16];
	unsigned char Random2[16];

	memset(sign,0,16);

	srand((unsigned)time(NULL));
	for (int i=0;i<8;i++)
	{
		*(int *)&Random[2*i]=rand();
	}

	hresult=RCDog_AuthDog(1,Random,RandomLen,Random1);
	if (hresult!=S_OK)
	{
		return FALSE;
	}
	md5object.SetKey(Md5Key,12);
    md5object.Encrypt((PCHAR)Key,KeyLen,sign);
	GenerateKey(sign,&RC6Key);
	RC6DecryptData(&RC6Key,Random1,16,Random2);
	for (int j=0;j<RandomLen;j++)
	{
		if (Random[j]!=Random2[j])
		{
			return FALSE;
		}
	}
	return TRUE;

}
