//###########################################################################
//
//     Filename:  RC6.H
//  S/W Part No:  
//       Author:  Dennis Xiang
//         Date:  2000-09-12
//			Ver:  1.0
//
//      Purpose:  
//     Platform:  Win32s on Win 3.X, Win9x and WinNT 3.5 or Higher
//
//  Decriptions:  Head file of RC6,define the varibles ,structures and functions
//	
//
//  Change History:
//###########################################################################

#define RC6W unsigned long 	
#define lgW	5					
#define const_r	20			
#define const_b 16			
#define P32 0xB7E15163l;		
#define Q32 0x9E3779B9l;		


#define Improper_Text_Length	1


typedef struct _RC6_KEY
{
	char Signature[4];	

	unsigned long Length;	

	RC6W SKey[2*const_r+4];
} RC6_KEY, * PRC6_KEY;

#define Improper_Text_Length	1


void GenerateKey(void * bRand,PRC6_KEY);

unsigned long RC6EncryptData(RC6_KEY * hKey, unsigned char* PlainText, unsigned long TextLen, unsigned char* CipherText);
unsigned long RC6DecryptData(RC6_KEY * hKey, unsigned char* CipherText, unsigned long TextLen, unsigned char* PlainText);
RC6W RoundLeft(RC6W num, RC6W bit);
RC6W RoundRight(RC6W num, RC6W bit);