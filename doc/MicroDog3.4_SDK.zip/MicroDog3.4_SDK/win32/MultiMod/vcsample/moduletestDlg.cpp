/***********************************************************************

Testing sample of Multimodule
Copyright (C) 2001 Rainbow China Co.,Ltd. All Rights Reserved

Module name:
    moduletestDlg.cpp 

Function introduction:
    The implementation file of testing multimodule 

Developer:
    zhengzh

Date:
    2001.11.27

***********************************************************************/

// moduletestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "moduletest.h"
#include "moduletestDlg.h"
#include "variblefunc.h"
#include "errcode.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/*****************************
       Testing Function
*****************************/
void moduletest(WORD ModuleNo,char Message[500])
{
	DWORD retdog; 
	bValid=RCDog_CheckModule(ModuleNo);

	if (bValid==TRUE)
	{
			
        /*Excute the following operation 
		  if you want to decrease by degrees*/
		hresult=RCDog_DecModule(ModuleNo);

		//Judge whether the decreasing by degrees is valid
		if (hresult!=S_OK)
		{
			if (hresult==E_FAIL)
				retdog=RCDog_GetLastDogError();//Get the error code of the dog

            sprintf (Message, " Module%d is valid!\n",ModuleNo);
		}
		else 
        {    			
		    /*Excute the following operation 
		      if the using times is limited*/
            hresult=RCDog_GetModule(ModuleNo,&ModuleCount);

			if (hresult==S_OK&&ModuleCount>0)
			{
	
                sprintf (Message, " Module%d is valid!\n The using times of the module decrease by 1!\n Module%d can still be used %d times\n",ModuleNo,ModuleNo,ModuleCount);
			}
		    else 
			{
				  if (hresult==E_FAIL)
						retdog=RCDog_GetLastDogError();//Get the error code of the dog

                  sprintf (Message, " Module%d is valid!\n Module%d can't be used since now!\n",ModuleNo,ModuleNo);
			}
		}
	}
	else 
	{
        sprintf (Message, "Module%d is invalid!\n",ModuleNo);
	}  
}

/////////////////////////////////////////////////////////////////////////////
// CModuletestDlg dialog

CModuletestDlg::CModuletestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CModuletestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CModuletestDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
 	DWORD retdog; 
   	
	hDog=LoadLibrary(TEXT("DogMM.dll"));//load the  dll
 
	if(hDog != NULL)
	{
		//Map the interface functions from dll
		RCDog_Open=(HRESULT(*)(DWORD,BYTE))GetProcAddress(hDog,"RCDog_Open");
		RCDog_Close = (void(*) ())GetProcAddress(hDog,"RCDog_Close");
		RCDog_CheckModule=(BOOL(*)(WORD))GetProcAddress(hDog,"RCDog_CheckModule");
		RCDog_GetModule=(HRESULT(*)(WORD,WORD *))GetProcAddress(hDog,"RCDog_GetModule");
		RCDog_DecModule=(HRESULT(*)(WORD))GetProcAddress(hDog,"RCDog_DecModule");
		RCDog_AuthDog=(HRESULT(*)(DWORD,BYTE *,DWORD,BYTE*))GetProcAddress(hDog,"RCDog_AuthDog");
		RCDog_GetLastDogError = (DWORD(*) ())GetProcAddress(hDog,"RCDog_GetLastDogError");
	    
		//RCDog_Open
		DogPassword=0;//The DogPassword should be same to the DogPassword in the dog
		DogCascade=0;//The DogCascade should be same to the DogCascade in the dog
		hresult = RCDog_Open(DogPassword,DogCascade);	

		if (hresult==S_OK)
		{
		}
		else
		{
		  if (hresult==E_FAIL)
			retdog=RCDog_GetLastDogError();//get the error code of the dog
            CString str;
            str.Format(_T("%s\n"),"Can't open the dog");
	        MessageBox((LPCTSTR) str,"Excuting Result",MB_OK);
		    exit(0);
		}		
	}
	else
	{
	  CString str;
      str.Format(_T("%s\n"), "The dll can't be found");
	  MessageBox((LPCTSTR) str,"Excuting Result",MB_OK);
	  exit(0);
	};
	// TODO: Add extra initialization here
}


void CModuletestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CModuletestDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CModuletestDlg, CDialog)
	//{{AFX_MSG_MAP(CModuletestDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON0, OnButton0)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_BN_CLICKED(IDC_BUTTON7, OnButton7)
	ON_BN_CLICKED(IDC_BUTTON8, OnButton8)
	ON_BN_CLICKED(IDC_BUTTON9, OnButton9)
	ON_BN_CLICKED(IDC_BUTTON10, OnButton10)
	ON_BN_CLICKED(IDC_BUTTON11, OnButton11)
	ON_BN_CLICKED(IDC_BUTTON12, OnButton12)
	ON_BN_CLICKED(IDC_BUTTON13, OnButton13)
	ON_BN_CLICKED(IDC_BUTTON14, OnButton14)
	ON_BN_CLICKED(IDC_BUTTON15, OnButton15)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUTTON_CHECKDLL, OnButtonCheckdll)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CModuletestDlg message handlers

BOOL CModuletestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
    	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CModuletestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CModuletestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

/*************************
      Testing Module0
*************************/
void CModuletestDlg::OnButton0() 
{
    char Message[500];
    ModuleNo=0;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);	
}

/*************************
      Testing Module1
*************************/

void CModuletestDlg::OnButton1() 
{
    char Message[500];
    ModuleNo=1;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
}

/*************************
      Testing Module2
*************************/

void CModuletestDlg::OnButton2() 
{
    char Message[500];
	ModuleNo=2;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
}

/*************************
      Testing Module3
*************************/

void CModuletestDlg::OnButton3() 
{
    char Message[500];
	ModuleNo=3;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
	
}

/*************************
     Testing Module4
*************************/

void CModuletestDlg::OnButton4() 
{
    char Message[500];
    ModuleNo=4;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
}

/*************************
      Testing Module5
*************************/

void CModuletestDlg::OnButton5() 
{
    char Message[500];
    ModuleNo=5;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
	
}

/*************************
      Testing Module6
*************************/

void CModuletestDlg::OnButton6() 
{
    char Message[500];
	ModuleNo=6;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);	
}

/*************************
     Testing Module7
*************************/

void CModuletestDlg::OnButton7() 
{
    char Message[500];
	ModuleNo=7;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
	
}

/*************************
     Testing Module8
*************************/

void CModuletestDlg::OnButton8() 
{
    char Message[500];
	ModuleNo=8;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);	
}

/*************************
      Testing Module9
*************************/

void CModuletestDlg::OnButton9() 
{
    char Message[500];
	ModuleNo=9;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
	
}

/*************************
      Testing Module10
*************************/

void CModuletestDlg::OnButton10() 
{
    char Message[500];
	ModuleNo=10;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
	
}

/*************************
       Testing Module11
*************************/

void CModuletestDlg::OnButton11() 
{
    char Message[500];
	ModuleNo=11;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
}

/*************************
      Testing Module12
*************************/

void CModuletestDlg::OnButton12() 
{
    char Message[500];
	ModuleNo=12;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
}

/*************************
     Testing Module13
*************************/

void CModuletestDlg::OnButton13() 
{
    char Message[500];
	ModuleNo=13;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);	
}

/*************************
      Testing Module14
*************************/

void CModuletestDlg::OnButton14() 
{
    char Message[500];
	ModuleNo=14;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
}

/*************************
      Testing Module15
*************************/

void CModuletestDlg::OnButton15() 
{
    char Message[500];
	ModuleNo=15;//The number of the module which needs testing
	moduletest(ModuleNo, Message);
    GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
}

/*************************
      Check dll
*************************/
void CModuletestDlg::OnButtonCheckdll() 
{
	char Message[500];
	/*if you want to authenticate the dll,call the function Checkdll,
	  this function will finish this operation*/
	if (CheckDll(DogKey,DogKeyLen)==TRUE)//authenticate successfully
	{
	   sprintf(Message,"Authenticate the dll successfully");
	   GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
	}
	else//authenticate failed
	{
       sprintf(Message,"Authenticate the dll failed");
	   GetDlgItem(IDC_STATIC_RESULT_TEXT)->SetWindowText(Message);
	}	
	
}

void CModuletestDlg::OnCancel() 
{

    RCDog_Close();//finishing the operation of the dog,close the dog
    FreeLibrary(hDog);//free the dll
	CDialog::OnCancel();
}

void CModuletestDlg::OnClose() 
{

	RCDog_Close();//finishing the operation of the dog,close the dog	
	CDialog::OnClose();
}


