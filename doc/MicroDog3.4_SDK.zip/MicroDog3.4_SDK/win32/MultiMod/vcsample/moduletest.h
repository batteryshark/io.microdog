// moduletest.h : main header file for the MODULETEST application
//

#if !defined(AFX_MODULETEST_H__D9469349_114E_4CCD_A152_2C948C932BDE__INCLUDED_)
#define AFX_MODULETEST_H__D9469349_114E_4CCD_A152_2C948C932BDE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CModuletestApp:
// See moduletest.cpp for the implementation of this class
//

class CModuletestApp : public CWinApp
{
public:
	CModuletestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CModuletestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CModuletestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MODULETEST_H__D9469349_114E_4CCD_A152_2C948C932BDE__INCLUDED_)

