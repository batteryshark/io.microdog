		   ------------------------------------------
		         File list for win32 folder
		   ------------------------------------------
                   Copyright (c) 2002, Rainbow China Co., Ltd.
  
     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of MicroDog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.


  Note: 
	The RC-MH specified below has exactly the same functions of MicroDog Suite.

  File list
  ---------
  The files and directories below are included in directory WIN32, all modules are suitable
  for real 32-bit Windows system. 
  Please refer to Readme file and demo program under each directory for specification 
  for the interface function in detail.      

  \WIN32
    |- README-ENG.TXT  This file.
    |
    |- Control		<dir> The demo for control
	 |- ACTIVEX        <dir>  - API & demo program for ActiveX control
    |    |    |
    |    |    |- JAVASCRIPT    <dir> - A javascript demo program for calling ActiveX control
    |    |    |
    |    |    |- VBSCRIPT      <dir> - A vbscript demo program for calling ActiveX control
    |    |    |
    |    |    |- VB		<dir> - A vb demo program for calling ActiveX control
    |    |    |
    |    |    |- VC		<dir> - A vc demo program for calling ActiveX control
    |    | 
    |    |- DLLCONTROL     <dir> API & demo program for DLL control
    |    
    |- AUTOCAD        <dir>  - The demo for AutoCAD ARX
    |    
    |    
    |- DELPHI         <dir>  - API & demo program for 32-bit Windows DELPHI compiler
    |			       (Borland Delphi 2.0 ~ 5.0 ).
    |
    |- EXETOOL        <dir>  - Protection tool used to protect EXE files running under 32-bit 
    |                          WIndows directly. 
    |
    |- JAVA           <dir>  - A DLL including its source code and JAVA application to show how
    |                          to call the DLL.(jdk1.1.4 & jsdk2)
    |
    |- LAHEY_F        <dir>  - API & demo program for LAHEY FORTRAN 90 V4.0 compiler. 
    |
    |- POWER_F        <dir>  - API & demo program for MS Powerstation FORTRAN compiler. 
    |
    |- RemoteUpgrade  <dir>  - The utility for multimodule's remoteupgrading
    |    |
    |    |-CLIENT 	  <dir> - The client's utility and sample program for remoteupgrading
    |    |
    |    |-DEVELOPER      <dir> - The developer's utility and sample program for remoteupgrading
    |
    |
    |- Visual_f       <dir>  - The demo program for Visual FORTRAN V6.0
    |
    |- WIN32C 
    |    |
    |    |- BORLANDC      <dir>  - API & demo program for Borland C/C++ compiler. 
    |    |
    |    |- CBUILDER      <dir>  - A C++ Builder demo program of for calling API for 
    |    |                         BORLAND C/C++.
    |    |
    |    |- MSVC          <dir>  - API & demo program for MSVC compiler. 
    |    |
    |    |- MFCDEMO       <dir>  - A MFC demo program for calling API for MSVC compiler. 
    |
    |- WIN32DLL       
         |
         |-HIGHDLL        <dir>  - A high strength dll and  C language sample program of call 
         |                         this DLL
         |
         |
         |-NORMALDLL      <dir>  -  A DLL including its source code and various kinds of applications 
         |                         to show how to call the DLL including VC, VB, VFP and PB .
	 | 
         |
         |-OTHERDLL       <dir>  - Other DLL and example for C#,VB.NET and OMNI

  Important Note
  --------------
1) If you want to run the protected application in other computer in Windows 9x or 
   Windows ME or Windows NT or Windows 2000 or Windows XP, you should install the 
   corresponding device driver for the hardware Dog. Please use INSTDRV.EXE in the 
   DRIVER folder to install the correct driver.

2) If you want to release your protected programs to your end-users, please include
   the device driver installing tool in the DRIVER folder in your SETUP process,
   and execute installing the device drivers for the Dog first. 

3) One important thing is that, because the DLL is separated from the protected 
   application, the calling interface of DLL functions is then exposed to hacker 
   (because of the nature of DLL). Here comes the importance for the hiding of DLL 
   functions' name and function calling.  Therefore, we strongly recommend you to 
   use static API Library (such as C API) to protect your application other than DLL 
   in general. If DLL method must be used, and the strength of the protection comes 
   from the complexity of your own DLL, the software developer must make the DLL as 
   complicated as possible. The functions' calling interface of DLL must be hidden 
   well, and the functions' names in the DLL should not be relative with the Dog 
   operation. The sequence of parameters passing should also be baffling for hackers, 
   and the Dog operation functions should be merged with your own other DLL functions. 

   For your benefits, please remember that WIN32DLL.DLL we provided is only a sample 
   program. It should not be used for any kind of protection work, since its source 
   code is already open to public. You should follow the above principles to develop 
   you own DLLs by calling C/C++ API module. 
   
   If the developer use C language to call dll to protect the application,we propose 
   you use high strength dll(WIN32HDLL.dll) to enhance the application's security.

4) To increase protection intensity, we strongly recommend you that after using DLL 
   protection, building a protected EXE file, you should use our SHELL encryption 
   tool (in WIN32\EXETOOL directory) to protect the EXE file further.
