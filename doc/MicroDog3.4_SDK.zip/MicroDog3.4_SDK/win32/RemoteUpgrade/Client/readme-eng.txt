	---------------------------------------------------------------------
                    Microdog Suite 32-bit Windows Application
                        Illustration of Remote Upgrade DLL sample 
        ---------------------------------------------------------------------
                          	Copyright (c) 2003 Rainbow China Co., Ltd.

     MicroDog Suite combines all advantages and features of USBDog(UMC type) and Parallel 
Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel Dog(PMH type) 
which are compatible with each other.The protected applications can use either USBDog or 
Parallel Dog when running in the operating systems such as Windows 98, Windows ME,Windows 2000 
and Windows XP. The current version of MicroDog can support only Parallel dog when the application
is running in Windows NT 4.0 , so please contact us if you need to operate USBDog in that environment.


=========
Functions
=========
  Microdog Suite contains two Hardware Dog (MicroDog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of MicroDog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.
  Microdog Suite has six functions including verifying of the correct Hardware Dog, writing 
data into and reading data from the memory, changing data, checking the current manufacturing 
number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogCovert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-digit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel portsharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
    The six functions specified above will secure your software products from any unauthorized 
use.  For detailed description of protection strategy, please read The Developer's Manual 
(Microdog DOC).

============
File list
============

         DogRuClt.dll       remote upgrade DLL
         VcSample<dir>      example for remote upgeade DLL(VC6.0)
	 DelphiSample<dir>  example for remote upgeade DLL(Delphi5.0)
============
API Functions
============
   
DLL of client has two interfaces,one is for producting authentication string,the other is for upgrading 
for multiple module

l.    HRESULT	GenClientString([out]CHAR * Buf, [in, out]ULONG *len,[in]ULONG Pas
sword,[in]UCHAR Cascade);

function describe:
	To product request string of remote upgrade client

parameter describe:

	Buf:	
			output parameter,to product memory area pointer for authentication string
        len:
			This parameter indecate the lenth of the  memory area during input process 
			and indecate the lenth of the producted authentication string during output process
        Password:    
			input parameter which is correspond to dog password
        Cascade:
			input parameter which is correspond to dog cascade number
                  


2.	HRESULT	UpdateModule([in]CHAR * ServerString,[in]ULONG Password,[in]UCHAR Cas
cade,[in]ULONG nLen );

function describe:
	You can invoke this fuction to UpdateMultimodule after getting the backing out string
	from the developer.This fuction can estimate whether the remote upgrade key is right or not 
	during excution. After excuting correctly,the fuction of the corresponding upgrade module will 
	be released


parameter describe:

	ServerString:	
			output parameter,to product memory area pointer for authentication string
        Password:    
			input parameter which is correspond to dog password
        Cascade:
			input parameter which is correspond to dog cascade number
	nLen:
			This parameter indicate the lenth of the  memory area during input process 
			and indicate the lenth of the producted authentication string during output process

===========
Error code
===========

60001:
        input parameter wrong
60002:
        the update string of developer is destroied or amended
60003:
        the update string of developer is destroied or amended



=================
Technical support
=================
If you have any technical problems, please contact Rainbow China Co., Ltd., 
our branches, or our distributors.  


Please Refer to  /Address.txt for the contact address.

