// UpdateCltDlg.cpp : implementation file
//
// This application demonstrates how to invoke the DLL for client remote upgrade
//
//////////////////////////////////////

#include "stdafx.h"
#include "UpdateClt.h"
#include "UpdateCltDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
//API Functions:
/*
 HRESULT	GenClientString([out]CHAR * Buf, [in, out]ULONG *len,[in]ULONG Password,[in]UCHAR Cascade));

Function describe:
	produce client request string with remote upgrade

Parameter describe:

	Buf:	
			output parameter,to produce memory area pointer for authentication string
        len:
			This parameter indecate the lenth of the  memory area during input process 
			and indecate the lenth of the product authentication string during output process
        Password:    
			input parameter which is correspond to dog password
        Cascade:
			input parameter which is correspond to dog cascade number
                  
HRESULT	UpdateModule([in]CHAR * ServerString,[in]ULONG Password,[in]UCHAR Cascade,[in]ULONG nLen );

Function describe:
	You can invoke this fuction to UpdateMultimodule after getting the backing out string
	from the developer.This fuction can estimate whether the distant upgrade key is right or not 
	during excution. After excuting correctly,the fuction of the corresponding upgrade module will 
	be released
Parameter describe:

	ServerString:	
			output parameter,to produce memory area pointer for authentication string
        Password:    
			input parameter which is correspond to dog password
        Cascade:
			input parameter which is correspond to dog cascade number
	nlen:   
			This parameter indecate the lenth of the  memory area during input process and 
			indecate the lenth of the producted authentication string during output process
*/
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUpdateCltDlg dialog

CUpdateCltDlg::CUpdateCltDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUpdateCltDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUpdateCltDlg)
	m_ServerString = _T("");
	m_ClientString = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CUpdateCltDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUpdateCltDlg)
	DDX_Text(pDX, IDC_EDIT2, m_ServerString);
	DDX_Text(pDX, IDC_EDIT3_CLIENT, m_ClientString);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CUpdateCltDlg, CDialog)
	//{{AFX_MSG_MAP(CUpdateCltDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUpdateCltDlg message handlers

BOOL CUpdateCltDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CUpdateCltDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CUpdateCltDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CUpdateCltDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CUpdateCltDlg::OnButton1() 
{
	
	HINSTANCE hCom;
	unsigned long result;
	char tempstr[200];
	//Define fuction pointer type
	typedef unsigned long (__stdcall *GENCLIENTSTRING)(CHAR *,ULONG *,ULONG,UCHAR);
	//Define fuction pointer 
	GENCLIENTSTRING pGenClientString=NULL;
	//load DLL
	hCom=::LoadLibrary("DogRUClt.dll");
	if(hCom==NULL)
	{
		::MessageBox(NULL,"DogRUClt.dll not found!","Warning",MB_ICONEXCLAMATION|MB_OK);
        ::FreeLibrary(hCom);
		return;
	}
	//Map interface fuction address
	VERIFY(pGenClientString=(GENCLIENTSTRING)::GetProcAddress((HMODULE)hCom,"GenClientString"));

	char ClientString[48];
	memset(ClientString,0,48);
	ULONG Len=48;
	memset(ClientString,0,48);
	//Invoke fuction interface
	result=pGenClientString(&ClientString[0],&Len,0,0);
	if(result)
	{
		sprintf(tempstr,"Produce request string failed,the error code is %u",result);
		AfxMessageBox(tempstr);
	}
	else
	{
	AfxMessageBox("Produce request string succeed!");
	}
    ::FreeLibrary(hCom);
	memcpy(m_ClientString.GetBufferSetLength(48),ClientString,48);

	UpdateData(false);

	
}

void CUpdateCltDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	
	HINSTANCE hCom;
	unsigned long result;
	char tempstr[200];
	
	//Define fuction pointer type
	typedef unsigned long (__stdcall *UPDATEMODULE)(CHAR *,ULONG,UCHAR,ULONG);
	//Define fuction pointer
	UPDATEMODULE pUpdateModule=NULL;
	//Load dll
	hCom=::LoadLibrary("DogRUClt.dll");
	if(hCom==NULL)
	{
		::MessageBox(NULL,"DogRUClt.dll not found!","Warning",MB_ICONEXCLAMATION|MB_OK);
        ::FreeLibrary(hCom);
		return;
	}
	//Map interface fuction address
	VERIFY(pUpdateModule=(UPDATEMODULE)::GetProcAddress((HMODULE)hCom,"UpdateModule"));
	//Invoke fuction interface
	result=pUpdateModule(m_ServerString.GetBufferSetLength(m_ServerString.GetLength()),0,0,m_ServerString.GetLength());
	if(result)
	{
		sprintf(tempstr,"Upgrade multiple module failed,the error code is %u",result);
		AfxMessageBox(tempstr);
	}else
	{

	AfxMessageBox("Upgrade multiple module succeed!");
	}
	
	UpdateData(false);
    ::FreeLibrary(hCom);
}
