	---------------------------------------------------------------------
                    MicroDog Suite 32-bit Windows Application
                        Illustration of Remote Upgrade Module
        ---------------------------------------------------------------------
	        Copyright (c) 2003, Rainbow China Co., Ltd.


     MicroDog Suite combines all advantages and features of USBDog(UMC type) and Parallel 
Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel Dog(PMH type) 
which are compatible with each other.The protected applications can use either USBDog or 
Parallel Dog when running in the operating systems such as Windows 98, Windows ME,Windows 2000 
and Windows XP. The current version of MicroDog can support only Parallel dog when the application
is running in Windows NT 4.0 , so please contact us if you need to operate USBDog in that environment.

=======================
MicroDog remote UpdateModule brief introduction  
=======================
Distant UpdateModule provide the developer a distant method of changing the multiple module setting 
in Dog. The suite contains DLL of the client and the ocx controller of the developer.The DLL 
of the client has two interface functions,one is for producting distant upgrade request string,
one is for upgrading the results based on the developer's backtrack;the controller of developer 
has 4 interface functions,these are for testing the client request string and product return string
based on the input result.The developer can use developer compilation tools for distant upgrading,
he can invoke the controller of developer to program also. 
============
File list
============

         Client<dir>       	  DLL of remote upgrade client and example program
         Developer<dir>           controller of remote developer and example program

