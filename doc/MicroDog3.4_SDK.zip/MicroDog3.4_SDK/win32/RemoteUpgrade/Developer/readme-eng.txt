	---------------------------------------------------------------------
                    Microdog Suite 32-bit Windows Application
                        Illustration of Remote Upgrade Module
        ---------------------------------------------------------------------
	        Copyright (c) 2003, Rainbow China Co., Ltd.

     MicroDog Suite combines all advantages and features of USBDog(UMC type) and Parallel 
Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel Dog(PMH type) 
which are compatible with each other.The protected applications can use either USBDog or 
Parallel Dog when running in the operating systems such as Windows 98, Windows ME,Windows 2000 
and Windows XP. The current version of MicroDog can support only Parallel dog when the application
is running in Windows NT 4.0 , so please contact us if you need to operate USBDog in that environment.


=========
Functions
=========
  Microdog Suite contains two Hardware Dog (MicroDog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the
 Hardware Dog of MicroDog into the parallel port or that of USBDog into the USB port.  The
 software supplies functions for calling the Hardware Dog.
  Microdog Suite has six functions including verifying of the correct Hardware Dog, writing 
data into and reading data from the memory, changing data, checking the current manufacturing 
number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogCovert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-digit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel portsharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
    The six functions specified above will secure your software products from any unauthorized 
use.  For detailed description of protection strategy, please read The Developer's Manual 
(Microdog DOC).

============
File list
============


         DogRuSvr.ocx       	  Controller of remote upgrade developer
         SvrSetup.exe             controller installation program
         VCSample<dir>            example of remote upgrade developer(VC6.0)    
         DelphiSample<dir>        example of remote upgrade developer(Delphi5.0)
============
API Functions
============
Before use this controller,please run SvrSetup.exe or use regsvr32.exe to installation the 
controller first.If the developer does not want to write the program of invoking controller,he can
use the remote upgrade property  in the developer compilation tools to set directly.

The controller of remote upgrade developer has 4 fuction interface which are for checking input
string and product return string based on input:

HRESULT CheckClientString([in]LPCTSTR Buff) 
	function describe:
	checkout the input string.Including whether the figure signature,lenth,time are correct 
	or not.This fuction must be invoked first while you invoke other interface fuctions. 
	Attention:Once this fuction is invoked,all the changing of the state bring from the latter 
	invokeded fuction will be cleaned totally. In other words,this fuction has the initialization action.
	It is a input parameter,a memory area pointer during input process. 



HRESULT	SetSecureBit([in]ULONG WordNum, [in]ULONG ModuleNum, [in]BOOL  isSet);
	function describe:
	 the  module  digit setting or cleanup digit for a inhibited word. WordNum is the 
	inhibited word as defined before; ModuleNum is the number of the module,to delegate to set digit 
	for which module;isSet delegate setting digit or cleanup digit.If isSet is TRUE,the corresponding
	position is 1. If isSet is FALSE  ,the corresponding position is 0.


HRESULT	SetModule([in]ULONG ModuleNum, [in]ULONG setNumber);
	function describe:
	Set the current times for a module,the first parameter is module number.There are 16 modules
	 provided,so this kind of parameter can not be more than 15.The second parameter is the times which is setted,
	it must less than 65536.

BSTR	GetServerString();
	function describe:
	After the operationgs of one time initialization, several times' digit setting and  
	module current time setting,the developer can invoke this fuction and get the back string. 

HRESULT	SetCascade([in]ULONG ulDogCascade);
	function describe:
	Set DogCascade value.

===========
Error code
===========
60001:
			parameter is wrong
60002:
                        examine the fault of client input string
60003:
                        input the fault of use times
60004:
                        fault of string length                       
60005:
                        the sum of the input modules are wrong 


=================
Technical support
=================
If you have any technical problems, please contact Rainbow China Co., Ltd., 
our branches, or our distributors.  

Please Refer to  /Address.txt for the contact address.

