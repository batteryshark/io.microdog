// SrvActiveSampleDlg.h : header file
//
//{{AFX_INCLUDES()
#include "dogrusvr.h"
//}}AFX_INCLUDES

#if !defined(AFX_SRVACTIVESAMPLEDLG_H__3C42D7D7_0890_4EC9_8CA3_A0BCA2FDA97C__INCLUDED_)
#define AFX_SRVACTIVESAMPLEDLG_H__3C42D7D7_0890_4EC9_8CA3_A0BCA2FDA97C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSrvActiveSampleDlg dialog

class CSrvActiveSampleDlg : public CDialog
{
// Construction
public:
	CSrvActiveSampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSrvActiveSampleDlg)
	enum { IDD = IDD_SRVACTIVESAMPLE_DIALOG };
	CString	m_Client;
	CString	m_Svr;
	CDogRuSvr	m_RuSrv;
	CString	m_number_dir;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSrvActiveSampleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSrvActiveSampleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SRVACTIVESAMPLEDLG_H__3C42D7D7_0890_4EC9_8CA3_A0BCA2FDA97C__INCLUDED_)
