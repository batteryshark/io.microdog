// SrvActiveSample.h : main header file for the SRVACTIVESAMPLE application
//

#if !defined(AFX_SRVACTIVESAMPLE_H__11E557E6_51A2_441D_ACD5_7D1F5AD2032F__INCLUDED_)
#define AFX_SRVACTIVESAMPLE_H__11E557E6_51A2_441D_ACD5_7D1F5AD2032F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSrvActiveSampleApp:
// See SrvActiveSample.cpp for the implementation of this class
//

class CSrvActiveSampleApp : public CWinApp
{
public:
	CSrvActiveSampleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSrvActiveSampleApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSrvActiveSampleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SRVACTIVESAMPLE_H__11E557E6_51A2_441D_ACD5_7D1F5AD2032F__INCLUDED_)
