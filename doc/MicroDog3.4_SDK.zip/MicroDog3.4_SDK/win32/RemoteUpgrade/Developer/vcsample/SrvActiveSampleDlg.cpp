// SrvActiveSampleDlg.cpp : implementation file
//
// Before using this controller,please regist the controller by regsrv32 first,then you can use it
//
/////////////////////////////////////////////////////////////////////
/*
HRESULT CheckClientString([in]LPCTSTR Buff) 
	Function describe:
	checkout the input string.Including whether the figure signature,lenth,time are correct 
	or not.This fuction must be invoked first while you invoke other interface fuctions. 
	Attention:Once this fuction is invoked,all the changing of the state bring from the latter 
	invokeded fuction will be cleaned totally. In other words,this fuction has the initialization action.
	It is a input parameter,a memory area pointer during input process.

HRESULT	SetSecureBit([in]ULONG WordNum, [in]ULONG ModuleNum, [in]BOOL  isSet);
	Function describe:
	the  module  digit setting or cleanup digit for a inhibited word. WordNum is the 
	inhibited word as defined before; ModuleNum is the number of the module,to delegate to set digit 
	for which module;isSet delegate setting digit or cleanup digit.If isSet is TRUE,the corresponding
	position is 1. If isSet is FALSE  ,the corresponding position is 0.


HRESULT	SetModule([in]ULONG ModuleNum, [in]ULONG setNumber);
	Function describe:
	Set the current times for a module,the first parameter is module number.There are 16 modules
	provided,so this kind of parameter can not be more than 15.The second parameter is the times which is setted,
	it must less than 65536.
BSTR	GetServerString();
	Function describe:
	After tne operationgs of one time initialization, several times' digit setting and  
	module current time setting,the developer can invoke this fuction and get the back string. 
HRESULT	SetCascade([in]ULONG ulDogCascade);
	Function describe:
	Set DogCascade value.
*/
#include "stdafx.h"
#include "SrvActiveSample.h"
#include "SrvActiveSampleDlg.h"
#include "dogrusvr.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSrvActiveSampleDlg dialog

CSrvActiveSampleDlg::CSrvActiveSampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSrvActiveSampleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSrvActiveSampleDlg)
	m_Client = _T("");
	m_Svr = _T("");
	m_number_dir = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSrvActiveSampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSrvActiveSampleDlg)
	DDX_Text(pDX, IDC_EDIT_CLIENT, m_Client);
	DDX_Text(pDX, IDC_EDIT_SVR, m_Svr);
	DDX_Control(pDX, IDC_DOGRUSVRCTRL1, m_RuSrv);
//	DDX_Text(pDX, IDC_EDIT_DIR, m_number_dir);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSrvActiveSampleDlg, CDialog)
	//{{AFX_MSG_MAP(CSrvActiveSampleDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
//	ON_BN_CLICKED(IDC_BUTTON_BROWSE, OnButtonBrowse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSrvActiveSampleDlg message handlers

BOOL CSrvActiveSampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSrvActiveSampleDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSrvActiveSampleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSrvActiveSampleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSrvActiveSampleDlg::OnOK() 
{
// TODO: Add extra validation here
	UpdateData();
	char tempstr[50];
    //To check the ruqest string is right or not
	long re=m_RuSrv.CheckClientString(m_Client);

	
	if(!re)
	{
		//To set the DogCascade value
		ULONG ulDogCascade = 0;
		m_RuSrv.SetCascade(ulDogCascade);
		//To set the validity inhibited word for 0 module		
		m_RuSrv.SetSecureBit(2,0,TRUE);	   
		//To set descending inhibited word for 0 module
		m_RuSrv.SetSecureBit(1,0,TRUE);   
		 //To set 1000-time ues for 0 module
		m_RuSrv.SetModule(0,1000);    
		//To get developer upgrade string
		CString szStr = "Produce upgrade string error.";
		CString szStrReturn;
		szStrReturn = m_RuSrv.GetServerString();   
		if(!strcmp(szStr,szStrReturn))
		{
			AfxMessageBox("Produce request string fail. Check dog error.");
		}
		else
		{
			m_Svr = szStrReturn; 
		}
	}
	else
	{
		sprintf(tempstr,"Produce request string fail,error code is %u",re);
		AfxMessageBox(tempstr);
	}

	UpdateData(false);
	
//	CDialog::OnOK();
}
