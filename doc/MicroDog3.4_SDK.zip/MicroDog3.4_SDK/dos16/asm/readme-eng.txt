
                     -------------------------------------------------------
	                       MicroDog Suite 16-bit DOS Application
                                      API Guide to C/C++
                                 Calling C API with ASM Language  
                     -------------------------------------------------------

                        Copyright (c) 2001, Rainbow China Co., Ltd.

     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.    

  The RC-MH specified below has exactly the same functions of MicroDog Suite.

-------------------------------------------------------------------------------------------------
    This file demonstrates how to call C API by using ASM language.


=========
Functions
=========
  MicroDog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, 
writing data into and reading data from the memory, changing data, checking the current 
manufacturing number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six basic functions specified above will secure your software products from any unauthorized
use. For detailed description of protection strategy, please read The Developer's Manual .

=========
File list
=========
   File name             Description
   --------------        -----------------------------------------------------
   README-ENG.TXT        This file
   EXAM.ASM              Example program
   
====================
Testing Environments 
====================
  MASM 5.X to 6.X
  TASM

================
API functions
================
1. APIs define the following functions which can be used in the developer's program.
       extrn _DogCheck:far         Check dog
       extrn _ReadDog:far          Read  dog
       extrn _WriteDog:far         write dog
       extrn _DogConvert:far       Conversion 
       extrn _GetCurrentNo:far     Get current number
       extrn _DisableShare:far     Disable share

2. Developers must define the following global variables in their application:
       public _Cascade             Cascade number (0 to 2)
       public _DogAddr             Address in the Dog's memory (0 to 199)
       public _DogBytes            Length of transferred data (1 to 200)
       public _DogPassword         Password Only used in Read/Write operation
       public _DogResult           Scrambled result
       public _DogData             Pointer to the input/output data

   Define the following variable in the data segment:
       _Cascade	label	byte
	       db	1 dup (?)
       _DogData	label	dword
	       db	4 dup (?)
       _DogResult	label	word
	       db	4 dup (?)
       _DogPassword	label	word
	       db	4 dup (?)
       _DogBytes	label	word
	       db	2 dup (?)
       _DogAddr	label	word
	       db	2 dup (?)


3. _DogCheck
   Input parameter:  Cascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Checks whether the hardware Dog exists.  Only the DOg that has the same serial
            number as the OBJ file can be detected.  
            In this version, the modules don't have a cascade function, and the parameter 
            Cascade will be used in the future, so it must be 0 now. If need this function, 
            please contact us.        
        
            Cascade will have the same meaning to all the functions hereafter.
      
       For example:
                ......
                ......
		mov	byte ptr ds:_Cascade,0    ; The Cascade must be 0
		call	far ptr _DogCheck
		or	ax,dx                     ; Check whether the operation succeed
		je	go_on1                    ; Jump if faild
		call	display                   ; Show the result
		jmp	next1                     
	go_on1: 
                ; Error handling
                ......
                ......
        next1:
                ; Run normally
                ......
                ......


4. _ReadDog
   Input parameter: Cascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter: DogData
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads data from the hardware Dog. The Dog contains a 200-byte nonvolatile 
             memory.  From the Dog, ReadDog reads data from the memory beginning at the 
             address indicated by DogAddr.  The byte number of the read data is indicated 
             by DogBytes.  The read data will be stored in the space that DogData points to.
             The MicroDog will verify the DogPassword. DogPassword is the password for the
             read\write operations.  It is stored in the hardware Dog.  It can be set by 
             the utility tool or the SetPassword() function. Applications must secure enough
             space to buffer the data being read.  ReadDog will not check whether the size of
             a buffer is sufficient.

   Example 1:
          Read a 30 bytes string from address 0 of the Dog's memory
                ......
          ReadCharBuff		db	30 dup (?)
                ......
		mov     byte ptr ds:_Cascade,0    ; Cascade number must be 0
                mov     word ptr ds:_DogPassword+2,0
                mov     word ptr ds:_DogPassword,0
                ; The Dog's password is set zero when leave factory. 
                ; you can modify the password by the tool DogEdit or function SetPassword().
                ; The tool is in the directory UTILITY.
		mov	word ptr ds:_DogBytes,30
		lea	ax,word ptr cs:ReadCharBuff
		mov	word ptr ds:_DogData+2,cs
		mov	word ptr ds:_DogData,ax
		mov	word ptr ds:_DogAddr,0
		call	far ptr _ReadDog
		or	ax,dx                     ; Check whether the operation succeed
		je	go_on1                    ; Jump if faild
		call	display                   ; Show the result
		jmp	next1                     
	go_on1: 
                ; Error handling
                ......
                ......
        next1:
                ; Run normally
                ......
                ......

  Example 2:
          Read an integer from address 130 of the Dog's memory.
                ......
          DemoInteger		dw	1234
                ......
		mov     byte ptr ds:_Cascade,0    ; The Cascade number must be 0
                mov     word ptr ds:_DogPassword+2,0
                mov     word ptr ds:_DogPassword,0
                ; The Dog's password is set zero when leave factory. 
                ; you can modify the password by the tool DogEdit or function SetPassword().
                ; The tool is in the directory UTILITY.
                mov     word ptr ds:_DogBytes,2
                lea	ax,word ptr cs:DInt
                mov	word ptr ds:_DogData+2,cs
                mov	word ptr ds:_DogData,ax
                mov	word ptr ds:_DogAddr,130
                call	far ptr _ReadDog
		or	ax,dx                     ; Check whether the operation succeed
		je	go_on1                    ; Jump if faild
		call	display                   ; Show the result
		jmp	next1                     
	go_on1: 
                ; Error handling 
                ......
                ......
        next1:
                ; Run normally
                ......
                ......


5. _WriteDog
   Input parameter: Cascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Writes data to the hardware Dog. Carries out the same operation as ReadDog does
            except the data flow direction is different.
   Example:
          Write a 23 bytes string to address 0 of the Dog's memory.
                ......
          WriteCharBuff		db	'Micro Dog GS-MH is OK !','$'
                ......
		mov     byte ptr ds:_Cascade,0    ; The cascade number must be 0.
                mov     word ptr ds:_DogPassword+2,0
                mov     word ptr ds:_DogPassword,0
                ; The Dog's password is set zero when leave factory. 
                ; You can modify the password by the tool DogEdit or function SetPassword().
                ; The tool is in the directory UTILITY.
		mov	word ptr ds:_DogBytes,23
		lea	ax,word ptr cs:WriteCharBuff
		mov	word ptr ds:_DogData+2,cs
		mov	word ptr ds:_DogData,ax
		mov	word ptr ds:_DogAddr,0
		call	far ptr _WriteDog
		or	ax,dx                     ; Check whether the operation is success
        	je	go_on1                    ; Jump if faild
		call	display                   ; Show the result
		jmp	next1                     
	go_on1: 
                ; Errot handling
                ......
                ......
        next1:
                ; Run normally
                ......
                ......


6. _DogConvert
   Input parameter: Cascade, DogBytes, DogData
   Output parameter: DogResult
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Transfers data to Dog.  Then the hardware Dog scrambles the data, 
             and returns the scrambled result Dogresult as a 32-bit integer.  DogBytes
             indicates the number of bytes of the date, which DogData points to, being 
             converted.The conversion algorithm can be specified by the developer.  The 
             last 4 bytes of the memory will affect the conversion algorithm.  The 196th 
             byte is used to specify the algorithm.  Therefore, the developer can define 
             256 kinds of algorithms.The algorithm descriptor is made up of the 197th,198th
             and 199th byte, so it may have a total of 16,777,215 different combinations.
    Example:
                ......
          DogConvertCharBuff	db	'Micro Dog GS-MH','$'
                ......
		mov     byte ptr ds:_Cascade,0    ; the cascade number must be 0
		mov	word ptr ds:_DogBytes,15
                lea	ax,word ptr cs:DogConvertCharBuff
		mov	word ptr ds:_DogData+2,cs
		mov	word ptr ds:_DogData,ax
		mov	word ptr ds:_DogAddr,0
		call	far ptr _DogConvert
		or	ax,dx                     ; Check whether the operation is success.
		je	go_on1                    ; Jump if faild
		call	display                   ; Show the result
		jmp	next1                     
	go_on1: 
                ; Error handling 
                ......
                ......
        next1:
                ; Run normally
                ......
                ......


7. _DisableShare
   Input parameter: Cascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Disable the hardware DOg's sharing ability.The parallel port hub is a kind 
             of hardware share device that allows multiple copies of the protected program 
             share the same Dog.Factory setting for share ability is Enable. You may call
             DisableShare function to prevent pirates from using a parallel port hub. 

    Example:
                ......
                ......
		mov	byte ptr ds:_Cascade,0    ; Cascade code must be 0
		call	far ptr _DisableShare
		or	ax,dx                     ; Check whether the operation is success
		je	go_on1                    ; Jump if faild
		call	display                   ; Show the result
		jmp	next1                     
	go_on1: 
                ; Error handling
                ......
                ......
        next1:
                ; Run normally
                ......
                ......


8. _GetCurrentNo
   Input Parameter: Cascade, DogData
   Output parameter: DogData
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads the Manufacturing code of the hardware Dog.Some of the hardware
             Dogs may have the same ID, but every hardware Dog has its unique
             Manufacturing code. The Manufacturing code can help developers manage
             user accounts.

      Example:
                ......
          CurrentNO		db	4 dup(0)
                ......
		mov     byte ptr ds:_Cascade,0    ; Cascade number must be 0
		mov	word ptr cs:CurrentNO+2,0
		mov	word ptr cs:CurrentNO,0
		lea	ax,word ptr cs:CurrentNO
		mov	word ptr ds:_DogData+2,cs
		mov	word ptr ds:_DogData,ax
		call	far ptr _GetCurrentNo
		or	ax,dx                     ; Check whether the operation is success.
		je	go_on1                    ; Jump if faild
		call	display                   ; Show the result
		jmp	next1                     
	go_on1: 
                ; Error handling 
                ......
                ......
        next1:
                ; Run normally
                ......
                ......

================================================
Compiling and running the example program 
================================================
    Compile EXAM.ASM to .OBJ, and link this OBJ file with DOS16DOG.OBJ 
to generate EXE file. 
    The example program demonstrates how the above functions run.
    This is only a simple example of calling the functions above. For advanced 
protection techniques, please refer to the MicroDog Developer's Guide.

===============
Error Codes
===============
    Refer to ERRCODE.TXT in the root of the installation directory for detailed 
information about error codes.
    Caution: The error code in this program is in hexadecimal format.

=========
Caution 
=========
   1. When you write data to the Dog, changing the last 4 bytes of the 
Dog's memory will affect the MicroDog scrambled result.
   2. If you use MD or MF, the functions DogCheck() and DogConvert() require
DogPassword, and the functions DisableShare() and GetCurrentNo() are not functional.
   3. In this version, the modules do not have a cascade function, although 
CASCADE will be available in the future. So, it must be 0. If you need this 
function, please contact us.    

======================================
Frequently asked questions
======================================
    If your questions are not included in this section, please refer to 
the file Microdog.DOC in the root of the installation directory.

=================
Technical support
=================
    If you have any technical problems, please contact Rainbow China Co., Ltd., 
our branches, or our distributors.  Be prepared to provide us your software part 
number.  This will accelerate our help.
    The part number of DOS16DOG is GS-MH-D16-ASM 2.000.
    The last part of a part number is a version number, which can also be extracted
by using Utility/Getver.exe.   The two values should be same.  If not, refer to 
the result returned by Getver.exe  first.  The version information can be helpful
in pinpointing and solving problems.
    Please Refer to  /Address.txt for the contact address.



