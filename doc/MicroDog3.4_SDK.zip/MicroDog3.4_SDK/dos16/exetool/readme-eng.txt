	              -------------------------------------------------------
	                       MicroDog Suite 16-bit DOS Application
                                         Shell Utility Guide   
                     -------------------------------------------------------

                          Copyright (c) 2001, Rainbow China Co., Ltd.

      MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.      
    
  The RC-MH specified below has exactly the same functions of MicroDog Suite.
---------------------------------------------------------------------------

===============
Encryption tool
===============
    EXE.EXE of this folder is used to protect EXE/COM files of DOS Operating system. 
    The encryption tool regard program ( EXE/COM file ) to be a pool of data, 
which is then re-located according to certain algorithm to become an encrypted program.


==============
Using the tool
==============
    Running the protected .EXE file encrypted by this tool in DOS window of WINDOWS 9x, 
the driver "VGS.VXD" must be copied to WINDOWS 9x's SYSTEM folder. This tool can also be 
run under WINDOWS NT. 
    This tool is able to provide functions like trial period, shared usage, verification 
Dog read/write password, etc. 
    The parameters used by this tool are all inputted through command line. Usage is as 
the following:
    Type the command:
    	EXE [RETURN]
 	The usage of all parameters are shown. 

	syntax: EXE <Level>  -P[code]  -D[nnnnnnnn]  <InputFile>  <OutputFile>
Where:
	Level:  Must be 1 or 2, and must be the first parameter following EXE. 

    	-P[code]:    If the password of the Dog is 0, then this is optional. Otherwise, 
this item must be provided. The password inputted by the developer must be same with the 
pre-set password (Please refer the utility of DOGEDIT), Otherwise the program can not be 
run. If the developer does not set any password, and selects this option, please input 0
(the factory default is 0). 
Note:There shouldn't be any space between code and P, code is unsigned long type. 

        -N:  Disable share

      	-D[nnnnnnnn]:	Whether to use trial period option. nnnnnnnn is the trial period 
selected. Input method: YMD. Such as ,19980920 for Sept. 20, 1998.
Note:4 digits are required for year. Month requires two digits like 02, 05,11 for Feb., 
     May, and Nov.. Date is two digits. For example , 05,12,23 stands for the 5th ,12th 
     and 23rd day of a month. There shouldn't be any space between nnnnnnnn and -D.

	InputFile:   The program to be encrypted. 

      	OutputFile:  The encrypted program.                

    Example 1:EXE  1  MYEXE.EXE  SECEXE.EXE
Note:There is one or two options after EXE for the parameter. Please refer to  
     "Explanations" below. 

    Example 2:EXE  1  -D19990601  MYEXE.EXE  SECEXE.EXE
Note:During encryption, the developer will be prompted to input file name of TIME FILE, just
     input any file name you wish, please do not add any path, just a name without path, 
     without extension. 
     Please refer to the Item 2 in "Caution" section below. 

    Example 3:EXE  1  -P1999  -N  MYEXE.EXE  SECEXE.EXE
Note:-P1999 stands for that the encrypted software will verify whether the password in 
Dog hardware is 1999 during its starting. If not, the program will not run . This means that 
the password after -P should be the same with what was set in the Dog hardware. The password 
in the Dog can be changed with the tool DOGEDIT(in folder UTILITY).

Note: If the developer selected -D the trial period function as well as the -P option to verify 
the write/read password for the Dog, or select -N to forbid the sharing, the -P or -N function 
is not available during trial period. Only after trial period can they be taken effect. 


============
Explanations
============
    EXE commands must take parameter 1 or 2 when initializing. We recommend parameter 1 for 
most cases. Files encrypted with parameter 2 occupies more memory. But for some programs 
with self verification, self modification, override or large programs, if parameter 1 does 
not work, please choose parameter 2. 
    Some programs give error message when running in MS-DOS 6.0 above after encryption 
"Packed file corrupt", please use DOS external command LOADFIX to start the program. 
Such as: LOADFIX  MYEXE.

========================
Technical specifications
========================
        . Program size increase 50~60K after encryption
        . Needs 10~20K more memory when running 
        . Do not use any interruption

===========
Error Codes
===========
    Refer to ERRCODE.TXT in the root of the install directory for detailed 
information on error codes.


=======
Caution
=======
   1. The file to be encrypted should not have the same name with the encrypted file. 
Please use a temporary file name for the encrypted file, and then replace the file to be 
encrypted, or use different path or disks. 
      The encrypted file can not be restored to its original status. 
   2. If the tool is used for GS-MF MicroDog, the access password must be 0 when using the 
tool to encrypt program.
   3. If the trial period option is selected when encrypting several EXE or COM files, 
please enter different file name for time for each EXE/COM file. Only input the file name 
itself, without the path. This tool will automatically put these files under the root 
directory of drive C. If the developer used this option to release their encrypted software, 
please deliver this file to your end-users, and install it to the root directory of the 
end-user's drive C. 
 
=================
Technical Support
=================
    For technical issues, please contact Rainbow China Co., Ltd. or its distributors 
immediately. Please provide us with the parts-number of the software you are using. 
    The parts-number of this module is GS-MH-D16-SHELL 2.000.
    The last part of this if the version number. You can also use Utility/Getver.exe to 
get the version number of this software module, which should be the same with this. If 
variations exist, the result from Getver.exe is right for report. Version number helps 
us to troubleshoot the problem and provide the right solutions. 
    For contact address, please see Address.txt under installation path.


    
