 
                 -------------------------------------------------------
                              MicroDog Suite 16-bit DOS Application
                                 API Guide to BASCOM/Quick BASIC
                  -------------------------------------------------------

                        Copyright (c) 2001, Rainbow China Co., Ltd.
     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.       
    
  The RC-MH specified below has exactly the same functions of MicroDog Suite.
-------------------------------------------------------------------------------------------------
    This file demonstrates how to call C API by using  BASCOM/Quick BASIC language.


=========
Functions
=========
  MicroDog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, 
writing data into and reading data from the memory, changing data, checking the current 
manufacturing number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six basic functions specified above will secure your software products from any unauthorized
use. For detailed description of protection strategy, please read The Developer's Manual .
                 
=========
File list
=========
   File name             Description
   --------------        -----------------------------------------------------
   README-ENG.TXT        This file
   EXAM.BAS              Example program
   MAKE.BAT              Compiler batch file

====================
Testing Environments 
====================
   BASCOM 1.0, Quick Basic 4.0

================
API functions
================

1. API defines the following functions which can be used in the developer's program.
        DOGCHECK(RetCode%,Cascade%)                         Check dog
        READDOG(RetCode%,Cascade%,DogAddr%,DogBytes%,
            DogPasswordHigh%,DogPasswordHigh%, DogData)     Read dog
        WRITEDOG(RetCode%,Cascade%,DogAddr%,DogBytes%,
            DogPasswordHigh%,DogPasswordLow%, DogData)      Write dog
        DOGCONVERT(RetCode%,Cascade%,DogBytes%,
            DogResultHigh%,DogResultLow%, DogData)          Conversion
        GETCURRENTNO(RetCode%,Cascade%,CurrentNoHigh%,
            CurrentNoLow%)                                  Get ID number of the hardware Dog 
        DISABLESHARE(RetCode%,Cascade%)                     Disable share

2. Parameters introduction:
        RetCode%             Return value
        DogAddr%             Address in the hardware Dog's memory 
        DogBytes%            Length of transferred data
        DogPasswordHigh%     Hige word of Read/Write Password
        DogPasswordLow%      Low word of Read/Write Password
        DogResultHigh%       High word of the conversion result
        DogResultLow%        Low word of the conversion result
        DogData              I/O data pointer
        Cascade              Cascade Number
        CurrentNoHigh%       High word of the hardware ID number
        CurrentNoLow%        Low word of the hardware ID number



3. DOGCHECK(RetCode%,Cascade%)
   Input parameter:  Cascade
   Output parameter: None
   Return value: RetCode% is zero if successful; is an error code if the function fails.
   Function: Checks whether the hardware Dog  exists.  Only the hardware Dog  that has the same 
	 serial number as the OBJ file can be detected. 
   For example:  
	......
	60      Cascade% = 0      rem: Cascade number must be 0
	70      RetCode% = 1
	80      call DOGCHECK(RetCode%, Cascade%)
	90      if (RetCode% <> 0) then goto 120   rem: if the return value is not 0 
	100     print "DogCheck success!"
	110     goto 140
	120     print "DogCheck error ! Return code = ";RetCode%
	......
	......      

4. READDOG(RetCode%,Cascade%,DogAddr%,DogBytes%,DogPasswordHigh%,
           DogPasswordLow%, DogData)
   Input parameter: Cascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter: DogData
   Return value: RetCode% is zero if successful; is an error code if the function fails.
   Function: Reads data from the hardware Dog . The hardware Dog  contains a 200-byte nonvolatile 
         memory.  From the hardware Dog , ReadDog reads memory data from the beginning at the 
         address indicated by DogAddr.  The byte number of the read data is indicated 
         by DogBytes.  The read data will be stored in the space that DogData points to.
         hardware Dog  will verify the Dog's Password. Dog's Password is the password for
         read\write operations.  It is stored in the hardware Dog .  It can be set by 
         the utility tool or SetPassword() function. The application must ensure enough space 
         to buffer the data being read.  ReadDog will not check whether the size of the buffer
         is sufficient.
   Example 1:
          Read an integer from address 50 of hardware Dog  memory
      	......
	40      PasswordHigh% = 0
	50      PasswordLow% = 0
	60      Cascade% = 0        rem: Cascade number must be 0
	70      RetCode% = 1
        ......
	590     DogAddr% = 50
	600     DogBytes% = 2
	610     rInt% = 1000
	620     call READDOG(RetCode%, Cascade%, DogAddr%, DogBytes%, 
                PasswordHigh%, PasswordLow%, rInt%)
	630     if (RetCode% <> 0) then goto 660   rem: if the return value is not 0 
	640     print "Read integer from Dog is : ";rInt%
	650     goto 680
	660     print "Read integer from Dog error ! Return code = ";RetCode%
	......
	......
   Example 2:
          Read a string from address 70 of hardware Dog  memory
      	......
	40      PasswordHigh% = 0
	50      PasswordLow% = 0
	60      Cascade% = 0         rem: Cascade number must be 0
	70      RetCode% = 1
        ......
        770     DogAddr% = 70
	780     DogBytes% = 0
	790     ReadStr$ = "        "
	800     call READDOG(RetCode%, Cascade%, DogAddr%, DogBytes%, 
                PasswordHigh%, PasswordLow%, ReadStr$)
	810     if (RetCode% <> 0) then goto 840    rem: if the return value is not 0 
	820     print "Read string from Dog is : '";ReadStr$;"'"
	830     goto 860
	840     print "Read string from Dog error ! Return code = ";RetCode%
        ......
        ......
 

5. WRITEDOG(RetCode%,Cascade%,DogAddr%,DogBytes%,DogPasswordHigh%,
           DogPasswordLow%, DogData)
   Input parameter: Cascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter: None
   Return value: RetCode% is zero if successful; is an error code if the function fails.
   Function: Writes data to the hardware Dog . Carries out the same operation as ReadDog does
      except that the data flow direction is different.
   Example 1:
          Write an integer to address 50 of the hardware Dog  memory
      	......
	40      PasswordHigh% = 0
	50      PasswordLow% = 0
	60      Cascade% = 0             rem: Cascade number must be 0
	70      RetCode% = 1
        ......
	320     DogAddr% = 50
	330     DogBytes% = 2
	340     wInt% = 1234
	350     call WRITEDOG(RetCode%, Cascade%, DogAddr%, DogBytes%, PasswordHigh%,PasswordLow%, wInt%)
	360     if (RetCode% <> 0) then goto 390       rem: if the return value is not 0 
	370     print "Write integer ";wInt%;" to Dog success!"
	380     goto 410
	390     print "Write integer to Dog error ! Return code = ";RetCode%
        ......
	......
   Example 2:
          Write a string from address 70 of the hardware Dog  memory
      	......
	40      PasswordHigh% = 0
	50      PasswordLow% = 0
	60      Cascade% = 0          rem: Cascade number must be 0
	70      RetCode% = 1
        ......
        500     DogAddr% = 70
	510     DogBytes% = 0
	520     WriteStr$ = "MicroDog"
	530     call WRITEDOG(RetCode%, Cascade%, DogAddr%, DogBytes%, 
                PasswordHigh%, PasswordLow%, WriteStr$)
	540     if (RetCode% <> 0) then goto 570    rem: if the return value is not 0 
	550     print "Write string '";WriteStr$;"' to Dog success !"
	560     goto 590
	570     print "Write string to Dog error ! Return code = ";RetCode%
        ......
        ......


6. DOGCONVERT(RetCode%,Cascade%,DogBytes%,DogResultHigh%, 
              DogResultLow%,DogData)

   Input parameter: Cascade, DogBytes, DogData
   Output parameter: DogResult
   Return value: RetCode% is zero if successful; is an error code if the function fails.
   Function: Transfers data to hardware Dog .  The hardware Dog  scrambles the data and 
       returns the scrambled result Dogresult as a 32-bit integer.  DogBytes indicates
       the number of bytes of the date, which DogData points to, being converted. 
       The conversion algorithm can be specified by the developer.  The last 4 bytes 
       of the memory will affect the conversion algorithm.  The 196th byte is used to 
       specify the algorithm.  Therefore, the developer can define 256 kinds of algorithms. 
       The algorithm descriptor is made up of 197th,198th and 199th byte, so in total it 
       may have 16,777,215 different combinations.
   Example:
       	 Convert teh string "Micro Dog GS-MH"  
	......
	60      Cascade% = 0       rem: Cascade number must be 0
	70      RetCode% = 1
        ......
	210     CvtStr$ = "Micro Dog GS-MH"
	220     DogBytes% = 0
	230     ResultHigh% = 0
	240     ResultLow% = 0
	250     call DOGCONVERT(RetCode%, Cascade%, DogBytes%, DogResultHigh%, 
                DogResultLow%, CvtStr$)
	260     if (RetCode% <> 0) then goto 300    rem: if the return value is not 0 
	270     print "DogConvert success !"
	280     print "ResultHigh = "; DogResultHigh%; "   ResultLow = "; DogResultLow%
	290     goto 320
	300     print "DogConvert error ! Return code = ";RetCode%
        ......
        ......

7. DISABLESHARE(RetCode%,Cascade%)
   Input parameter: Cascade
   Output parameter: None
   Return value: RetCode% is zero if successful; is an error code if the function fails.
   Function: Disable the hardware Dog 's sharing ability.
         The parallel port hub is a kind of hardware share device that allows multiple 
         copies of the protected program share the same hardware Dog . 
         Factory setting for share ability is Enable. You may call DisableShare function to 
         to prevent pirates from using a parallel port hub. So that only the machine that 
         has the hardware Dog  can run the protected program.  
         DisableShare only affects the functions ReadDog, WriteDog and DogConvert. 

* Caution:
         Do not call on this function multiple times. It is designed to be called no more
         than once in an application.

   Example:
	......
	60      Cascade% = 0      rem: Cascade number must be 0
	70      RetCode% = 1
        ......
	150     call DISABLESHARE(RetCode%, Cascade%)
	160     if (RetCode% <> 0) then goto 190   rem: if the return value is not 0 
	170     print "DisableShare success!"
	180     goto 200
	190     print "DisableShare error ! Return code = ";RetCode%
        ......
        ......

8. GETCURRENTNO(RetCode%,Cascade%,CurrentNoHigh%, CurrentNoLow%)	
   Input Parameter: Cascade, DogData
   Output parameter: DogData
   Return value: RetCode% is zero if successful; is an error code if the function fails.
   Function: Reads the Manufacturing code of the hardware Dog.Some of the hardware
             Dogs may have the same ID, but every hardware Dog has its unique
             Manufacturing code. The Manufacturing code can help developers manage
             user accounts.
             The Manufacturing code is 4 bytes.

   Example:
	......
	60      Cascade% = 0      rem: Cascade number must be 0
	70      RetCode% = 1
        ......
	860     CurrentNoHigh% = 0
	870     CurrentNoLow% = 0
	880     call GETCURRENTNO(RetCode%, Cascade%, CurrentNoHigh%, CurrentNoLow%)
	890     if (RetCode% <> 0) then goto 930      rem: if the return value is not 0 
	900     print "Current No (high) is : "; CurrentNoHigh%
	910     print "Current No (low)  is : "; CurrentNoLow%
	920     goto 950
	930     print "GetCurrentNo error ! Return code = "; RetCode%
        ......
        ......
  
========================
  Compatibility with MF
========================
   MF can use all of the function above except DOGCHECK() and DOGCONVERT().
   We provide two functions especially for MF in BCOMDOG.OBJ (to replace the two
   functions above).

1. MFDOGCHECK(PasswordLow%,RetCode%,Cascade%)
   Input parameter: PasswordLow, Cascade
   Output parameter: None
   Return value: RetCode% is zero if successful; is an error code if the function fails.
   Fuction: Checks whether the hardware Dog  exists. Only the hardware Dog  that has the same 
       serial number as the OBJ can be detected. Cascade has no effect on MF, 
       PasswordLow is the read/write password for MF Dog.

2. MFDOGCONVERT(PasswordLow%, RetCode%,Cascade%,DogBytes%,DogResultHigh%, 
              DogResultLow%,DogData)

   Input parameter: PasswordLow, Cascade, DogBytes, DogData
   Output parameter: DogResult
   Return value: RetCode% is zero if successful; is an error code if the function fails.
   Function: Transfers data to hardware Dog .  The hardware Dog  scrambles the data, 
       and returns the scrambled result Dogresult as a 32-bit integer.  DogBytes indicates
       the number of bytes of the date, which DogData points to, being converted. 
       The conversion algorithm can be specified by the developer. Cascade has no effect 
       on MF.  PasswordLow is the read/write password for MF dog.

   The MF  hardware Dog  does not provide its hardware ID number and share-preventing function, 
so the functions DISABLESHARE and GETCURRENT have no effect.


===============
  Error Codes
===============
    Refer to ERRCODE.TXT in the root of the install directory for detailed 
information on error codes.
   Caution: The error code in this program is in hexadecimal format.



================================================
Compiling and running of the example program 
================================================
    This example has been tested under Bascom 1.0 and Quick Basic 4.0. The 
batch file used to compile the program is MAKE.BAT.  You should use 
DOS16\BASCOM\BCOMDOG.OBJ for linking.
    How to use make: "make filename"
For example: "make exam"
    File make.bat has a command line: SET BASPATH=C:\BASCOM. If your BASCOM 
or Quick Basic is in another directory, please modify this line.

========
Cautions 
========
     In this version, the modules do not have a cascade function, although 
CASCADE will be available in the future. So, it must be 0. If you need this 
function, please contact us.    
 
======================================
Frequently asked questions and answers
======================================
    If your questions are not included in this section, please refer to 
the file umh3.chm in the root of the installation directory.

Question: Why does the exe file that I compiled not run, and why does it keep reading 
          the floppy disk?
Answer:   The exe file compiled by Bascom needs a file called basrun.exe.  This file
          should be in the installation directory or in the installation disk.

=================
Technical support
=================
    If you have any technical problems, please contact Rainbow China Co., Ltd., 
our branches, or our distributors.  Be prepared to provide us your software part 
number.  This will accelerate our help.
    The part number of BCOMDOG.OBJ is GS-MH-D16-BASCOM 2.000.
    The last part of a part number is a version number, which can also be extracted
by using Utility/Getver.exe.   The two values should be same.  If not, refer to 
the result returned by Getver.exe  first.  The version information can be helpful
in pinpointing and solving problems.
    Please Refer to  /Address.txt for the contact address.

