
                  -------------------------------------------------------
	                MicroDog Suite for 16-bit MS-DOS Application                                    
                  -------------------------------------------------------

                        Copyright (c) 2001, Rainbow China Co., Ltd.
  
     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.      
    
  The RC-MH specified below has exactly the same functions of MicroDog Suite.
 
  =========
  File List
  =========
  There are following folders and files in DOS16 folder:

  DOS16
    |- README-ENG.TXT      This file.
    |
    |- ASM        <dir>  - A sample program using the ASM language to call C module.
    |
    |- C          <dir>  - API & demo program for 16-bit DOS C/C++ compiler. Please refer to Readme.txt and 
    |                      demo program in this directory for detailed information about API functions.  
    |
    |- TRUEBAS    <dir>  - API & demo program for Ture BASIC compiler. Please refer to Readme.txt and 
    |                      demo program in this directory for detailed information about API functions.  
    |
    |- FORTRAN    <dir>  - API & demo program for 16-bit FORTRAN compiler. Please refer to Readme.txt and 
    |                       demo program in this directory for detailed information about API functions.  
    |
    |- CLIPPER    <dir>  - API & demo program for Clipper For DOS. Please refer to Readme.txt and
    |                      demo program in this directory for detailed information about API functions.  
    |
    |- FOXPRO2 0  <dir>  - API & demo program for Foxpro 2.0 For DOS compiler. Please refer to Readme.txt and 
    |                      demo program in this directory for detailed information about API functions.
    |
    |
    |- FOXPRO2 5  <dir>  - API & demo program for the Foxpro 2.5/2.6 For DOS compiler. Please refer to Readme.txt
    |                      and demo program in this directory for detailed information about API functions.  
    |
    |- PASCAL     <dir>  - API & demo program for Turbo PASCAL For DOS compiler. Please refer to Readme.txt and 
    |                      demo program in this directory for detailed information about API functions.  
    |
    |- EXETOOL    <dir>  - Protection tool used to protect EXE files running under DOS directly. Please refer
    |                      to Readme.txt and demo program in this directory for detailed information about using methods.  
    |
    |- BASCOM     <dir>  - API & demo program for BASCOM compiler. Please refer to Readme.txt and demo 
    |                      program in this directory for detailed information about API functions.  
    |
    |- QBASIC     <dir>  - API & demo program for Quick BASIC compiler for DOS. Please refer to Readme.txt and
    |                      demo program in this directory for detailed information about API functions.  
    |
    |- PROTECTC   <dir>  - API & demo program 16-bit BORLAND C++ 4.5 compiler in protection mode. Please refer
    |                      to Readme.txt and demo program in this directory for detailed information about API functions.  
    |                           
    |- FOXTOOL    <dir>  - Protection tool suitable for FOXPRO For DOS application. Please refer to Readme.txt 
                           and demo program in this directory for detailed information about using methods.  


    
