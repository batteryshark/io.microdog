/************************************************************************
  This example program is demonstrated how to use the API of GS-MH
  MicroDog.

  The suitable compiler range:

     Turbo C 2.0 for DOS,
     Borland C&C++3.1 for DOS,
     Visual C++ 1.51

  Compile method:
     Project:   SetPass.C  DosSetPs.Obj
     Mode:      large

  (c)Copyright  Rainbow Goldensoft Co.,Ltd. 2000.
************************************************************************/

#include "stdio.h"

extern unsigned long far SetPassword(void);

/************************************************************************
  The globle variable Cascade indicates the cascade serial .
************************************************************************/
unsigned char Cascade;

/************************************************************************
  The globle variable DogPassword indicates the old password of the Dog;
  The globle variable NewPassword indicates the new password of the Dog;
************************************************************************/
unsigned long DogPassword;
unsigned long NewPassword;

int main()
{
/************************************************************************
  The following variables including its names and contents may be defined
by user himself.
************************************************************************/

	unsigned long retCode;

	Cascade = 0;         // Assume the Dog is the first cascaded one.

	printf("\nPlease input the old password: ");
	scanf("%ld", &DogPassword);

	NewPassword = DogPassword;

	retCode = SetPassword();

	if(retCode)
	{
		printf("\nWrong password, or no dog found. Return code: %ld\n", retCode);
		return 1;
	}

	printf("\nPlease input the new password: ");
	scanf("%ld", &NewPassword);

	retCode = SetPassword();

	if(retCode)
	{
		printf("\nCannot change password. Return code %ld\n", retCode);
		return 2;
	}
	else
		printf("\nPassword changed successful.\n");

	return 0;
}
