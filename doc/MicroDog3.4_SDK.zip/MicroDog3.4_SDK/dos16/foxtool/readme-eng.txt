                   -------------------------------------------------------
                             MicroDog Suite 16-bit DOS Application
                                        FOXBASE Utility Guide 
                   -------------------------------------------------------

                        Copyright (c) 2001, Rainbow China Co., Ltd.

        MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.         

    
  The RC-MH specified below has exactly the same functions of MicroDog Suite.

-------------------------------------------------------------------------------------------------

========================
Intruduction to the tool
========================
    There is a special encryption tool FOX.EXE for protecting .PRG/.FOX/.FXP/.APP 
applications and Database files (.DBF) of DBASE/FOXBASE/FOXPRO for DOS in the folder. 
    You should first encrypt all your applications (.PRG/.FOX/.FXP/.APP files) and 
Database (.DBF) by using the tool, then modify the explanation program of 
DABSE/FOXBASE/FOXPRO (that's to say you should modify DBASE.EXE/MFOXPLUS.EXE/FOXR.EXE) 
by using the tool in order to let these programs recognize the encrypted applications 
and Database files. So encrypted applications/Database and encrypted explanation 
programs are working together, protection effect is reached.

    The encryption tool FOX.EXE in the folder regards these application files and 
Database files to be a pool of data, which is then re-located according to certain 
algorithm to become an encrypted applications and Database. 


==============
Using the tool
==============
    Running the protected file encrypted by this tool in DOS window of WINDOWS 9x, 
the driver "VGS.VXD" in "DRIVER" folder must be copied to WINDOWS 9x's SYSTEM folder. 
    This tool is able to provide functions like trial period, shared usage, verification 
Dog read/write password, etc. 
    The parameters used by this tool are all inputted through command line. Usage is as 
the following:
    Type the command:
    	FOX [RETURN]
 	The usage of all parameters are shown. 

	syntax: FOX <P|F|X|A|D> -P[code] -N <InputFile>  <OutputFile>

Where:
	<P|F|X|A|D>:  These five parameters only be used when modify explanation programs 
                      (MFOXPLUS.EXE, DBASE.EXE, FOXR.EXE).
           P -- means modified explanation program can recognize encrypted applications 
                with .PRG extension.
           F -- means modified explanation program can recognize encrypted applications 
                with .FOX extension.
           X -- means modified explanation program can recognize encrypted applications 
                with .FXP extension.
           A -- means modified explanation program can recognize encrypted applications 
                with .APP extension.
           D -- means modified explanation program can recognize encrypted Database files 
                with .DBF extension.
           Note: P, F, X are default parameters. Please do not leave space between these 
                 parameters when you use more than one parameter, and these parameters should 
                 be the first parameter after FOX in the line.

    	-P[code]:  If the password of the Dog is 0, then this is optional. Otherwise, 
                   this item must be provided. The password inputted by the developer must 
                   be same with the pre-set password (Please refer the utility of DOGEDIT), 
                   Otherwise the program can not be run. If the developer does not set any 
                   password, and selects this option, please input 0 (the factory setting is 0). 
           Note:There shouldn't be any space between code and P, code is unsigned long type. 

        -N:  Disable share

	InputFile:   The file to be encrypted. 

      	OutputFile:  The encrypted file.                

Remarks:
1) Output file name should not be same with the original file name when you modify
   the explanation programs. 

2) If your application consists of a lot of files with .PRG/.FOX/.FXP/.APP extension, 
   all these files should be encrypted.

3) If your database consists of a lot of files with .DBF extension, all these files 
   should be encrypted.

4) Please modify FOXR.EXE instead of FOX.EXE for FOXPRO environment.

5) If your application programs consist of a lot of .PRG files, each is called by Do 
   command, you should not specify different names with original but different path.

--------
Examples
--------
    Example 1: There is a application program A.PRG running at MFOXPLUS.EXE

       Step 1: Use the tool FOX.EXE to modify MFOXPLUS.EXE, OutputFile is MF.EXE
       Syntax: FOX P MFOXPLUS.EXE MF.EXE
       Note: If MF.EXE will use other encrypted application programs, you should add other 
             parameter(s) to meet this requirement.

       Step 2: Use the tool FOX.EXE to encrypt A.PRG, OutputFile is B.PRG.
       Syntax: FOX A.PRG B.PRG
       Note: Parameters have no meaning when encrypting application programs and database. 
             Then you should not provide the parameters.

       Step 3: Copy MF.EXE, MFOXPLUS.OVL and other necessary files to a certain directory, 
               then execute :
               MF B.PRG
               You will get all functions in A.PRG but B.PRG is a protected application.

    Example 2: There is a application program A.FXP for FOXPRO 2.5. The requirement is to 
               verify access password in the hardware Dog  must be 1234.

       Step 1: Use the tool FOX.EXE to modify FOXR.EXE, OutputFile is FOXR1.EXE
       Syntax: FOX F FOXR.EXE FOXR1.EXE

       Step 2: Use the tool FOX.EXE to encrypt A.FXP, OutputFile is B.FXP.
       Syntax: FOX A.FXP B.FXP

       Step 3: Copy FOXR1.EXE and other necessary files to a certain directory, 
               then execute :
               FOXR1 B.FXP
               You will get all functions in A.FXP but B.FXP is a protected application.

========================
Technical specifications
========================
        * Explanation Program size increases 6K after modification
        * Do not use any interruption
        * The tool is suitable for DBASE 3, FOXBASE, FOXPRO 2.0, FOXPRO 2.5 and 2.6
	* Some software consists of several source program, and the programs are calling 
with DO each other. In the conditions, encrypted program name must be the same as the program 
name, but they can be in the different directory.
============
About Foxpro
============
   To convert PRG file into FXP file, following process:
   A. Starup FOXPRO.EXE.
   B. Running PRG file,and then making cognominal FXP file.  
   C. Encrypting FOXR.EXE file and FXP file by using the encryption tool FOX.EXE.

===========
Error Codes
===========
	See errcode.txt under installation path.
         
=======
Caution
=======
    1. If the tool is used for GS-MF MicroDog, the access password must be 0 when using the 
tool to encrypt program.
    2. If the tool is used for GS-MF MicroDog, the parameter -N has no meaning when using the 
tool to encrypt program.

======================================
Frequently asked questions and answers
======================================
    If your questions are not included in this section, please refer to 
the file Microdog.DOC in the root of the installation directory.
1. Question: Whether may you provide your end-user protected database and unprotected 
             database?
   Answer:   Yes.
   Method: 1) The protected database files use .DBF extension, unprotected 
              database files use other extension such as .DDD.
           2) When you modify explanation programs, use D parameter.
           3) When you open unprotected database files in your source program
              please use the full name with .DDD extension, like: 
              USE B.DDD
           4) When you open protected database files in your source program
              please use basic name with no extension, like: 
              USE A

2. Question: My application program is EXE file written by FOXPRO, can I use the tool to 
             protect my application program?
   Answer:   No.
             This tool can not prevent from uncompiling your program.
	     Please use another tool EXETOOL.EXE with parameter 2, which is located at 
	     the folder \dos16\EXETOOL to protect your application.

3. Question: My application program is EXE file written by FOXPRO, can I use the tool to 
  	     protect database file.
   Answer:   Yes.
   Method: 1) Modify your EXE file by using the tool with parameter D.
           2) Encrypt your database files with the tool.
           3) Protect your modified EXE file by using \dos16\exetool\EXETOOL.EXE
              tool with parameter 2 to prevent from uncompiling your EXE file to 
              .PRG files.

=================
Technical Support
=================
    For technical issues, please contact Rainbow China Co., Ltd. or its distributors 
immediately. Please provide us with the parts-number of the software you are using. 
    The parts-number of this module is GS-MH-D16-FOXPRO 2.000.
    The last part of this if the version number. You can also use Utility/Getver.exe to 
get the version number of this software module, which should be the same with this. If 
variations exist, the result from Getver.exe is right for report. Version number helps 
us to troubleshoot the problem and provide the right solutions. 
    For contact address, please see Address.txt under installation path.

