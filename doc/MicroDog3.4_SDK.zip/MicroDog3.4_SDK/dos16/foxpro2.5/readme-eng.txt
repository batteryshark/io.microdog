                  -------------------------------------------------------
                            MicroDog Suite 16-bit DOS Application
                                  API Guide to FOXPRO 2.5/2.6
                -------------------------------------------------------

                        Copyright (c) 2001, Rainbow China Co., Ltd.

         MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.    
    
  The RC-MH specified below has exactly the same functions of MicroDog Suite.

-------------------------------------------------------------------------------------------------
    This file demonstrates how to call C API by using FOXPRO 2.5/2.6 language.


=========
Functions
=========
  MicroDog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, 
writing data into and reading data from the memory, changing data, checking the current 
manufacturing number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six basic functions specified above will secure your software products from any unauthorized
use. For detailed description of protection strategy, please read The Developer's Manual .

=========
File list
=========
   File name             Description
   --------------        -----------------------------------------------------
   README-ENG.TXT        This file
   FOXDOG25.PLB          API OBJ file
   EXAM.PRG              Demo program

==================
Tested Environment
==================
    Foxpro 2.5 / 2.6 for DOS

================
API Introduction 
================

1. API define the following functions which can be used in the developer's program.
   DogCheck(Cascade)	
   ReadDog(Cascade, DogAddr, DogData, DogPassword[, DogBytes])
   WriteDog(Cascade, DogAddr,, DogData, DogPassword[, DogBytes])
   DogConvert(Cascade, DogData, @DogResult)
   GetCN(Cascade, @DogData)
   DisShare(Cascade)

2. Meanwhile, Developer should define following variables:
      DogAddr, DogBytes, Cascade, DogPassword, DogResult, DogData

   Explanation for variables
   -------------------------
     a. DogAddr:  Indicates the start address (0~199) of Dog internal 
                  user area during read operation. The sum of adding DogAddr with 
                  DogBytes will not be allowed to be over 200.

     b. DogBytes: Byte number of read operation (1~200) or conversion operation 
                  (1~63). In read operation, The sum of adding DogAddr with DogBytes 
                  will not be allowed to be over 200.

     c. DogPassword: Access password. The factory setting in the hardware Dog  is 
                     0, it may be changed by DOGEDIT.EXE in UTILITY folder. It 
                     will only take effect for the functions of ReadDog and WriteDog, 
                     not for DogCheck and DogConvert.

     d. DogResult: Result after conversion. Function DogConvertT will put the 
                   converted result into this variable. Be careful, if the 
                   operation of DogConvert fails, the original DogResult value will 
                   not be changed. 

     e. Cascade: Reserved parameter for cascade capability, it should be 0 in 
                 this version.

     f. DogData: Buffer of read/write/conversion operation. 

3. DogCheck(Cascade)
   Input parameter:  Cascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Fuction: Checks whether the hardware Dog  exists. Only the hardware Dog  that has the same 
	 serial number as the OBJ file can be detected.  In this version, the modules don't 
         have a cascade function, and the parameter CASCADE will be used in the future, so it
         must be 0 now. If need this function, please contact us.    

   Example:
        ......
        ......
        Cascade = 0      && Cascade must be 0 in this version
        RetCode = 0
        RetCode = DogCheck(Cascade)
        if RetCode = 0   && If returen value is not 0
           ?"The MicroDog is Present"
        else                 
           ?"The MicroDog is Absent, ErrorCode is: ", RetCode
        endif

4. ReadDog(Cascade, DogAddr, DogData, DogPassword[, DogBytes])
   Input parameter: Cascade, DogAddr, DogData, DogPassword [, DogBytes]
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads data from the hardware Dog . The hardware Dog  contains a 200-byte nonvolatile 
         memory.  From the hardware Dog , ReadDog reads data from the memory beginning at the 
         address indicated by DogAddr.  The byte number of the read data is indicated 
         by DogBytes.  The read data will be stored in the space that DogData points to.
         The Dog will verify the DogPassword. DogPassword is the password for the
         read\write operations.  It is stored in the hardware Dog .  It can be set by 
         the utility tool or the SetPassword() function. Applications must secure enough
         space to buffer the data being read.  ReadDog will not check whether the size of
         a buffer is sufficient.

   Example:
        ......
        ......
        Cascade = 0      && Cascade must be 0 in this version
        RetCode = 0   
        string = "12345678"
        DogAddr = 10     && Beginning address is 10
        DogPassword = 0  && Password of the hardware Dog  is 0 
        * Factory setting of password is 0, you may change it by the tool DOGEDIT.EXE (in 
        * UTILITY folder).
        RetCode = ReadDog(Cascade,DogAddr,@string,DogPassword)
        if RetCode <> 0  && if return value is not 0 
           ? "Read Dog Error! RetCode = ", RetCode
        else
           ? "Read ",string," from MicroDog."
        endif

5. WriteDog(Cascade, DogAddr,, DogData, DogPassword[, DogBytes])
   Input parameter: Cascade, DogAddr,, DogData, DogPassword[, DogBytes]
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Writes data to the hardware Dog . Carries out the same operation as ReadDog does
      except the data flow direction is different.

    Example: 
       ......
       ......
       Cascade = 0       && Cascade must be 0 in this version
       RetCode = 0   
       string = "MicroDog"
       DogAddr = 10      && Beginning address is 10
       DogPassword = 0   && Password of the hardware Dog  is 0 
        * Factory setting of password is 0, you may change it by the tool DOGEDIT.EXE (in 
        * UTILITY folder).
       RetCode = WriteDog(Cascade,DogAddr,string,DogPassword)
       if RetCode <> 0   && if return value is not 0
          ? "Write Dog Error! RetCode = ", RetCode
       else
          ? "Write string 'MicroDog' into MicroDog."
       endif

6. DogConvert(Cascade, DogData, @DogResult)
   Input parameter: Cascade, DogData
   Output parameter: DogResult
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Transfers data to Dog.  Then the hardware Dog  scrambles the data, 
       and returns the scrambled result Dogresult as a 32-bit integer.  DogBytes indicates
       the number of bytes of the data, which DogData points to, being converted. 
       The conversion algorithm can be specified by the developer.  The last 4 bytes 
       of the memory will affect the conversion algorithm.  The 196th byte is used to 
       specify the algorithm.  Therefore, the developer can define 256 kinds of algorithms. 
       The algorithm descriptor is made up of the 197th,198th and 199th byte, so it 
       may have a total of 16,777,215 different combinations.
  Note: You must define variable DogResult before calling the function.

   Example:
       ......
       ......
       Cascade = 0        && Cascade must be 0 in this version
       DogResult = 0
       RetCode = DogConvert(Cascade, 1234, @DogResult)
           ? "The integer data 1234 is translated into: ", DogResult
           ? "Return code is ", RetCode

7. DisShare(Cascade)
   Input parameter: Cascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Disable the hardware Dog 's sharing ability.
         The parallel port hub is a kind of hardware share device that allows multiple 
         copies of the protected program share the same hardware Dog . 
         Factory setting for share ability is Enable. You may call DisableShare function to 
         to prevent pirates from using a parallel port hub. So that only the machine that 
         has the hardware Dog  can run the protected program.  
         DisableShare only affects the functions ReadDog, WriteDog and DogConvert. 

* Caution:
         Do not call on this function multiple times. It is designed to be called no more
         than once in an application.

      Example:
       ......
       ......
       Cascade = 0        && Cascade must be 0 in this version
       RetCode = DisShare(Cascade)
       if RetCode = 0     && if return value is 0
          ?"The MicroDog Disable Share"
       else                 
          ?"The MicroDog Disable Share Fail, ErrorCode is: ", RetCode
       endif

8. GetCN(Cascade, @DogData)	
   Input Parameter: Cascade, DogData
   Output parameter: DogData
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads the Manufacturing code of the hardware Dog.Some of the hardware
             Dogs may have the same ID, but every hardware Dog has its unique
             Manufacturing code. The Manufacturing code can help developers manage
             user accounts.
             The Manufacturing code is 4 bytes.

      Example:
       ......
       ......
       Cascade = 0        && Cascade must be 0 in this version
       RetCode = 0   
       number = 0
       RetCode = GetCN(Cascade,@number)
       if RetCode = 0     && if return value is 0
          ?"The MicroDog Current Number", number
       else                 
          ?"The MicroDog Get Current Number Fail, ErrorCode is: ", RetCode
       endif

================================================
Compiling and running of the example program 
================================================
    This example has been tested under Foxpro 2.5 and Foxpro 2.6.

============
 Error code
============
    Refer to ERRCODE.TXT on the root of the installation directory for detailed 
information about error codes.

=========
Cautions 
=========
    1. When you write data to the hardware Dog , changing the last 4 bytes of the 
Dog's memory will affect the result of the function DogConvert().
    2. The API module also can be used for GS-MD/MF MicroDog, but can not use new features 
of GS-MH.
    3. If you use GS-MD/MF MicroDog, the functions DogCheck() and DogConvert() require
DogPassword, and the functions DisableShare() and GetCurrentNo() are not functional.
    4. In this version, the modules do not have a cascade function, although 
CASCADE will be available in the future. So, it must be 0. If you need this 
function, please contact us.    
    5. To increase protection intensity, we strongly recommend you that after using API 
protection, building a protected EXE file, you should use our SHELL encryption 
tool with parameter 2 (the tool is in DOS16\EXETOOL directory) to protect the EXE 
file further and to prevent from uncompiling the EXE file to .Prg source programs.


=================
Technical support
=================
    If you have any technical problems, please contact Rainbow Goldensoft Ltd., our
branches or our distributors.Be prepared to provide us your software part number.
This will accelerate our help.
    The part number of FOXDOG25.PLB is GS-MH-D16RINTF 2.000.
    The last part of a part number is a version number, which can also be extracted
by using Utility/Getver.exe.   The two values should be same.  If not, refer to 
the result returned by Getver.exe  first.  The version information can be helpful
in pinpointing and solving problems.
    Please Refer to  /Address.txt for the contact address.


