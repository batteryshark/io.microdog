                    -------------------------------------------------------
                                MicroDog Suite 16-bit DOS Application
                                       API Guide to CLIPPER
                     -------------------------------------------------------

                        Copyright (c) 2001, Rainbow China Co., Ltd.

     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.     
    
  The RC-MH specified below has exactly the same functions of MicroDog Suite.

-------------------------------------------------------------------------------------------------
    This file demonstrates how to call C API by using CLIPPER language.


=========
Functions
=========
  MicroDog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, 
writing data into and reading data from the memory, changing data, checking the current 
manufacturing number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six basic functions specified above will secure your software products from any unauthorized
use. For detailed description of protection strategy, please read The Developer's Manual .

=========
File list
=========
   File name             Description
   --------------        -----------------------------------------------------
   README-ENG.TXT        This file
   DOGDEMO.PRG           Example program
   MAKE.BAT              Batch program for compiling demo program by using Clipper 
                         Summer 87'
   MAKE5.BAT             Batch program for compiling demo program by using Clipper 5.2 
   MHCLP.OBJ             API OBJ file

====================
Testing Environments 
====================
  Clipper Summer 87'
  CA Clipper 5.2

================
API Intruduction
================

1. APIs define the following functions which can be used in the developer's program.
     function name     Description
     -------------     ------------------------
     DogCheck()        Check the hardware Dog
     ReadDog()         Read data from the hardware Dog
     WriteDog()        Write data to the hardware Dog
     DogConvert()      Convert a string into a 32-bit integer
     GetCurNo()        Get the ID number
     ShareDis()        Disable share
     GetRetCode()      Get function's return value 

  
2. RetCode = DogCheck(Cascade)

   Input parameter:  Cascade
   Return value: Returns zero if successful; returns an error code if the function fails.
   Fuction: Checks whether the hardware Dog exists. Only the Dog that has the same serial
            number as the OBJ file can be detected.  
            In this version, the modules don't have a cascade function, and the parameter 
            CASCADE will be used in the future, so it must be 0 now. If you need this 
            function, please contact us.    

   Remark:  The explanation for parameter Cascade should have same meaning for ALL 
            following functions.

   Example:
     ......
     ......
     Cascade = 0     && Cascade must be 0 in this version 
     retcode = 0
     retcode=DogCheck(Cascade)
     if (retcode=0)   && If return value is 0 
       ? '  dog check succeeded.'
     else
       ? '  dog check failed, error=',retcode
     endif
     ......
     ......

3. RetValue = ReadDog(Cascade,DogAddr,DogPassword,DogData)

   Input parameter: Cascade, DogAddr, DogPassword, DogData
   Output parameter: DogData
   Return value: 1) When DogData is pointing a string's address, returns zero if 
                    successful; returns an error code if the function fails.
                 2) When DogData=1/2/3, and GetRetCode() returns 0, the return value of the 
                    function is the data you want to read from the Dog.
   Function: Reads data from the hardware Dog. The Dog contains a 200-byte nonvolatile 
         memory.  From the Dog, ReadDog reads data from the memory beginning at the 
         address indicated by DogAddr. The length and the type of reading data should be 
         defined by DogData, please refer following explanation. 
         The MicroDog will verify the DogPassword. DogPassword is the password for the
         read/write operations.  It is stored in the hardware Dog.  It can be set by 
         DOGEDIT.EXE in UTILITY folder. 

   a. When DogData is pointing a string's address, ReadDog function checks the reserved 
      space of the string, and put data from the Dog into the space.

     Example:
     ......
     ......
     Cascade=0
     Passwd = 0   && The password is 0
     * Factory set value of password is 0, you may change the password by using DOGEDIT.EXE
     * in the UTILITY folder.
     DogData = "12345"  && DogData points a string's address
     Addr = 0           && Address is 0 
     retcode=ReadDog(Cascade,Addr,Passwd,DogData)
     if (retcode=0)     && Success when retcode=0
        ? '  read string success and the string is:',DogData
     else
        ? '  read string failed, error=',retcode
     endif

   b. When DogData equals 1, ReadDog will read 4 bytes from the hardware Dog with 
      beginning address DogAddr, and ReadDog returns a long integer with this 4 bytes.
        (-2147483648 < RetValue < 2147483647)

     Example:
     ......
     ......
     Cascade=0
     Passwd = 0   && The password is 0
     * Factory set value of password is 0, you may change the password by using DOGEDIT.EXE
     * in the UTILITY folder.
     DogData = 1         && DogData equals 1, ReadDog will return a long integer
     Addr = 30           && Beginning address is 30 
     longR = ReadDog(Cascade,Addr,Passwd,DogData)
     retcode=GetRetCode()
     if (retcode=0)      && Success when retcode=0
       ? '  read long succeeded and the long data is:',longR
     else
       ? '  read long failed, error=',retcode
     endif

   c. When DogData equals 2, ReadDog will read 2 bytes from the hardware Dog with 
      beginning address DogAddr, and ReadDog returns a boolean data with this 2 bytes.
        ( RetValue = .T. or RetValue = .F.   )

     Example:
     ......
     ......
     Cascade=0
     Passwd = 0   && The password is 0
     * Factory set value of password is 0, you may change the password by using DOGEDIT.EXE
     * in the UTILITY folder.
     DogData = 2        && DogData equals 2, ReadDog will return a boolean data
     Addr = 20          && Beginning addressis 20 
     logicR = ReadDog(Cascade,Addr,Passwd,DogData)
     retcode=GetRetCode()
     if (retcode=0)     && Success when retcode=0
       ? '  read logic succeeded, and the logic data is:',logicR
     else
       ? '  read logic failed, error=',retcode
     endif

   d. When DogData equals 3, ReadDog will read 8 bytes from the hardware Dog with 
      beginning address DogAddr, and ReadDog returns a date data with this 8 bytes.
        ( RetValue = 08/02/98 etc.  )

     Example:
     ......
     ......
     Cascade=0
     Passwd = 0   && The password is 0
     * Factory set value of password is 0, you may change the password by using DOGEDIT.EXE
     * in the UTILITY folder.
     Addr = 10          && Beginning addressis 10 
     DogData = 3        && DogData equals 3, ReadDog will return a date data
     dateR = ReadDog(Cascade,Addr,Passwd,DogData)
     retcode=GetRetCode()
     if (retcode=0)     && Success when retcode=0
        ? '  read date succeeded, and date is:',dateR
     else
        ? '  read date failed, error=',retcode
     endif

Remarks:
1) The developer should call GetRetCode() function immediately after calling ReadDog().
   The return value of ReadDog() is valid only when GetRetCode() returns 0 (means success).

2) ReadDog() will fail if ShareDis() has been already called and share has been detected. 


4. RetCode = WriteDog((Cascade,DogAddr,DogPassword,DogData)

   Input parameter: Cascade, DogAddr, DogPassword, DogData
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Writes data to the hardware Dog. Carries out the same operation as ReadDog does
      except the data flow direction is different.

   a. When DogData is pointing a string's address, WriteDog function checks the  
      space of the string, and put the string into the Dog. 

     Example:
     ......
     ......
     Cascade=0
     Passwd = 0   && The password is 0
     * Factory set value of password is 0, you may change the password by using DOGEDIT.EXE
     * in the UTILITY folder.
     DogData = "GS-MH"  && DogData points a string's address
     Addr = 0           && Address is 0 
     retcode=WriteDog(Cascade,Addr,Passwd,DogData)
     if (retcode=0)     && Success when retcode=0
        ? '  write string succeeded'
     else
        ? '  write string failed, error=',retcode
     endif

   b. When DogData is a long integer, WriteDog will write the integer (4 bytes) into the 
      hardware Dog with beginning address DogAddr.

     Example:
     ......
     ......
     Cascade=0
     Passwd = 0   && The password is 0
     * Factory set value of password is 0, you may change the password by using DOGEDIT.EXE
     * in the UTILITY folder.
     DogData = 2000      && DogData is a long integer, WriteDog will write the integer into the Dog
     Addr = 30           && Beginning address is 30 
     retcode = WriteDog(Cascade,Addr,Passwd,DogData)
     if (retcode=0)      && Success when retcode=0
        ? '  write long succeeded'
     else
       ? '  write date failed, error=',retcode
     endif

   c. When DogData is a boolean data, WriteDog will write the data (2 bytes) into the hardware Dog with 
      beginning address DogAddr.
        ( DogData = .T. or DogData = .F. )

     Example:
     ......
     ......
     Cascade=0
     Passwd = 0   && The password is 0
     * Factory set value of password is 0, you may change the password by using DOGEDIT.EXE
     * in the UTILITY folder.
     DogData = .T.      && DogData is a boolean data, WriteDog will write the data into the Dog
     Addr = 20          && Beginning addressis 20 
     retcode = WriteDog(Cascade,Addr,Passwd,DogData)
     if (retcode=0)     && Success when retcode=0
        ? '  write logic succeeded'
     else
        ? '  write date failed, error=',retcode
     endif

   d. When DogData is a date data, WriteDog will write the data (8 bytes) into the hardware Dog
      with  beginning address DogAddr.

     Example:
     ......
     ......
     Cascade=0
     Passwd = 0   && The password is 0
     * Factory set value of password is 0, you may change the password by using DOGEDIT.EXE
     * in the UTILITY folder.
     Addr = 10          && Beginning addressis 10 
     DogData = 3        && DogData equals 3, ReadDog will return a date data
     retcode=WriteDog(Cascade,Addr,Passwd,DogData)
     if (retcode=0)     && Success when retcode=0
        ? '  write date succeeded '
     else
        ? '  write date failed, error=',retcode
     endif

--------
Remarks:
--------
   You should pay more attention to the last 4 bytes in the Dog's memory, because they are 
   the selecting byte of converting algorithm (address 196) and user defined algorithm's 
   descriptors (address from 197 to 199), will take effect on the result of conversion.

   If you want to choose a certain converting algorithm, please use the function WriteDOg()
   to change the content of address 196 in the Dog's memory.
   
   If you want to change the descriptors, please use the function WriteDog() to change the 
   content of address from 197 to 199 in the Dog's memory.

5. DogResult = DogConvert(Cascade,DogData)

   Input parameter: Cascade, DogData
   Return value: Result of converting algorithm
   Function: The function transfers a string to the hardware Dog.  Then the Dog scrambles the 
       string, and returns the scrambled result as a 32-bit integer.  DogData points to the 
       string.
       The conversion algorithm can be specified by the developers.  The last 4 bytes 
       of the memory will affect the conversion algorithm.  The 196th byte is used to 
       specify the algorithm.  Therefore, the developer can define 256 kinds of algorithms. 
       The algorithm descriptor is made up of the 197th,198th and 199th byte, so it 
       may have a total of 16,777,215 different combinations.

   Example:
     ......
     ......
     Cascade = 0          && Cascade should be 0 in this version
     retcode = 0
     ConvertStr = "223344"
     Result=DogConvert(Cascade,ConvertStr)
     retcode=GetRetCode()
     if (retcode=0)       && Success when retcode=0
        ? '  convert succeeded. result=', Result
     else
        ? '  convert failed, error=',retcode
     endif

-------
Remarks
-------
1) The developer should call GetRetCode() function immediately after calling DogConvert().
   The return value of DogConvert() is valid only when GetRetCode() returns 0 (means success).

2) DogConvert() will fail if ShareDis() has been already called and share has been detected. 

6. RetCode = ShareDis(Cascade)

   Input parameter: Cascade (Cascade should be 0 in this version.)
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Disable the hardware Dog's sharing ability.
         The parallel port hub is a kind of hardware share device that allows multiple 
         copies of the protected program share the same Dog. 
         Factory setting for share ability is Enable. You may call DisableShare function to 
         to prevent pirates from using a parallel port hub. So that only the machine that 
         has the Dog can run the protected program.  
         DisableShare only affects the functions ReadDog, WriteDog and DogConvert. 

* Caution:
         Do not call on this function multiple times. It is designed to be called no more
         than once in an application.

    Example:
     ......
     ......
     Cascade = 0          && Cascade should be 0 in this version
     retcode = 0
     retcode=ShareDis(Cascade)
     if (retcode=0)       && Success when retcode=0
        ? '  disable share succeeded.'
     else
        ? '  disable share failed, error=',retcode
     endif

------
Remark
------
    Please do not call the function ShareDis() more than once. One program should call 
the function only once.

7. CurNo = GetCurNo(Cascade)

   Input Parameter: Cascade
   Return value: The Manufacturing code
   Function: Reads the Manufacturing code of the hardware Dog.Some of the hardware
             Dogs may have the same ID, but every hardware Dog has its unique
             Manufacturing code. The Manufacturing code can help developers manage
             user accounts.
             The Manufacturing code is 4 bytes.

   Example:
     ......
     ......
     Cascade = 0          && Cascade should be 0 in this version
     retcode = 0
     CurNo = GetCurNo(Cascade)
     retcode=GetRetCode()
     if (retcode=0)       && Success when retcode=0
        ? '  Get propduction-sequence number succeeded. result=', CurNo
     else
        ? '  Get propduction-sequence number failed, error=', retcode
     endif
     
------
Remark
------
   The developer should call GetRetCode() function immediately after calling GetCurNo().
   The return value of GetCurNo() is valid only when GetRetCode() returns 0 (means success).


8. RetCode = GetRetCode()

   Input Parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Get status of last operation on the Dog. 
  
9. RetCode = MFDogCheck(Cascade, DogPassword)

   Input Parameter: Cascade, DogPassword
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: This function executs similar function with DogCheck() but specially provided 
           for GS-MD/MF MicroDog hardware Dog. Cascade has no meaning for GS-MD/MF MicroDog 
           and should be 0.  

10. DogResult = MFDogCvt(Cascade, DogData, DogPassword)

   Input Parameter: Cascade, DogData, DogPassword
   Return value: Converting  result
   Function: This function executs similar function with DogConvert() but specially provided 
           for GS-MD/MF MicroDog hardware Dog. Cascade has no meaning for GS-MD/MF MicroDog 
           and should be 0. 


============
 Error code
============
    Refer to ERRCODE.TXT on the root of the installation directory for detailed 
information about error codes.

========
Cautions
========
    1. You should pay more attention to the last 4 bytes in the Dog's memory when you call 
function WriteDog(), because they are the selecting byte of converting algorithm 
(address 196) and user defined algorithm's descriptors (address from 197 to 199), 
will take effect on the result of conversion.
    2. This API can operate the Dog of GS-MD/MF MicroDog, but can execute new functions such as
ShareDis(), GetCurNo() etc.
    3. When using this API for GS-MD/MF MicroDog Dog, please set DogPassword before calling
MFDogCheck(), MFDogCvt().
    4. In this version, the modules do not have a cascade function, although CASCADE will 
be available in the future. So, it must be 0. If you need this function, please 
contact us.    

  
=================
Technical support
=================
    If you have any technical problems, please contact Rainbow China Co., Ltd., 
our branches, or our distributors.  Be prepared to provide us your software part 
number.  This will accelerate our help.
    The part number of DOS16DOG is GS-MH-D16-CLIPPER 2.000.
    The last part of a part number is a version number, which can also be extracted
by using Utility/Getver.exe.   The two values should be same.  If not, refer to 
the result returned by Getver.exe  first.  The version information can be helpful
in pinpointing and solving problems.
    Please Refer to  /Address.txt for the contact address.


