		   ------------------------------------------
		           File list for WIN16 folder
		   ------------------------------------------
      MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.    
    
  The RC-MH specified below has exactly the same functions of MicroDog Suite.

  File list
  ---------
  The files and directories below are included in directory WIN16.
 
  WIN16
    |- README-ENG.TXT      This file.
    |
    |- C          <dir>  - API & demo program for Visual C & Borland C/C++ compiler. 
    |
    |- DLL        <dir>  - A DLL including its source code and various kinds of applications 
    |                      to show how to call the DLL including VC, VB and PB .
    |
    |- EXETOOL    <dir>  - Protection tool used to protect EXE files running under 16-bit 
    |                      WIndows directly. 
    |
    |- DELPHI     <dir>  - API & demo program for 16-bit Windows DELPHI 1.0 compiler.
    |
    |- FLL        <dir>  - A FLL including its source code and demo program for FOXPRO.
    |
    |- PWC        <dir>  - API & demo program for changing access password in the 
    |                      hardware Dog.
    |
    |- PWDLL      <dir>  - A DLL including its source code and demo program to show how
    |                           to change the access password in the hardware dog.
    |
    |- Toolbook   <dir>  - A DLL including its source code and demo program for toolbook4.0.


 