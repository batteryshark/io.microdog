
                     -------------------------------------------------------
                            MicroDog Suite 16-bit Windows Application
                                    Illustration of DLL sample 
                     -------------------------------------------------------

                 Copyrights (c)  2002 , Rainbow China Co., Ltd. 

         MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.      
    
  The RC-MH specified below has exactly the same functions of MicroDog Suite.

=======
Functions
=======
MicroDog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.

The Hardware Dog consists of a microprocessor and a memory. Please insert the Hardware Dog of 
Parallel Dog into the parallel port or that of USBDog into the USB port.  The software supplies 
functions for calling the Hardware Dog.

MicroDog Suite has six functions including verifying of the correct Hardware Dog, writing data 
into and reading data from the memory, changing data, checking the current manufacturing number 
and setting anti-sharing mode.

The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 

The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call them
directly to achieve security of higher degree. You can also write the configuration data into 
Hardware key and record your operations.

DogCovert function is that the program sends a string of data to Hardware Dog, and Hardware Dog 
will return a 32-digit integer number. The data sent and the data returned can match each other 
well. The algorithms for Hardware Dog with different Serial Numbers are different,and you can 
define your own protection algorithms. 256 algorithms are available and 3-byte descriptors 
can be selected for each algorithm, thus more than 16 million different algorithm descriptors. 

GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.

The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.

The six functions specified above will secure your software products from any unauthorized use. 

For detailed information about how to implement software protection, 
please refer to the Developer's manual.

=========
File list
=========
	
	README-ENG.TXT		this file
	GSMHWG.DLL		DLL file
	source	<dir>		source files for Dll 
	Demo.tbk		ToolBook4.0 sample program

===============================
Introduction to DLL programming
===============================

Under 16-bit WINDOWS environment, the MicroDog Dynamic Linking Library can be made 
through MS Visual C++ or Borland C++ compiler. The approach is to call the WIN16 C 
standard API (in WIN3x\C folder) in the DLL, so as to operate the MicroDog. Thus, 
the applications calling this DLL will be able to judge whether the proper MicroDog exists 
through the result of the operation. The application is then protected. See below the 
illustration for the calling to dynamic linking library by an application:
	  
 Application     Win16 DLL      Win16 API        Parallel port  
 ------------    ---------      ---------        -------------
      |   call    |    call       | communication    |
      |           |               | with the Dog     |
      |=========> | ============> | ==============>  | ========>  --------------
      |           |               |                  |            |Dog Hardware|
      |<========= | <============ | <==============  | <========  --------------


One important thing is that, because the DLL is separated from the protected application, 
the calling interface of DLL functions is then exposed to hacker (because of the nature 
of DLL). Here comes the importance for the hiding of DLL functions' name and function 
calling.  Therefore, we strongly recommend you to use static API Library (such as C API) to 
protect your application other than DLL in general. If DLL method must be used, and the 
strength of the protection comes from the complexity of your own DLL, the software developer 
must make the DLL as complicated as possible. The functions' calling interface of DLL must 
be hidden well, and the functions' names in the DLL should not be relative with the Dog 
operation. The sequence of parameters passing should also be baffling for hackers, and the 
dog operation functions should be merged with your own other DLL functions. 

For your benefits, please remember that GSMHWG.dll we provided is only a sample program. 
It should not be used for any kind of protection work, since its source code is already 
open to public. You should follow the above principles to develop you own DLLs by calling 
C/C++ module. 

To increase protection intensity, we strongly recommend you that after using DLL protection, 
forming a protected EXE file, you should use our SHELL encryption tool (in WIN3x\EXETOOL 
directory) to protect the EXE file further.

=========
File list
=========
   File Name        Description
   ------------     -----------------------------
   README-ENG.TXT	this file(English)
   GSMHWG.DLL		DLL file
   source	<dir>	source files for Dll 
   Demo.tbk		ToolBook4.0 sample program


=======================
 DLL sample: GSMHWG.DLL
=======================
1. GSMHWG.DLL is actually calling the C API module (WIN16IL.OBJ) to operate the 
   hardware Dog. When building your own DLLs, you should also call this API module 
   to operate the hardware Dog.

2. This sample DLL only defines one function:
        WINAPI unsigned long GS_MHDog(UCHAR m_Command, UCHAR m_Cascade, UINT m_DogAddr, UINT m_DogBytes,
		           void far * m_DogData, void far * m_DogResult, unsigned long m_DogPassword )		
   Return Value: 0 means success, others are error codes.

3. 
	UCHAR 		m_Command;		//Command Code
	UCHAR		m_Cascade;		//Cascade Number, it must be 0 in this version
	UINT		m_DogAddr;		//Beginning Address
	UINT		m_DogBytes;		//Length of operation data(0~200)
	unsigned long	m_DogPassword;		//Access password stored in the hardware Dog
                                		//only needed by read and write operation.
	void  		far *m_DogResult;	//Conversion Result
	void 		far * m_DogData;	//IO data buffer.

4. The  m_Command is a command code, defined as following:
    DogCheck	   1	Check the hardware Dog
    ReadDog	   2	Read data from the Dog
    WriteDog	   3	Write data to the Dog
    DogConvert	   4	Convert a string into a 32-bit integer
    GetCurrentNo   5	Get hardware ID number of the Dog
    DisableShare   7	Disable share

 a. DogCheck
   Input parameter: m_DogCascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Checks whether the hardware Dog exists.  Only a Dog that has the same serial
         number as the OBJ file can be detected.  In this version, the modules do not 
         have a cascade function. CASCADE will be used in the future, so it must be set to 
	 0 now. If you need this function, please contact us.       

 b. ReadDog
   Input parameter:  m_DogCascade, m_DogAddr, m_DogBytes, m_DogData, m_DogPassword
   Output parameter:  m_DogData
   Return value:     zero means operation succeeded. All others are error codes.
   Function: Reads data from the hardware Dog. The Dog contains a 200-byte nonvolatile 
         memory.  ReadDog reads data from the Dog memory beginning at the address 
         indicated by m_DogAddr.  The bytes number of the read data is indicated 
         by m_DogBytes.  The read data is stored in the space m_DogData points to.
         MicroDog verifies the m_DogPassword. m_DogPassword is the password for
         read/write operations stored on the hardware Dog.  It can be set by the 
         utility tool DOGEDIT.EXE in UTILITY folder or the SetPassword() function. 
         Applications must ensure enough space to buffer the data being read.  ReadDog 
         does not check whether the buffer size is sufficient.

 c. WriteDog
   Input parameter: m_Cascade, m_DogAddr, m_DogBytes, m_DogData, m_DogPassword
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Writes data to the hardware Dog. Carries out the same operation as ReadDog,
      except that the data flow direction is different.

 d. DogConvert
   Input parameter: m_Cascade, m_DogBytes, m_DogData
   Output parameter: m_DogResult
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Transfers data to MicroDog.  The hardware Dog converts the data 
       and returns the converted result m_Dogresult as a string.  m_DogBytes indicates
       the number of bytes of the date, which m_DogData points to, being converted. 
       The conversion algorithm can be specified by the developer.  The last 4 bytes 
       of memory affects the conversion algorithm.  The 196th byte is used to 
       specify the algorithm.  Therefore, a developer can define 256 kinds of algorithms. 
       The algorithm descriptors are made up of the 197th, 198th and 199th byte, so it have 
       a maximum of 16,777,215 different combinations.
   
 e. DisableShare
   Input parameter: m_Cascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Disable the hardware Dog's sharing ability.
         The parallel port hub is a kind of hardware share device that allows multiple 
         copies of the protected program share the same Dog. 
         Factory setting for share ability is Enable. You may call DisableShare function to 
         to prevent pirates from using a parallel port hub. So that only the machine that 
         has the Dog can run the protected program.  
         DisableShare only affects the functions ReadDog, WriteDog and DogConvert. 

 * Caution:
         Do not call on this function multiple times. It is designed to be called no more
         than once in an application.

 f. GetCurrentNo	
   Input Parameter: m_Cascade, m_DogData
   Output parameter: m_DogData
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads the Manufacturing code of the hardware Dog and returns the  result 
	     m_Dogresult as a string.Some of the hardware Dogs may have the same ID, but
	     every hardware Dog has its unique Manufacturing code. The Manufacturing code
	     can help developers manage user accounts.
             The Manufacturing code is 4 bytes.
   
=========
Cautions
=========
1. When you write data to the Dog, changing the last 4 bytes of the 
   MicroDog memory will affect the result of function DogConvert().

2. If you use MD or MF, the functions DogCheck() and DogConvert() require
   DogPassword, and the functions DisableShare() and GetCurrentNo() are 
   not functional.

3. If you want to run the protected application in other computer in Windows 9x or 
   Windows NT or Windows 2000, you should install the corresponding device driver 
   for the hardware Dog. Please use INSTDRV.EXE in the DRIVER folder to install 
   the correct driver.

4. If you want to release your protected programs to your end-users, please include
   the device drivers and installing tool in the DRIVER folder in your SETUP process,
   and execute installing the device drivers for the Dog first. 

5. One important thing is that, because the DLL is separated from the protected 
   application, the calling interface of DLL functions is then exposed to hacker 
   (because of the nature of DLL). Here comes the importance for the hiding of DLL 
   functions' name and function calling.  Therefore, we strongly recommend you to 
   use static API Library (such as C API) to protect your application other than DLL 
   in general. If DLL method must be used, and the strength of the protection comes 
   from the complexity of your own DLL, the software developer must make the DLL as 
   complicated as possible. The functions' calling interface of DLL must be hidden 
   well, and the functions' names in the DLL should not be relative with the Dog 
   operation. The sequence of parameters passing should also be baffling for hackers, 
   and the dog operation functions should be merged with your own other DLL functions. 

   For your benefits, please remember that GSMHWG.DLL we provided is only a sample 
   program. It should not be used for any kind of protection work, since its source 
   code is already open to public. You should follow the above principles to develop 
   you own DLLs by calling C/C++ API module (WIN16IL.OBJ). 

6. To increase protection intensity, we strongly recommend you that after using DLL 
   protection, building a protected EXE file, you should use our SHELL encryption 
   tool (in WIN3x\EXETOOL directory) to protect the EXE file further.

7. In this version, the module does not have a cascade function, although 
   CASCADE will be available in the future. So, it must be 0. If you need this 
   function, please contact us.    

============
Error code
============
   Refer to ERRCODE.TXT in the root of the installation directory for detailed 
   information about error codes.

=================
Technical Support
=================
    For technical issues, please contact Rainbow GoldenSoft Co., Ltd. or its distributors 
immediately. Please provide us with the parts-number of the software you are using. 

    The last part of this is the version number. You can also use Utility/Getver.exe to 
get the version number of this software module, which should be the same with this. If 
variations exist, the result from Getver.exe is right for report. Version number helps 
us to troubleshoot the problem and provide the right solutions. 

    For contact address, please see Address.txt under installation path.

===================================
Appendix:  To develop YOUR own DLL
===================================

   One important thing is that, because the DLL is separated from the protected 
   application, the calling interface of DLL functions is then exposed to hacker 
   (because of the nature of DLL). Here comes the importance for the hiding of DLL 
   functions' name and function calling.  Therefore, we strongly recommend you to 
   use static API Library (such as C API) to protect your application other than DLL 
   in general. If DLL method must be used, and the strength of the protection comes 
   from the complexity of your own DLL, the software developer must make the DLL as 
   complicated as possible. The functions' calling interface of DLL must be hidden 
   well, and the functions' names in the DLL should not be relative with the Dog 
   operation. The sequence of parameters passing should also be baffling for hackers, 
   and the dog operation functions should be merged with your own other DLL functions. 

   When you develop write a your own dll by using VC1.5, you must set following config:

	  1.Options/Project/Compiler/memory Model/Segment setup/
     	    SS!=DS,DS Loaded on functions entry
	  2.Options/Project/Comppiler/Windows Prolog/Epilog/None

   You can refer to gsmhwg.cpp when you develop YOUR own DLL. 
