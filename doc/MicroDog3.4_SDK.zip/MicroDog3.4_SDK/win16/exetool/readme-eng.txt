
                     -------------------------------------------------------
                               MicroDog Suite 16-bit WINDOWS Application
                                  UTILITY Guide to SHELL Protection
                     -------------------------------------------------------

                 Copyrights (c)  2001 , Rainbow China Co., Ltd. 

       MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.      
    
  The RC-MH specified below has exactly the same functions of Microdog Suite.

========================
Overview
========================
1) This utility may protect NE format executable files running in Windows 3.x.

2) This utility program has two protection types -- shell and embedded API protection. 

 a. Shell protection will add a shell program onto original executable program, that 
    shell program may gain control of CPU before the original program is executed. 
    Therefore it will verify the presence of the correct Hardware Dog first. If 
    the correct Hardware Dog exits, it will transfer control right to original program
    and jump to the entrance of the program. Otherwise, it exits. 

 b. Embedded API protection is a more complex technology. When running, the protected program 
    can capture the system-calling instructions of the original program, and 
    count the number of captures. It will check for the existence of the correct
    Hardware Dog at certain interval that can be set during building-up process of the 
    protected program. Embedded API protection may lower the efficiency of the protected 
    program. The shorter the interval is, the more the program is affected. 

3) Please start this tool in Windows, and follow the instructions. The right 
   Dog should be inserted in the computer's parallel port or USB port when this tool 
   or protected program runs.

4) Structure of NE format file is flexible and complex. Please test your protected
   program carefully. If you find abnormal performance of your program, please record 
   them in detail, and report to us immediately.

5) Besides EXE files, this program can protect DLL files. 

6) The developers are able to choose to allow trial period or not. If you choose 
   trial period, you will determine how many days are in the trial period with current day 
   as the starting date. Before the expiration date, the protected program can be used 
   without the Hardware Dog.  Once the trial period expires, the program must run with the 
   Hardware Dog. If the Dog is not found, it will require you to plug it in.  
   If you do not have the Dog, the program will exit. Each time the protected file runs, 
   the current system date and time is recorded in a hidden,protected file in the system folder. 
   The file name is same with that of the protected program with extension as .HIS. Every 
   time when the protected program runs, it check whether the current time is earlier 
   than the last recorded time. If it is, the system time is regarded as  
   changed manually, and it is considered as expired. 

7) You may use AS technology (combination of API and Shell) to enhance protection for
   your application. Please refer to "umh3.chm" for AS technology.
 
8) You may use the wizard or direct mode to input related parameters. The wizard 
   should provide detailed description to each parameter and each step of operation. 
   The results are same.

9) You may use the default or your own configuration file. All contents configurable
   by the developer should be kept in a configuration file. The wizard and direct mode
   use the same configuration file. 

10) This tool cannot be used to protect self-verifying program. Some programs will 
    check itself when running. If it finds any difference, it will regard it as infected 
    by virus and refuse to continue.

11) Applications protected with this tool can be run in Windows 3.x, Windows 95 and 
    Windows NT/2K. 
    Please install device drivers when the protected program(s) runs in Windows 95. 
    Otherwise, the printing process may be affected. 
    16-bit Windows NT/2K device drivers must be installed when it runs in Windows NT/2K.

    please read readme file at DRIVER folder to learn how to install drivers.

=========
File list
=========
   File name             Description
   --------------        -----------------------------------------------------
   README-ENG.TXT        This file
   WIN16EXE.EXE	         This protection tool
   Ctl3d.dll             DLL file needed by this tool    
   Listhscr.dll          DLL file needed by this tool    
===================
Tested environments
===================

  Systems: Windows 3.2 Chinese version, Windows NT 4.0/2K, Windows 9X

  Various executable files (NE format) of Windows 3.x, including: Power Builder 4.0, 
Microsoft Visual Basic 3.0, Microsoft Foxpro 2.5, Tool Book 4.0 etc..

=================
Power Builder 4.0
=================

PBLMI040.DLL is a DLL for Power Builder 4.0 that can be found in the folder of Power 
Builder 4.0. 

This tool can be used to protect EXE files created with Power Builder 4.0. Please set the 
file types in the 'parameters' option when using the tool. 

Meanwhile, please rebuild PBLMI040.DLL with the tool. The protected EXE files can be 
run only with rebuilt PBLMI040.DLL. It's the developer's responsibility to deliver both 
of the protected program and the rebuilt PBLMI040.DLL to your end-users. 

The rebuilt PBLMI040.DLL can also be used for non-protected EXE files. 

====================
Visual Basic 3.0/4.0
====================                      

VBRUN300.DLL/VB40016.DLL is a DLL for Visual Basic 3.0/4.0 that can be found at the system 
folder of Windows 3.x.

This tool can be used to protect EXE files created with Visual Basic 3.0/4.0. Please set  
the file types in the 'parameters' option when using the tool. 

Meanwhile, please rebuild VBRUN300.DLL(VB 3.0) or VB40016.DLL(VB 4.0) with the tool. After 
being rebuilt, the VBRUN300.DLL should be named VBRUN301.DLL. The protected EXE files can  
run only with rebuilt VBRUN301.DLL/VB40016.DLL. It's the developer's responsibility to 
deliver the both the protected program and the rebuilt DLL files to the end-users. 

VBRUN301.DLL/VB40016.DLL can also be used for non-protected EXE files.

Before rebuilding, VBRUN300.DLL/VB40016.DLL should first be renamed other file names. 
The output file should be named VBRUN301.DLL/VB40016.DLL.

If VBRUN301.DLL/VB40016.DLL is in the same directory with the protected program, please 
ensure that there is no un-rebuilt VBRUN300.DLL/VB40016.DLL files in WINDOWS system folder 
because WINDOWS will first access the DLL in SYSTEM folder and before accessing the current
folder. 

This tool can also protect database files (.DBF) used by the protected VB EXE program. 
Please follow the steps below:

1) Rebuild XBS110.DLL. This is a VB 3.0 DLL that operates the database file. It can be 
   found at the folder of Windows system. Before rebuilding, it should first be renamed  
   XBS110.D, and the output file should be entered as XBS110.DLL.

2) Protect DBF files. you need to change the name before protection. The 
   protected files have extension as DBF, wildcard character '*' is available.

3) Distribute the rebuilt XBS110.DLL with protected DBF. 

4) VB EXE program can either be protected or not, with no affect on DBF protection. 

5) After rebuilding, the XBS110.DLL can automatically recognize which DBF has been protected.
   This is helpful when there are several DBF files, and only some of them 
   need to be protected. the rebuilt XBS110.DLL is suitable in such situations. 

==============
Tool Book 4.0
==============                      
1) Protect its EXE as VB3.0 files. 

2) Rebuild TBLOAD.EXE, MTB40NET.EXE and MTB40BAS.DLL (may choose other DLL). 
   (Note: Non-protected EXE also need the Dog to run)

===========
Foxpro2.5
===========
This tool can be used to protect EXE files created with Foxpro 2.5. Please set  
the file types in the 'parameters' option when using the tool. 

Meanwhile, please rebuild Foxw2500.DLL with the tool.  The protected EXE files can  
run only with rebuilt Foxw2500.DLL. It's the developer's responsibility to 
deliver the both the protected program and the rebuilt DLL files to the end-users. 

Foxw2500.DLL can also be used for non-protected EXE files.

Before rebuilding, Foxw2500.DLL should first be renamed other file names. The output file
should be named Foxw2500.DLL again.

If Foxw2500.DLL is in the same directory with the protected program, please 
ensure that there is no un-rebuilt Foxw2500.DLL files in WINDOWS system folder 
because WINDOWS will first access the DLL in SYSTEM folder and before accessing the current
folder. 

This tool can also protect database files (.DBF) used by the protected Foxpro EXE program. 


===========
Foxpro2.5B
===========
This tool can be used to protect EXE files created with Foxpro 2.5B. Please set  
the file types in the 'parameters' option when using the tool. 

Meanwhile, please rebuild Foxw250B.DLL with the tool.  The protected EXE files can  
run only with rebuilt Fox250B.DLL. It's the developer's responsibility to 
deliver the both the protected program and the rebuilt DLL files to the end-users. 

Foxw250B.DLL can also be used for non-protected EXE files.

Before rebuilding, Foxw250B.DLL should first be renamed other file names. The output file
should be named Foxw250B.DLL again.

If Foxw250B.DLL is in the same directory with the protected program, please 
ensure that there is no un-rebuilt Foxw250B.DLL files in WINDOWS system folder 
because WINDOWS will first access the DLL in SYSTEM folder and before accessing the current
folder. 

This tool can also protect database files (.DBF) used by the protected Foxpro EXE program. 

===========
Foxpro2.6
===========
This tool can be used to protect EXE files created with Foxpro 2.6. Please set  
the file types in the 'parameters' option when using the tool. 

Meanwhile, please rebuild Foxw2600.DLL with the tool.  The protected EXE files can  
run only with rebuilt Fox2600.DLL. It's the developer's responsibility to 
deliver the both the protected program and the rebuilt DLL files to the end-users. 

Foxw2600.DLL can also be used for non-protected EXE files.

Before rebuilding, Foxw2600.DLL should first be renamed other file names. The output file
should be named Foxw2600.DLL again.

If Foxw250B.DLL is in the same directory with the protected program, please 
ensure that there is no un-rebuilt Foxw2600.DLL files in WINDOWS system folder 
because WINDOWS will first access the DLL in SYSTEM folder and before accessing the current
folder. 

This tool can also protect database files (.DBF) used by the protected Foxpro EXE program. 

===========
Error code
===========
See errcode.txt in the installation directory.
	
=======
Cautions
=======

When you protect VB applications, there is an access order problem for the protected
files to access VBRUN300.DLL. The order is decided by Windows. Thus, the rebuilt 
VBRUN301.DLL should be in Windows\system folder. This is the priority
folder for ordinary Windows application to access. If this still does not work, please check whether 
there are files with same names in other folders that have priority to access, and change 
their names. 

This is same with POWER BUILDER. 

=================
Technical Support
=================
    For technical issues, please contact Rainbow GoldenSoft Co., Ltd. or its distributors 
immediately. Please provide us with the part-number of the software you are using. 

    The part-number of this module is RG-UMH-W16-SHELL 1.000.

    The last part of is the version number. You can also use Utility/Getver.exe to 
get the version number of this software module which should be the same with this one. If 
variations exist, the result from Getver.exe is right for report. Version number helps 
us to troubleshoot the problem and provide the right solutions. 

    For contact address, please see Address.txt under installation path.
