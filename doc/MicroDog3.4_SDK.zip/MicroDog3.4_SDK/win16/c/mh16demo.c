/****************************************************************************

    PROGRAM: DOGDEMO

    PURPOSE: This application demonstrates how to invoke the Microdog's
             API for Windows Application
             
    Copyright 2000 Rainbow Goldensoft Co.,Ltd. All Rights Reserved

****************************************************************************/

#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "resource.h"

unsigned char Cascade;
		//  The globle variable Cascade indicates the cascade serial . 
        //  It must be set to 0 at this version.
UINT DogAddr;			
//  The globle variable DogAddr indicates the first memory  address ( range
//  0 to 199) of user area in the MicroDog when you make reading and/or writing
//  operations.The sum of DogAddr and DogBytes should not exceed 200.

UINT DogBytes;			
//    The globle variable DogBytes indicates the number ( 1-200 ) of bytes in
//  the  operation of reading/writing or  convertion. The  sum of DogAddr and
//  DogBytes should not exceed 200.

void far * DogData;
//  The globle variable DogData indicates  the pointer variable which poi-
//  nts to the data for operations .
unsigned long DogResult;
//    The globle variable DogResult indicates the result of converting opera-
//  tion.

unsigned long DogPassword;
//    The globle variable DosPassword indicates the password in the MicroDog
//  (factory value is zero), used in the reading/writing/converting operation.

extern unsigned long far DogCheck(void);
extern unsigned long far ReadDog(void);
extern unsigned long far WriteDog(void);
extern unsigned long far DogConvert(void);
extern unsigned long far GetCurrentNo(void);
extern unsigned long far DisableShare(void);

HANDLE hInst;

BOOL FAR PASCAL MainDlgProc(HWND, unsigned, WORD, LONG);
BOOL FAR PASCAL LoopDlgProc(HWND, unsigned, WORD, LONG);
void Status(HWND hDlg,WORD wParam,DWORD lParam);

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;                // current instance
HANDLE hPrevInstance;            // previous instance
LPSTR lpCmdLine;                 // command line
int nCmdShow;                    // show-window type (open/icon)
{
	hInst = hInstance;

	DialogBox(hInstance,"MainDlg",(HWND)NULL,MainDlgProc);   

	return 0;
}

BOOL FAR PASCAL MainDlgProc(HWND hDlg,unsigned message,WORD wParam,LONG lParam)                                                           
{                         
	DWORD ul, ret;
	UINT ui;
	double real;
	unsigned char buff[30], msg[100], status[256];
	
	switch(message)                                                    
	{                        
		case WM_COMMAND:
			switch(wParam)
			{                  
			case IDC_CHECK:
				Cascade = 0;
				ret = DogCheck();
				if(ret)
					wsprintf(status, "Check dog fail! Error Code: %ld.", ret);
                else
                    wsprintf(status, "Check dog successfully!");
                    
                SetDlgItemText(hDlg, IDC_STATUS, status);
				break;
			case IDC_READ:
				Cascade = 0;				
				DogAddr = 10;
				DogPassword = 0;
		    	DogBytes = 8;
				DogData = buff;
				ret = ReadDog();
				buff[DogBytes] = 0;
				if(ret)
					sprintf(msg, "Read string from dog is \"MicroDog\" fail! Error Code: %ld.\n", ret);
                else
                    sprintf(msg, "Read string from dog is \"%s\" successfully!\n", buff);
                strcpy(status, msg);
                    
				DogAddr = 30;
		    	DogBytes = 2;
				DogData = &ui;
				ret = ReadDog();
				if(ret)
					sprintf(msg, "Read integral from dog is 12345 fail! Error Code: %ld.\n", ret);
                else
                    sprintf(msg, "Read integral from dog is %d successfully!\n", ui);
                strcat(status, msg);
                    
				DogAddr = 50;
		    	DogBytes = 8;
				DogData = &real;
				ret = ReadDog();
				if(ret)
					sprintf(msg, "Read double from dog is 111.222 fail! Error Code: %ld.\n", ret);
                else
                    sprintf(msg, "Read double from dog is %#7.3f successfully!\n", real);
                strcat(status, msg);

                SetDlgItemText(hDlg, IDC_STATUS, status);
			    break;
			case IDC_WRITE:
				Cascade = 0;				
				DogAddr = 10;
				DogPassword = 0;
		    	DogBytes = 8;
		    	strcpy(buff, "MicroDog");
				DogData = buff;
				ret = WriteDog();
				if(ret)
					sprintf(msg, "Write string \"%s\" to dog fail! Error Code: %ld.\n", buff, ret);
                else
                    sprintf(msg, "Write string \"%s\" to dog successfully!\n", buff);
                strcpy(status, msg);
                    
				DogAddr = 30;
		    	DogBytes = 2;
		    	ui = 12345;
				DogData = &ui;
				ret = WriteDog();
				if(ret)
					sprintf(msg, "Write integral %d to dog fail! Error Code: %ld.\n", ui, ret);
                else
                    sprintf(msg, "Write integral %d to dog successfully!\n", ui);
                strcat(status, msg);
                    
				DogAddr = 50;
		    	DogBytes = 8;
		    	real = 111.222;
				DogData = &real;
				ret = WriteDog();
				if(ret)
					sprintf(msg, "Write double %#7.3f to dog fail! Error Code: %ld.\n", real, ret);
                else
                    sprintf(msg, "Write double %#7.3f to dog successfully!\n", real);
                strcat(status, msg);

                SetDlgItemText(hDlg, IDC_STATUS, status);
		    	break;
			case IDC_CONVERT:            
				Cascade = 0;
		    	DogBytes = 8;
		    	strcpy(buff, "MicroDog");
				DogData = buff;
				ret = DogConvert();
				if(ret)
					sprintf(status, " Convert \"%s\" fail! Error Code: %ld.", buff, ret);
				else 
					sprintf(status, " Convert \"%s\" to %ld successfully!", buff, DogResult);

                SetDlgItemText(hDlg, IDC_STATUS, status);
			    break;
			case IDC_GET_CURRENT_NO:
				Cascade = 0;
				DogData = &ul;
				ret = GetCurrentNo();
				if(ret)
					sprintf(status, " Get currnet number fail! Error Code: %ld.", ret);
				else 
					sprintf(status, " Get currnet number is %ld successfully!", ul);

                SetDlgItemText(hDlg, IDC_STATUS, status);
				break;
			case IDC_DISABLE_SHARE:
				Cascade = 0;
				ret = DisableShare();
				if(ret)
					sprintf(status, " Disable share fail! Error Code: %ld.", ret);
				else 
					sprintf(status, " Disable share successfully!");

                SetDlgItemText(hDlg, IDC_STATUS, status);
				break;
			case IDOK:
				EndDialog(hDlg, TRUE);
				break;
			default:
				return FALSE;
			}
			break;
		default:
			return FALSE;
       		//return (BOOL)DefWindowProc(hDlg, message, wParam, lParam);
    }
    
    return TRUE;
}

