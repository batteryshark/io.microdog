#include "windows.h"
#include "gsmhwg.h"

#ifdef __cplusplus
extern "C" {
#endif

extern unsigned long FAR PASCAL GS_MHDog(PMH_DLL_PARA);
//extern unsigned long FAR PASCAL GS_MHDog(MH_DLL_PARA far *);
//extern int far DogCheck(void);

UCHAR Cascade;
UINT DogAddr;			
UINT DogBytes;			
void far * DogData;
unsigned long DogResult;
unsigned long DogPassword;
		
extern MHSTATUS DogCheck(void);		
extern MHSTATUS ReadDog(void);
extern MHSTATUS WriteDog(void);
extern MHSTATUS DogConvert(void);	
extern MHSTATUS SetPassword(void);	
extern MHSTATUS EnableShare(void);
extern MHSTATUS GetCurrentNo(void);
extern MHSTATUS DisableShare(void);
#ifdef __cplusplus
}
#endif

//default unload DLL
int FAR PASCAL WEP (int  bSystemExit)
{
    return(1);
}

//default Load DLL
BOOL FAR PASCAL DllMain (HINSTANCE hDLL, DWORD dwReason, LPVOID lpReserved)
{                          
    return 1;
}

//---------------------------------------------------------------------
//Routine Description:
//	the DLL(Dynamic-Link Library) only one interface function
//
//	Return Value:
//		if the function succeeds, the return value is MH_SUCCESS
//		if the function fails, the return valuse is error code
//			For details on error code, see the ErrCode.txt
//
//Parameters:
//	pmdp 
//		Points to a MH_DLL_PARA structure. You must fill the 
//		structure with the appropriate command and data before 
//		passing it to the function, and it to be filled in by 
//		this function. 
//
//typedef struct _MH_DLL_PARA
//{
//	BYTE 	Command;
//	BYTE	Cascade;
//	WORD	DogAddr;	
//	WORD	DogBytes;	
//	DWORD	DogPassword;	
//	DWORD DogResult;	
//	BYTE  	DogData[200];
//} MH_DLL_PARA;
//
//Command code
//1 DogCheck
//2 ReadDog
//3 WriteDog
//4 DogConvert
//5 GetCurrentNo
//6 EnableShare
//7 DisableShare
//
//----------------------------------------------------------------------
unsigned long FAR PASCAL GS_MHDog(PMH_DLL_PARA pmdp)
{            
                
//    pmdp->DogResult = pmdp->Command+1;
//	return 1;                       
	MHSTATUS resu = 1;
	Cascade = pmdp->Cascade;
	DogAddr = pmdp->DogAddr;
	DogBytes = pmdp->DogBytes;
	DogPassword = pmdp->DogPassword;
	DogResult = pmdp->DogResult;
	
	DogData = pmdp->DogData;
	switch(pmdp->Command)
	{
	case 1:          
		resu = DogCheck();
		break;
	case 2:
		resu = ReadDog();
		break;
	case 3:                           
		resu = WriteDog();
		break;
	case 4:
		resu = DogConvert();
		break;
	case 5:
		resu = GetCurrentNo();
		break;
	case 6:
		resu = 0;
		break;
	case 7:
		resu = DisableShare();
		break;
	}
	
	pmdp->Cascade = Cascade;
	pmdp->DogAddr = DogAddr;
	pmdp->DogResult = DogResult;
	pmdp->DogAddr = DogAddr;
	return resu;
}
