
//	File: demo.c
//	Houhongwei
//	Date:1998.8.21
//	Part:GS-MH-W16-DLL's demo for 16bits visual C++

#define STRICT

#include <windows.h>
#include <stdio.h>
#include <string.h>

#include "Demo.h"

#define MH_SUCCESS 0

MH_DLL_PARA mdp;

unsigned long FAR PASCAL GS_MHDog(PMH_DLL_PARA pmdp);

char   DispData[40];
unsigned long   RetCode;

long FAR PASCAL _export WndProc( HWND, WORD , WORD, LONG );

//#pragma argsused
int PASCAL WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
					LPSTR lpszCmd, int nCmdShow)
{
	 static char szAppName[] = "Demo" ;
	 HWND        hwnd ;
	 MSG         msg ;
	 WNDCLASS    wndclass ;
	 HANDLE 	 hAccel;

	 if (!hPrevInstance)
	 {
		  wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
		  wndclass.lpfnWndProc   = (WNDPROC)WndProc ;
		  wndclass.cbClsExtra    = 0 ;
		  wndclass.cbWndExtra    = 0 ;
		  wndclass.hInstance     = hInstance ;
		  wndclass.hIcon         = LoadIcon( NULL, IDI_APPLICATION );
		  wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;
		  wndclass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
		  wndclass.lpszMenuName  = MAKEINTRESOURCE( CHELPAPMENU );
		  wndclass.lpszClassName = szAppName ;

		  RegisterClass (&wndclass) ;
	}

	hwnd = CreateWindow (szAppName,
		"DEMO",
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		NULL,
		NULL,
		hInstance,
		NULL) ;

	 ShowWindow (hwnd, nCmdShow) ;
	 UpdateWindow (hwnd) ;

	 hAccel = LoadAccelerators( hInstance,
			MAKEINTRESOURCE( CHELPAPACCEL ) );

	 while (GetMessage (&msg, NULL, 0, 0))
	 {
		if ( !TranslateAccelerator( hwnd, hAccel, &msg ))
		{
			 TranslateMessage (&msg) ;
			 DispatchMessage (&msg) ;
		}
	 }
	 return msg.wParam ;
}

long FAR PASCAL _export WndProc (HWND hwnd, WORD message, WORD wParam, LONG lParam)
{
 HDC hdc;                        
//	HINSTANCE mlib;
 PMH_DLL_PARA pmdp = &mdp;
 int i;
	 switch (message)
	 {
		  case WM_COMMAND:
			switch ( wParam )
			{
			  case CM_U_OperateDog:
			  {             
			  
                hdc=GetDC(hwnd);
                pmdp->Command = 1;
                pmdp->Cascade = 0;
                pmdp->DogData[0] = 0x90;
                pmdp->DogPassword = 0;
                pmdp->DogResult = 0x666;
                //Check                    
                RetCode = GS_MHDog(pmdp);
			    if(RetCode==MH_SUCCESS)
			    {
				     wsprintf(DispData,"The MicroDog has been in port");
                     TextOut(hdc,80,80,DispData,strlen(DispData));
			    }
			    else
                {
				     wsprintf(DispData,"CheckDog Error , ErrorCode = %d",RetCode);
				     TextOut(hdc,80,80,DispData,strlen(DispData));
                }
			     
			     //Write
			     for(i=0;i<sizeof(pmdp->DogData)-1;i++)
				   pmdp->DogData[i] = i;
				pmdp->Command = 3;
				pmdp->DogAddr = 0;
				pmdp->DogBytes = 8;

				pmdp->DogData[0] = 'M';
				pmdp->DogData[1] = 'H';
				pmdp->DogData[2] = ' ';
				pmdp->DogData[3] = 'D';
				pmdp->DogData[4] = 'a';
				pmdp->DogData[5] = 't';
				pmdp->DogData[6] = 'e';
				pmdp->DogData[7] = 0;
				
                 RetCode = GS_MHDog(pmdp);
			     if(RetCode==MH_SUCCESS)
			     {
 					wsprintf(DispData,"Write string to Dog is success!");
                    TextOut(hdc,80,120,DispData,strlen(DispData));
			     }
			     else
			     {
			      	wsprintf(DispData,"WriteDog Error ,ErrorCode =%dL ",RetCode);
			      	TextOut(hdc,80,120,DispData,strlen(DispData));
			     }
			     
				pmdp->Command = 3;
				pmdp->DogAddr = 10;
				pmdp->DogBytes = 4;
				*(ULONG far *)&pmdp->DogData[10] = 1234;
				
                 RetCode = GS_MHDog(pmdp);
			     if(RetCode==MH_SUCCESS)
			     {
 					wsprintf(DispData,"Write long integer to Dog is success! ");
                    TextOut(hdc,80,140,DispData,strlen(DispData));
			     }
			     else
			     {
			      	wsprintf(DispData,"WriteDog Error ,ErrorCode =%dL ",RetCode);
			      	TextOut(hdc,80,140,DispData,strlen(DispData));
			     }
			     
				pmdp->Command = 3;
				pmdp->DogAddr = 20;
				pmdp->DogBytes = 4;
				*(float far *)&pmdp->DogData[20] = (float)66.6;
				                             
                 RetCode = GS_MHDog(pmdp);
			     if(RetCode==MH_SUCCESS)
			     {
 					sprintf(DispData, "Write float to Dog is success! ");
                    TextOut(hdc,80,160,DispData,strlen(DispData));
			     }
			     else
			     {
			      	wsprintf(DispData,"WriteDog Error ,ErrorCode =%dL ",RetCode);
			      	TextOut(hdc,80,160,DispData,strlen(DispData));
			     }              
			     
			     //Read
				pmdp->Command = 2;
				pmdp->DogAddr = 0;
				pmdp->DogBytes = 8;
				
                RetCode = GS_MHDog(pmdp);
				if(RetCode==MH_SUCCESS){
 					wsprintf(DispData,"The Read succeed  Str = %s", pmdp->DogData);
                    TextOut(hdc,80,180,DispData, strlen(DispData));
				}
			     else
			     {
				      wsprintf(DispData,"ReadDog Error ,ErrorCode =%dL ",RetCode);
				      TextOut(hdc,80,180,DispData ,strlen(DispData));
			     }

				pmdp->Command = 2;
				pmdp->DogAddr = 10;
				pmdp->DogBytes = 4;
				
                RetCode = GS_MHDog(pmdp);
				if(RetCode==MH_SUCCESS){

 					wsprintf(DispData,"The Read succeed  Num = %d", *(ULONG far *)&pmdp->DogData[10]);
                    TextOut(hdc,80,200,DispData,strlen(DispData));
				}                    
			     else
			     {
				      wsprintf(DispData,"ReadDog Error ,ErrorCode =%dL ",RetCode);
				      TextOut(hdc,80,200,DispData ,strlen(DispData));
			     }

				pmdp->Command = 2;
				pmdp->DogAddr = 20;
				pmdp->DogBytes = 4;
				
                RetCode = GS_MHDog(pmdp);
				if(RetCode==MH_SUCCESS){
 					sprintf(DispData,"The Read succeed  float = %f", *(float far *)&pmdp->DogData[20]);
                    TextOut(hdc,80,220,DispData,strlen(DispData));
				}
			     else
			     {
				      wsprintf(DispData,"ReadDog Error ,ErrorCode =%dL ",RetCode);
				      TextOut(hdc,80,220,DispData ,strlen(DispData));
			     }
			     
                //Convert                   
                pmdp->Command = 4;
                RetCode = GS_MHDog(pmdp);
			    if(RetCode==MH_SUCCESS)
			    {
				     wsprintf(DispData,"Convert success  ");
                     TextOut(hdc,80,260,DispData,strlen(DispData));

				     wsprintf(DispData,"Convert = %ld", pmdp->DogResult);
                     TextOut(hdc,260,260,DispData,strlen(DispData));
			    }
			    else
                {
				     wsprintf(DispData,"Convert Error , ErrorCode = %d",RetCode);
				     TextOut(hdc,80,260,DispData,strlen(DispData));
                }

                //GetCurrentNo                    
                pmdp->Command = 5;
                RetCode = GS_MHDog(pmdp);
			    if(RetCode==MH_SUCCESS)
			    {
				     wsprintf(DispData,"GetCurrentNo success is  ");
                     TextOut(hdc,80,280,DispData,strlen(DispData));

				     wsprintf(DispData,"CurrentNo = %ld", *(ULONG far *)pmdp->DogData);
                     TextOut(hdc,260,280,DispData,strlen(DispData));
			    }
			    else
                {
				     wsprintf(DispData,"GeCurentNo Error , ErrorCode = %d",RetCode);
				     TextOut(hdc,80,280,DispData,strlen(DispData));
                }
               
				ReleaseDC (hwnd, hdc);
            }
				break;
			case CM_EXIT:
				DestroyWindow( hwnd );
			break;
		  }
		  break;

		  case WM_DESTROY:
			   PostQuitMessage (0) ;
			   return 0 ;
	 }
	 return DefWindowProc (hwnd, message, wParam, lParam) ;
}


