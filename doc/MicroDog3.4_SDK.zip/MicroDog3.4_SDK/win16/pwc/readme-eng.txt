
                     -------------------------------------------------------
                               MicroDog Suite 16-bit WINDOWS Application
                                 API Guide to SETTING PASSWORD with C
                     -------------------------------------------------------

                   Copyright (c) 2001, Rainbow China Co., Ltd.

        MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.    
    
  The RC-MH specified below has exactly the same functions of MicroDog Suite.

=====================
Function introduction
=====================
This API module is C/C++ module, and is designed special for setting password in the 
hardware Dog used by developers. PLEASE DO NOT RELEASE THE API MODULE (WIN16SP.OBJ) TO 
YOUR END-USERS.

With regard to the protection technique, please refer to the Developer's Manual.
  
==========
File list
==========
    File name       Description
    ------------    -----------------------------------
    README-ENG.TXT  This file
    WIN16SP.OBJ	    API OBJ module for setting password
    MH16DEMO.MAK    VC Project file
    MH16DEMO.DEF    Module definition file
    MH16DEMO.C	    VC example program source code
    MH16DEMO.RC	    VC resource file
    demo.prj        BC Project file
    win16bc.rc      BC Resource file
    resource.h      resource header file
=====================
Testing Environments
=====================
    Borland C++ 3.1, 4.0, 4.5, 5.0
    Microsoft Visual C/C++ 1.52

===============
API Functions
===============

1. Interface defines the following function, which the developers may use in 
   their programs.
    unsigned long far SetPassword(void);

2. Developers must define the following global variables in their applications:
    unsigned long DogPassword;	/* Previous Password*/
    unsigned long NewPassword;	/* New Password*/
    unsigned char Cascade;	/* Cascade Number (1, 2 or 3), it must be 0 in this 
                                   version. */

3. This file contains only one function.
    unsigned long far SetPassword(void)
    Input parameter: Cascade, NewPassword, DogPassword
    Output Parameter: None
    Return value: Return zero if successful; return an error code if the function fails.
    Function: Setting the read/write Password of the hardware Dog. DogPassword refers to 
              the original password, and NewPassword refers to the one going to replace
              the original password.

===========
Error Code
===========
   Refer to ERRCODE.TXT in the root of the installation directory for detailed 
   information about error codes.

================================================
Compiling and running of the example program 
================================================
  
    This program has been tested under MS VC++ 1.52. The process is listed below:
    1 Visual C++ 1.52 compiler
    2 Code Generation
	2.1 Struct Member Byte Alignment: 1 Byte
	2.2 Disable Stack Checking: True
    3 Memory Model
	3.1 Model: Large
	3.2 Segment Setup: SS==DS*
    4 Windows Prolog/Epilog: None

=========
Caution
=========
 	
1. In this version, the modules do not have a cascade function. CASCADE will  
   be used in the future, so it must be set to 0 now. If you need this 
   function, please contact us.      

2. When you link the API to your application, if the IDE is MS VC++1.52 
   and the application calls MFC, please ignore some lib in the link 
   setting.  Otherwise, a warning will occur.

3. When you write data to the Dog, changing the last 4 bytes of the 
   MicroDog memory will affect the result of function DogConvert().

4. If you use MD or MF, the functions DogCheck() and DogConvert() require
   DogPassword, and the functions DisableShare() and GetCurrentNo() are 
   not functional.


=================
Technical support
=================
If you have any technical problems, please contact Rainbow Goldensoft Co., Ltd., 
our branches, or our distributors.  Be prepared to provide us your software part 
number.  This will accelerate our help.

The part number of WIN16SP.OBJ is GS-MH-W16-PWDINT 2.000.

The last part of a part number is a version number, which can also be extracted
by using Utility/Getver.exe.   The two values should be same.  If not, refer to 
the result returned by Getver.exe  first.  The version information can be helpful
in pinpointing and solving problems.

Please Refer to  /Address.txt for the contact address.
