/****************************************************************************
             
    Copyright 2000 Rainbow Goldensoft Co.,Ltd. All Rights Reserved

****************************************************************************/

#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "resource.h"

unsigned char Cascade;
		//  The globle variable Cascade indicates the cascade serial . 
        //  It must be set to 0 at this version.
unsigned long DogPassword;
		// Dog's password.
unsigned long NewPassword;

extern unsigned long far SetPassword(void);

HANDLE hInst;

BOOL FAR PASCAL MainDlgProc(HWND, unsigned, WORD, LONG);

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;                // current instance
HANDLE hPrevInstance;            // previous instance
LPSTR lpCmdLine;                 // command line
int nCmdShow;                    // show-window type (open/icon)
{
	hInst = hInstance;

	DialogBox(hInstance,"MainDlg",(HWND)NULL,MainDlgProc);   

	return 0;
}

BOOL FAR PASCAL MainDlgProc(HWND hDlg,unsigned message,WORD wParam,LONG lParam)                                                           
{                         
	BOOL fTranslated;
	unsigned char buff[32];
	DWORD ret = 0;
	
	switch(message)                                                    
	{                        
		case WM_INITDIALOG:
    		SetDlgItemText(hDlg, IDC_CASCADE, (LPCSTR)"0");
			break;
		case WM_COMMAND:
			switch(wParam)
			{                  
			case IDC_SET:
				Cascade = GetDlgItemInt(hDlg, IDC_CASCADE, &fTranslated	, FALSE);
				if(!fTranslated)
				{
					SetDlgItemText(hDlg, IDC_STATUS, "Error: Cascade parameter isn't right!");
					break;
				}
				
				GetDlgItemText(hDlg, IDC_OLD_PASSWORD, buff, 32);
				DogPassword = (unsigned long)atol(buff);

				GetDlgItemText(hDlg, IDC_NEW_PASSWORD, buff, 32);
				NewPassword = (unsigned long)atol(buff);

                if(ret = SetPassword())
				{
					wsprintf(buff, "Error %ld: Set password fail!", ret);
					SetDlgItemText(hDlg, IDC_STATUS, buff);
				}
				else SetDlgItemText(hDlg, IDC_STATUS, "Set password successful!");
				
				break;
			case IDOK:
				EndDialog(hDlg, TRUE);
				break;
			default:
				return FALSE;
			}
		default:
			return FALSE;
       		//return (BOOL)DefWindowProc(hDlg, message, wParam, lParam);
    }
    
    return TRUE;
}

