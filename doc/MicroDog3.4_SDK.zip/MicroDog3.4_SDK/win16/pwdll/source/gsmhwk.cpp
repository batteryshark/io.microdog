/****************************************************************************
             
    Copyright 2000 Rainbow Goldensoft Co.,Ltd. All Rights Reserved

****************************************************************************/

#include "windows.h"
#include "gsmhwk.h"
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

extern unsigned long FAR PASCAL GS_MHDog(PMH_DLL_PARA);

UCHAR Cascade;
unsigned long DogPassword;
unsigned long NewPassword;
		
extern MHSTATUS SetPassword(void);

#ifdef __cplusplus
}
#endif

//default unload DLL
int FAR PASCAL WEP (int  bSystemExit)
{
    return(1);
}

//default Load DLL
BOOL FAR PASCAL DllMain (HINSTANCE hDLL, DWORD dwReason, LPVOID lpReserved)
{                          
    return 1;
}

//---------------------------------------------------------------------
//Routine Description:
//	the DLL(Dynamic-Link Library) only one interface function
//
//	Return Value:
//		if the function succeeds, the return value is MH_SUCCESS
//		if the function fails, the return valuse is error code
//			For details on error code, see the ErrCode.txt
//
//Parameters:
//	pmdp 
//		Points to a MH_DLL_PARA structure. You must fill the 
//		structure with the appropriate command and data before 
//		passing it to the function, and it to be filled in by 
//		this function. 
//
//
//----------------------------------------------------------------------
unsigned long FAR PASCAL GS_MHDog(PMH_DLL_PARA pmdp)
{            
	MHSTATUS resu;
	Cascade = pmdp->Cascade;
	DogPassword = pmdp->DogPassword;
	NewPassword = *(DWORD *)pmdp->DogData;
	
	switch(pmdp->Command)
	{
	case 8:          
		resu = SetPassword();
		break;
	}
	
	return resu;
}
