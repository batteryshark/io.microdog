/****************************************************************************

    Copyright 2000 Rainbow Goldensoft Co.,Ltd. All Rights Reserved

****************************************************************************/

#ifndef ULONG
#define ULONG unsigned long
#endif

#ifndef HUINT
#define HUINT unsigned short
#endif

#ifndef UCHAR
#define UCHAR unsigned char
#endif

#ifndef WORD
#define WORD unsigned short
#endif

#define MHSTATUS ULONG

    typedef struct _MH_DLL_PARA
    {
    	BYTE	Command;
    	BYTE	Cascade;
    	WORD	DogAddr;
    	WORD	DogBytes;
    	DWORD	DogPassword;
    	DWORD	DogResult;
    	BYTE	DogData[200];
    }MH_DLL_PARA,  far * PMH_DLL_PARA;
    
//	unsigned long FAR PASCAL GS_MHDog(PMH_DLL_PARA pmdp);
    