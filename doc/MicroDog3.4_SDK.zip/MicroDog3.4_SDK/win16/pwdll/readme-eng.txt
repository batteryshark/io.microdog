
                     -------------------------------------------------------
                              MicroDog Suite 16-bit WINDOWS Application
                               API Guide to SETTING PASSWORD with DLL
                     -------------------------------------------------------

                   Copyright (c) 2001, Rainbow China Co., Ltd.
     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.     
    
  The RC-MH specified below has exactly the same functions of MicroDog Suite.

=====================
Function introduction
=====================
This API module is DLL module used by other 16-bit applications, and is designed special 
for setting password in the hardware Dog used by developers. 

PLEASE DO NOT RELEASE THE API MODULE (WIN16SP.OBJ) TO YOUR END-USERS.

With regard to the protection technique, please refer to the Developer's Manual.
  
==========
File list
==========
    File name       Description
    ------------    -----------------------------------
    README-ENG.TXT  This file
    Gsmhwk.dll      DLL module for setting password
    VB      <dir>   Demo program of VB 3.0
    source  <dir>   Source codes to build this DLL

==============================
Introduction to the GSMHWK.DLL
==============================
1. The GSMHWK.DLL is written with C, and call standard C API to operate the hardware Dog.

2. The DLL onle defines a function.
      WINAPI unsigned long GS_MHDog(MH_DLL_PARA *)	
   Return zero means succeeded, others are error codes. 

3. ALl data are defined in structure MH_DLL_PARA
    typedef struct _MH_DLL_PARA
    {
	BYTE 	Command;		/* Command code */
	BYTE	Cascade;		/* Cascade number, it must be 0 in this versiom. */
	WORD	DogAddr;		/* Beginning address of operation */
	WORD	DogBytes;		/* Byte number of operation*/
	DWORD	DogPassword;	/* Access password, factory setting is 0, you may use 
								DOGEDIT.EXE to change the password */
	DWORD	DogResult;		/* COnversion result */
	BYTE  	DogData[200];	/* IO data  */
    } MH_DLL_PARA;

4. Command, Member of the structure, is command code, it is defined as:
	Setpassword	8	/* Set password */

============
Error code
============
  Refer to ERRCODE.TXT in the root of the installation directory for detailed 
  information about error codes.

=======
Caution
=======
   In this version, the module does not have a cascade function, although 
   CASCADE will be available in the future. So, it must be 0. If you need this 
   function, please contact us.    

=================
Technical support
=================
If you have any technical problems, please contact Rainbow Goldensoft Ltd., 
our branches, or our distributors.  Be prepared to provide us your software 
part number.  This will accelerate our help.

The part number of GSMHWK.DLL is GS-MH-W16-PWDINT 2.000.

The last part of a part number is a version number, which can also be extracted
by using Utility/Getver.exe.   The two values should be same.  If not, refer to 
the result returned by Getver.exe  first.  The version information can be helpful
in pinpointing and solving problems.

Please Refer to  /Address.txt for contact address.

