				========================================
					MicroDog Utility Guide
				========================================
			      Copyrights (c)  2003  Rainbow China Co., Ltd.

  
=========
Software 
=========

    The new software includes the following files and documents:
    Readme-eng.txt              This file
    DogEdt32.exe                The powerful developer's tool.
    DogEdt32-eng.chm		The help of developer's tool.
    GetVer.exe                  Get version of encryption modules(for dos16,dos32,
				win16 and wni32 obj).
    Diagnose.exe		This tool can get the information of system and the 
				information of SoftDog's driver etc.You can use this 
				tool to report your system's information to Rainbow China.

======================================================================
    Dog, MicroDog are registered trademarks of Beijing Goldensoft Co., Ltd. and have been 
authorized to Rainbow Chian Co.,Ltd for its use.