#ifndef D32INT_H
#define D32INT_H
#define MHSTATUS unsigned long

#define	DogCheck	_DogCheck
#define	ReadDog		_ReadDog
#define WriteDog	_WriteDog
#define	DogConvert	_DogConvert
#define	GetCurrentNo	_GetCurrentNo
#define	EnableShare		_EnableShare
#define	DisableShare	_DisableShare

extern  MHSTATUS _DogCheck(void);
extern  MHSTATUS _ReadDog(void) ;
extern  MHSTATUS _WriteDog(void);
extern  MHSTATUS _DogConvert(void);
extern  MHSTATUS _GetCurrentNo(void);
extern  MHSTATUS _EnableShare(void)     ;
extern  MHSTATUS _DisableShare(void);   

#define	DogAddr		_DogAddr
#define	DogBytes	_DogBytes
#define	Cascade		_Cascade
#define	DogPassword	_DogPassword
#define DogResult	_DogResult
#define	DogData		_DogData

extern short  _DogAddr,_DogBytes;
extern unsigned char _Cascade;
extern unsigned long _DogPassword;
extern unsigned long _DogResult;
extern void * _DogData;

#endif

