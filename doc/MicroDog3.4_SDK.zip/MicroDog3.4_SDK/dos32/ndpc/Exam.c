#include "stdio.h"
#include "string.h"
#include "d32int.h"

/************************************************************************
  The globle variable DogAddr indicates the first memory  address ( range
0 to 199) of user area in the MicroDog when you make reading and/or writing
operations.The sum of DogAddr and DogBytes should not exceed 200.
************************************************************************/
short DogAddr;

/************************************************************************
  The globle variable DogBytes indicates the number ( 1-200 ) of bytes in
the  operation of reading/writing or  convertion. The  sum of DogAddr and
DogBytes should not exceed 200.
************************************************************************/
short DogBytes;

/************************************************************************
  The globle variable DosPassword indicates the password in the MicroDog
(factory value is zero), used in the reading/writing/converting operation.
***********************************************************************/
unsigned long DogPassword;

/************************************************************************
  The globle variable DogResult indicates the result of converting opera-
tion.
************************************************************************/
unsigned long DogResult;

/************************************************************************
  The globle variable DogData indicates  the pointer variable which poi-
  nts to the data for operations .
************************************************************************/
void  *    DogData;

/************************************************************************
  The globle variable Cascade indicates the cascade serial .
************************************************************************/
unsigned char Cascade;

/************************************************************************
  The following variables including its names and contents may be defined
by user himself.
************************************************************************/
void main()
{
  char DogConvertCharBuff[]={"Micro Dog GS-MH"};
  char WriteCharBuff[30]={"Micro Dog GS-MH is OK !"};
  char ReadCharBuff[30];

  unsigned short len;
  unsigned long retCode,CurrentNo;
  int wint,rint;

  Cascade = 0;         /* Assume the Dog is the first cascaded one. */

  printf("\n******** DisableShare ********\n");
  retCode = DisableShare();
  if(retCode)
    printf("DisableShare error. Return code: %ld\n", retCode);
  else
    printf("DisableShare success.\n");

  printf("********** DogCheck **********\n");
  retCode = DogCheck();
  if(retCode)
    printf("Dog check error. Return code: %ld\n", retCode);
  else
    printf("Dog check success.\n");

  DogBytes = strlen(DogConvertCharBuff);
  DogData = DogConvertCharBuff;
  retCode = DogConvert();
  printf("********* DogConvert *********\n");
  if(retCode)
    printf("Dog convert error. Return code: %ld\n", retCode);
  else
  {
    printf("Dog convert success.");
    printf("    Result: (Dec)%ld, (Hex)%lx\n", DogResult, DogResult);
  }

  printf("********** WriteDog **********\n");
  DogPassword = 0;  /*  The password of the dog was originated as zero.
			if you have changed the value of it , you must
			put its value here.  */
  len = strlen(WriteCharBuff);
  DogData = WriteCharBuff;
  DogAddr = 0;
  DogBytes = len;
  retCode = WriteDog();
  if(retCode)
    printf("Write Dog error. Return code: %ld\n", retCode);
  else
    printf("Write string '%s' to Dog success .\n",WriteCharBuff);

  wint = 12345;
  DogData = &wint;
  DogAddr = 100;
  DogBytes = 2;
  retCode = WriteDog();
  if(retCode)
    printf("Write Dog error. Return code: %ld\n", retCode);
  else
    printf("Write integer %d to Dog success .\n",wint);


  printf("********** ReadDog ***********\n");
  DogAddr = 0;
  DogBytes = len;
  memset(ReadCharBuff,0,30);
  DogData = ReadCharBuff;
  retCode = ReadDog();
  if(retCode)
    printf("Read Dog error. Return code: %ld\n", retCode);
  else
    printf("Read Dog success. Read string from Dog is: %s\n", DogData);

  rint = 0;
  DogAddr = 100;
  DogBytes = 2;
  DogData = &rint;
  retCode = ReadDog();
  if(retCode)
    printf("Read Dog error. Return code: %ld\n", retCode);
  else
    printf("Read Dog success. Read integer from Dog is: %d\n", rint);


  printf("******** GetCurrentNo *********\n");
  CurrentNo = 0;
  DogData = &CurrentNo;
  retCode = GetCurrentNo();
  if(retCode)
    printf("GetCurrentNo error. Return code: %ld\n", retCode);
  else
    printf("GetCurrentNo success. The dog's current number is : %ld\n",CurrentNo);
}
