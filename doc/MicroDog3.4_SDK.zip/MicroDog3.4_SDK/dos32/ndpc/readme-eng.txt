
                     -------------------------------------------------------
                           MicroDog Suite 32-bit Extended DOS Application
                                      API Guide to NDP C
                     -------------------------------------------------------

                          Copyright (c) 2001, Rainbow China Co., Ltd.
  
         MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.    


=========
Functions
=========
  MicroDog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, 
writing data into and reading data from the memory, changing data, checking the current 
manufacturing number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six basic functions specified above will secure your software products from any unauthorized
use. For detailed description of protection strategy, please read The Developer's Manual .
  
=========
File list
=========
   File name             Description
   --------------        -----------------------------------------------------
   README-ENG.TXT        This file
   LTL_C.obj             API OBJ file
   EXAM.C                Example program
   D32INT.H              Head file used by Example program 
   MAKE.BAT              MAKE file

===================
Tested Environments
===================
   NDP C 3.2   

=============
API Functions
=============

1. APIs define the following functions which can be used in the developer's program.
       unsigned long DogCheck(void)                       Check dog
       unsigned long ReadDog(void)                        Read dog
       unsigned long WriteDog(void)                       Write dog
       unsigned long DogConvert(void)                     Dog convert 
       unsigned long GetCurrentNo(void)                   Get current number
       unsigned long DisableShare(void)                   Disable share

2. Developers must define the following global variables in the application:
       unsigned char Cascade 
       short  DogAddr        
       short  DogBytes       
       unsigned long DogPassword
       unsigned long DogResult  
       void * DogData           

   Explanation for global variables
   --------------------------------
     a. DogAddr:  Indicates the start address (0~199) of MicroDog internal 
                  user area during read operation. The sum of adding DogAddr with 
                  DogBytes will not be allowed to be over 200.

     b. DogBytes: Byte number of read operation (1~200) or conversion operation 
                  (1~63). In read operation, The sum of adding DogAddr with DogBytes 
                  will not be allowed to be over 200.

     c. DogPassword: Access password. The factory setting in the hardware Dog is 
                     0, it may be changed by DOGEDIT.EXE in UTILITY folder. It 
                     will only take effect for the functions of ReadDog and WriteDog, 
                     not for DogCheck and DogConvert.

     d. DogResult: Result after conversion. Function DogConvertT will put the 
                   converted result into this variable. Be careful, if the 
                   operation of DogConvert fails, the original DogResult value will 
                   not be changed. 

     e. Cascade: Reserved parameter for cascade capability, it should be 0 in 
                 this version.

     f. DogData: Buffer of read/write/conversion operation. 

3. DogCheck()
   Input parameter:  Cascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Checks whether the hardware Dog exists. Only the Dog that has the same ID
         number as the OBJ file can be detected.  In this version, the modules don't 
         have a cascade function, and the parameter CASCADE will be used in the future, so it
         must be 0 now. If need this function, please contact us.    

   Example:
        unsigned long retCode;
        ......
        ......
        Cascade = 0;      /* Cascade number must be 0 in this version */
        retCode = DogCheck();
        if(retCode)       /* If returen value is not 0 */
          printf("Dog check error. Return code: %ld\n", retCode);
        else
          printf("Dog check success.\n");
        ......
        ......

4. ReadDog()
   Input parameter: Cascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter: DogData
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads data from the hardware Dog. The Dog contains a 200-byte nonvolatile 
         memory.  From the Dog, ReadDog reads data from the memory beginning at the 
         address indicated by DogAddr.  The byte number of the read data is indicated 
         by DogBytes.  The read data will be stored in the space that DogData points to.
         The MicroDog will verify the DogPassword. DogPassword is the password for the
         read/write operations.  It is stored in the hardware Dog.  It can be set by 
         the utility tool or the SetPassword() function. Applications must secure enough
         space to buffer the data being read.  ReadDog will not check whether the size of
         a buffer is sufficient.

   Example 1:
        /*Read a 10 bytes string from address 0 of the MicroDog memory */
        unsigned long retCode;
        unsigned char ReadCharBuff[30];
        ......
        ......
        Cascade = 0;      /* Cascade number must be 0 in this version */
        DogAddr = 0;      /* Beginning address is 0 */
        DogBytes = 10;    /* Length is 10 bytes*/
        DogPassword = 0;  /* Password of the dog is 0 */
        /* Factory setting of password is 0, you may change it by the tool DOGEDIT.EXE (in 
         UTILITY folder).*/

        DogData = ReadCharBuff;   /* DogData point to the string*/
        retCode = ReadDog();
        if(retCode)    /* if return value is not 0 */
          printf("Read Dog error. Return code: %ld\n", retCode);
        else
          printf("Read Dog success. Read string from Dog is: %s\n", ReadCharBuff);
        ......
        ......

   Example 2:
        /*  Read an integer from address 100 of the MicroDog's memory.  */
        unsigned long retCode;
        int rint;
        ......
        ......
        Cascade = 0;        /* Cascade number must be 0 in this version */
        DogAddr = 100;      /* Beginning address is 100 */
        DogBytes = 2;       /* The length of int variable is 2 */
        DogPassword = 0;    /* Password of the dog is 0 */
        /* Factory setting of password is 0, you may change it by the tool DOGEDIT.EXE (in 
         UTILITY folder).*/

        DogData = &int;   /* DogData point to the integer */
        retCode = ReadDog();
        if(retCode)    /* if the return value is not 0 */
          printf("Read Dog error. Return code: %ld\n", retCode);
        else
          printf("Read Dog success. Read integer from Dog is: %d\n", rint);
        ......
        ......


5. WriteDog()
   Input parameter: Cascade, DogAddr, DogBytes, DogData, DogPassword
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Writes data to the hardware Dog. Carries out the same operation as ReadDog does
      except the data flow direction is different.

    Example 1:
        /*  Write a string to address 10 of the MicroDog memory */
        unsigned long retCode;
        unsigned char WriteCharBuff[30]={"Micro Dog GS-MH is OK !"};
        ......
        ......
        Cascade = 0;      /* Cascade number must be 0 in this version */
        DogAddr = 10;      /* Beginning address is 10 */
        DogBytes = strlen(WriteCharBuff);    /* The length is the string length */
        DogPassword = 0;  /* The password of the Dog is 0 */
        /* Factory setting of password is 0, you may change it by the tool DOGEDIT.EXE (in 
         UTILITY folder).*/

        DogData = WriteCharBuff;   /* DogData point to the string */
        retCode = WriteDog();
        if(retCode)    /* If return value is not 0 */
          printf("Write Dog error. Return code: %ld\n", retCode);
        else
          printf("Write string '%s' to Dog success .\n",WriteCharBuff);
        ......
        ......

   Example 2:
        /*  write a long integer to address 120 of MicroDog memory */
        unsigned long retCode;
        long wlong;
        ......
        ......
        Cascade = 0;        /* Cascade number must be 0 in this version */
        DogAddr = 120;      /* Beginning address is 120 */
        DogBytes = 4;       /* The length of long integer is 4 bytes */
        DogPassword = 0;    /* The password of the Dog is 0 */
        /* Factory setting of password is 0, you may change it by the tool DOGEDIT.EXE (in 
         UTILITY folder).*/

        DogData = &wlong;   /* DogData point to the long integer */
        retCode = WriteDog();
        if(retCode)         /* if the return value is not 0 */
          printf("Write Dog error. Return code: %ld\n", retCode);
        else
          printf("Write long %ld to Dog success .\n",wint);
        ......
        ......

6. DogConvert()
   Input parameter: Cascade, DogBytes, DogData
   Output parameter: DogResult
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Transfers data to MicroDog.  Then the hardware Dog scrambles the data, 
       and returns the scrambled result Dogresult as a 32-bit integer.  DogBytes indicates
       the number of bytes of the data, which DogData points to, being converted. 
       The conversion algorithm can be specified by the developer.  The last 4 bytes 
       of the memory will affect the conversion algorithm.  The 196th byte is used to 
       specify the algorithm.  Therefore, the developer can define 256 kinds of algorithms. 
       The algorithm descriptor is made up of the 197th,198th and 199th byte, so it 
       may have a total of 16,777,215 different combinations.

      Example:
        /*  Convert string "MicroDog" */
        unsigned long retCode;
        unsigned char DogConvertCharBuff[10]={"MicroDog"};
        ......
        ......
        Cascade = 0;      /* Cascade number must be 0 in this version */
        DogBytes = strlen(DogConvertCharBuff);  /* The length of the string */
        /* Factory setting of password is 0, you may change it by the tool DOGEDIT.EXE (in 
         UTILITY folder).*/

        DogData = DogConvertCharBuff;   /* DogData point to the string */
        retCode = DogConvert();
        if(retCode)    /* if the return value is not 0 */
          printf("Dog convert error. Return code: %ld\n", retCode);
        else
        {
          printf("Dog convert success.");
          printf("Result: (Dec)%ld, (Hex)%lx\n", DogResult, DogResult);
        }
        ......
        ......

7. DisableShare()
   Input parameter: Cascade
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Disable the hardware Dog's sharing ability.
         The parallel port hub is a kind of hardware share device that allows multiple 
         copies of the protected program share the same Dog. 
         Factory setting for share ability is Enable. You may call DisableShare function to 
         to prevent pirates from using a parallel port hub. So that only the machine that 
         has the Dog can run the protected program.  
         DisableShare only affects the functions ReadDog, WriteDog and DogConvert. 

* Caution:
         Do not call on this function multiple times. It is designed to be called no more
         than once in an application.

      Example:
        unsigned long retCode;
        ......
        ......
        Cascade = 0;      /* Cascade number must be 0 in this version */
        retCode = DisableShare();
        if(retCode)       /* if the return value is not 0 */
          printf("DisableShare error. Return code: %ld\n", retCode);
        else
          printf("DisableShare success.\n");
        ......
        ......

8. GetCurrentNo()	
   Input Parameter: Cascade, DogData
   Output parameter: DogData
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads the Manufacturing code of the hardware Dog.Some of the hardware
             Dogs may have the same ID, but every hardware Dog has its unique
             Manufacturing code. The Manufacturing code can help developers manage
             user accounts.
             The Manufacturing code is 4 bytes.

      Example:
        unsigned long retCode, CurrentNo;
        ......
        ......
        Cascade = 0;      /* Cascade number must be 0 in this version */
        CurrentNo = 0;
        DogData = &CurrentNo;
        retCode = GetCurrentNo();
        if(retCode)       /* If the return value is not 0 */
          printf("GetCurrentNo error. Return code: %ld\n", retCode);
        else
          printf("GetCurrentNo success. The dog's current number is : %ld\n",CurrentNo);

        
============
Error code
============
   Refer to ERRCODE.TXT in the root of the installation directory for detailed 
   information about error codes.

================================================
Compiling and running the example program 
================================================
 
    This example program has been tested under NDP C 3.2.

    The compiling of the example program:
    "mc386 EXAM.C LTL_C.OBJ -ansi"

    Or you can use the batch file under the current directory
    Command line: "MAKE exam"
    Before using the batch file, please modify the NDP C path.

    The example program demonstrates how the above functions run.

    This is only a simple example of calling the functions above. For advanced 
    protection techniques, please refer to the MicroDog Developer's Manual.


=========
Caution
=========
 	
1. All names of functions and variables in this module(LTL_C.OBJ) contain 
   underlined character (_).  Some compiler environments allow you to select 
   whether you can use underlined characters, and some don't; If you are not 
   allowed, please add underlined characters before the function names and 
   the variable names. Otherwise, there will be compiling errors.

2. When you write data to the Dog, changing the last 4 bytes of the 
   MicroDog memory will affect the result of the function DogConvert().

3. The API module also can be used for GS-MD/MF MicroDog, but can not use new features 
   of RC-MH.

4. If you use GS-MD/MF MicroDog, the functions DogCheck() and DogConvert() require
   DogPassword, and the functions DisableShare() and GetCurrentNo() are not functional.

5. In this version, the modules do not have a cascade function, although 
   CASCADE will be available in the future. So, it must be 0. If you need this 
   function, please contact us.    

=================
Technical support
=================

If you have any technical problems, please contact Rainbow China Ltd., 
our branches, or our distributors.  Be prepared to provide us your software 
part number.  This will accelerate our help.

The part number of this module is GS-MH-DOS32-NDPC 1.008
The last part of a part number is a version number, which can also be extracted
by using Utility/Getver.exe.   The two values should be same.  If not, refer to 
the result returned by Getver.exe  first.  The version information can be helpful
in pinpointing and solving problems.

Please Refer to  /Address.txt for contact address.


 
    