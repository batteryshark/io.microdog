
                     -------------------------------------------------------
                           MicroDog Suite 32-bit Extended DOS Application
                              API Guide to POWER STATION FORTRAN
                     -------------------------------------------------------

                              Copyright (c) 2001, Rainbow China Co., Ltd.
     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.

  *Note: All the module in this folder can not operate USBDog(UMC type). Operating PMH
          is not restricted by operating systems.    



  The API for POWER STATION FORTRAN  is a module for Extended DOS and is suitable for protecting 
POWER STATION FORTRAN application.

=========
Functions
=========
  MicroDog Suite contains two Hardware Dog (Parallel Dog and USBDog) and the supporting software.
  The Hardware Dog consists of a microprocessor and a memory.  Please insert the Hardware 
Dog of Parallel Dog into the parallel port or that of USBDog into the USB port.  The software 
supplies functions for calling the Hardware Dog.
  MicroDog Suite has six basic functions including verifying of the correct Hardware Dog, 
writing data into and reading data from the memory, changing data, checking the current 
manufacturing number and setting anti-sharing mode.
  The fastest calling and easies-to-use protection mode is DogCheck, verifying the correct 
Hardware Dog. 
  The WriteDog and ReadDog functions are writing data into and reading data from the memory.  
When using the two functions, you can write variables dynamically into the program and call 
them directly to achieve security of higher degree.  You can also write the configuration data 
into Hardware key and record your operations.
  DogConvert function is that the program sends a string of data to Hardware Dog, and Hardware  
Dog will return a 32-bit integer number.  The data sent and the data returned can match each 
other well.  The algorithms for Hardware Dog with different Serial Numbers are different, and 
you can define your own protection algorithms.  256 algorithms are available and 3-byte 
descriptors can be selected for each algorithm, thus more than 16 million different algorithm 
descriptors. 
  GetCurrentNo function is used to read the current manufacturing number of Hardware Dog. Each 
Hardware Dog has a unique manufacturing number for customer account management.
  The anti-sharing function is designed especially to disable the parallel port sharing devices.
The software will not be shared by multiple parallel port sharing devices once this function is
Activated.
  The six basic functions specified above will secure your software products from any unauthorized
use. For detailed description of protection strategy, please read The Developer's Manual .


=========
File list
=========
   File name             Description
   --------------        -----------------------------------------------------
   README-ENG.TXT        This file
   POWER_F.OBJ           API OBJ file
   EXAM.C                Demo program
   MAKE.BAT              MAKE batch file

===================
Tested Environments
===================
   POWER STATION FORTRAN 1.0   

=============
API Functions
=============
1. API module (POWER_F.OBJ) defines the following functions which can be used in the 
   developer's program: 
        INTEGER*4 DOGCHECK  
        INTEGER*4 READDOG    
        INTEGER*4 WRITEDOG    
        INTEGER*4 DOGCONVERT  
        INTEGER*4 GETCURRENTNO  
        INTEGER*4 DISABLESHARE  


2. Meanwhile, Developer should define following COMMON block: 
	INTEGER*2 DOGADDR, DOGBYTES, CASCADE
        INTEGER*4 DOGPASSWORD, RESULT
	CHARACTER*n DOGDATA
C       n maybe an integer between 1 and 127
	COMMON /MHCOMM/DOGADDR, DOGBYTES, DOGPASSWORD, DOGRESULT, CASCADE, DOGDATA

   There are 6 variables in MHCOMM COMMON block, you may change the variable name(s) 
but the name MHCOMM and sequence of 6 variables should not be changed.

   Explanation for global variables
   --------------------------------
     a. INTEGER*2 DOGADDR:  Indicates the start address (0~199) of MicroDog internal 
                         user area during read operation. The sum of adding DOGADDR with 
                         DOGBYTES will not be allowed to be over 200.

     b. INTEGER*2 DOGBYTES: Byte number of read operation (1~200) or conversion operation 
                         (1~63). In read operation, The sum of adding DOGADDR with DOGBYTES 
                         will not be allowed to be over 200.

     c. INTEGER*4 DOGPASSWORD: Access password. The factory setting in the hardware Dog is 
                          0, it may be changed by DOGEDIT.EXE in UTILITY folder. It 
                          will only take effect for the functions of READDOG and WRITEDOG, 
                          not for DOGCHECK and DOGCONVERT.

     d. INTEGER*4 DOGRESULT: Result after conversion. Function DOGCONVERT will put the 
                          converted result into this variable. Be careful, if the 
                          operation of DOGCVT fails, the original DOGRESULT value will 
                          not be changed. 
     e. INTEGER*2 CASCAD: Reserved parameter for cascade capability, it should be 0 in 
                          this version.
     f. CHARACTER*n DOGDATA: Buffer of read/write/conversion operation. You may define it 
                          as any kind of valid type, length of the type should be defined 
                          by variable DOGBYTES.

3. INTEGER*4 DOGCHECK( )
   Input parameter:  CASCAD
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Checks whether the hardware Dog exists. Only the Dog that has the same ID
         number as the OBJ file can be detected.  In this version, the modules don't 
         have a cascade function, and the parameter CASCAD will be used in the future, so it
         must be 0 now. If need this function, please contact us.    

4. INTEGER*4 DOGCONVERT( )
   Input parameter: CASCAD, DOGBYTES, DOGDATA
   Output parameter: DOGRESULT
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Transfers data to MicroDog.  Then the hardware Dog converts the data, 
       and returns the converted result DOGRESULT as a 32-bit integer.  DOGBYTES indicates
       the number of bytes of the data, which DOGDATA points to, being converted. 
       The conversion algorithm can be specified by the developer.  The last 4 bytes 
       of the memory will affect the conversion algorithm.  The 196th byte is used to 
       specify the algorithm.  Therefore, the developer can define 256 kinds of algorithms. 
       The algorithm descriptor is made up of the 197th,198th and 199th byte, so it 
       may have a total of 16,777,215 different combinations.

5. INTEGER*4 READDOG( )
   Input parameter: CASCAD, DOGADDR, DOGBYTES, DOGDATA, DOGPASSWORD
   Output parameter: DOGDATA
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads data from the hardware Dog. The Dog contains a 200-byte nonvolatile 
         memory.  READDOG() reads data from the memory beginning at the address indicated by 
         DOGADDR.  The byte number of reading data is indicated by DOGBYTES.  The reading data 
         will be stored in the buffer DOGDATA.
         The MicroDog will verify the variable DOGPASSWORD. DOGPASSWORD is the password for the
         read/write operations.  It is stored in the hardware Dog.  It can be set by 
         the utility tool (DOGEDIT.EXE in UTILITY folder) or the SetPassword() function. 
         Applications must secure enough space to buffer the data being read.  READDOG() will 
         not check whether the buffer size is sufficient.

6. INTEGER*4  WRITEDOG ( )
   Input parameter: CASCAD, DOGADDR, DOGBYTES, DOGDATA, DOGPASSWORD
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Writes data to the hardware Dog. Carries out the same operation as READDOG() does
      except the data flow direction is different.

7. INTEGER*4 DISABLESHARE( )
   Input parameter: CASCAD
   Output parameter: None
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Disable the hardware Dog's sharing ability.
         The parallel port hub is a kind of hardware share device that allows multiple 
         copies of the protected program share the same Dog. 
         Factory setting for share ability is Enable. You may call DisableShare function to 
         to prevent pirates from using a parallel port hub. So that only the machine that 
         has the Dog can run the protected program.  
         DISABLESHARE() only affects the functions READDOG(), WRITEDOG() and DOGCONVERT(). 

* Caution:
         Do not call on this function multiple times. It is designed to be called no more
         than once in an application.

8. INTEGER*4 GETCURRENTNO( )
   Input Parameter: CASCAD, DOGDATA
   Output parameter: DogDATA
   Return value: Returns zero if successful; returns an error code if the function fails.
   Function: Reads the Manufacturing code of the hardware Dog.Some of the hardware
             Dogs may have the same ID, but every hardware Dog has its unique
             Manufacturing code. The Manufacturing code can help developers manage
             user accounts.
             The Manufacturing code is 4 bytes.

============
Error code
============
   Refer to ERRCODE.TXT in the root of the installation directory for detailed 
   information about error codes.

================================================
Compiling and running the example program 
================================================
 
    This example program has been tested under POWER STATION FORTRAN 1.0.

    The compiling of the example program:
    "FL32 EXAM.FOR POWER_F.OBJ"

    Or you can use the batch file under the current directory
    Command line: "MAKE exam"
    Before using the batch file, please modify the POWERF path.

    The example program demonstrates how the above functions run.

    This is only a simple example of calling the functions above. For advanced 
    protection techniques, please refer to the MicroDog Developer's Manual.

=========
Caution
=========
 	
1. When you write data to the Dog, changing the last 4 bytes of the 
   MicroDog memory will affect the result of the function DogConvert().

2. The API module also can be used for GS-MD/MF MicroDog, but can not use new features 
   of RC-MH.

3. If you use GS-MD/MF MicroDog, the functions DOGCHECK() and DOGCONVERT() require
   DOGPASSWORD, and the functions DISABLESHARE() and GETCURRENTNO() are not functional.

4. In this version, the modules do not have a cascade function, although 
   CASCADE will be available in the future. So, it must be 0. If you need this 
   function, please contact us.    

=================
Technical support
=================

If you have any technical problems, please contact Rainbow China Ltd., 
our branches, or our distributors.  Be prepared to provide us your software 
part number.  This will accelerate our help.

The part number of POWER_F.OBJ is GS-MH-LM-PSFOR 1.008.

The last part of a part number is a version number, which can also be extracted
by using Utility/Getver.exe.   The two values should be same.  If not, refer to 
the result returned by Getver.exe  first.  The version information can be helpful
in pinpointing and solving problems.

Please Refer to  /Address.txt for contact address.


	          