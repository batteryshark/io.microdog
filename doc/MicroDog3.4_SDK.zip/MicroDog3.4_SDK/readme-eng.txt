                                =======================
                                MicroDog SDK V3.4 Suite
                                =======================

     MicroDog Suite combines all advantages and features of USBDog(UMC type) 
and Parallel Dog(PMH type).The suite contains Hardware Dog of USBDog(UMC type) and Parallel 
Dog(PMH type) which are compatible with each other.The protected applications can use either 
USBDog or Parallel Dog when running in the operating systems such as Windows 98 ,Windows ME ,
Windows 2000 and Windows XP. The current version of Microdog can support only Parallel dog 
when the application is running in Windows NT 4.0 , so please contact us if you need to operate 
USBDog in that environment.



1. File list:

    Name                       Description
    ---------------------      --------------------------------------
    README-ENG.TXT               This file
    MicroDog.pdf                 Developer's Manual for Microdog Suite
    QSTART.pdf                   Quick start for Microdog Suite
    ADDRESS-ENG.TXT              Contact information of Rainbow China
    HOMEPAGE.URL                 Web address of Rainbow China
    ERRCODE-ENG.TXT              List of Error codes for Microdog Suite
    UTILITY      <DIR>           Some useful tools for Microdog Suite
    WIN16        <DIR>           APIs & Tools for WINDOWS 3.x
    WIN32        <DIR>           APIs & Tools for WINDOWS 9x/ME/NT/2000/XP
    DOS16        <DIR>           APIs & Tools for 16-bit DOS
    DOS32        <DIR>           APIs & Tools for 32-bit DOS(Expanded DOS)
    DRIVER       <DIR>           Device drivers installing tool forWindows 9x/ME/NT/2000/XP
    LINUX	 <DIR>	         APIs & Tools for LINUX

        With regard to detailed information for each module in various system platforms, 
    please see README and sample in that folder in which you are interesting.


2. Compatibility with PMF MicroDog:

        If you use the hardware Dog of PMF MicroDog to install Microdog Suite, please
   clear the access password in PMF Dog, otherwise installation will run into problem.